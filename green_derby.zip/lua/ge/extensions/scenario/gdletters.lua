-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

--local function getSignText(vehId, designPath)
--  local veh = {}
--  if not vehId then veh = be:getPlayerVehicle(0) end
--  if not vehId then return '' end
--  if type(vehId) == 'number' then
 --   veh = be:getObjectByID(vehId)
 -- end
 -- if not veh then return '' end

 -- local txt = veh:getDynDataFieldbyName("gdSignText", 0)
 -- if txt and txt:len() > 0 then return txt end

--  local design = nil
--  if designPath then
--    design = jsonReadFile(designPath)
--  end
  
--end
local function setSignText()
local vehIn = gdloader.vehIn
 for _,v in ipairs(vehIn) do
	local veh = nil
  if v.vid then
    veh = be:getObjectByID(v.vid)
  else
    veh = be:getPlayerVehicle(0)
  end
  if not veh then return end
 -- if not formats then
  --  local formattxt = veh:getDynDataFieldbyName("gdSignFormats", 0)
  --  if formattxt and string.len(formattxt) >0 then
  --    formats = jsonDecode(formattxt )
   -- else
    local  formats = {"30-20"}
   -- end
  --else
    veh:setDynDataFieldbyName("gdSignFormats", 0, jsonEncode(formats))
 --end
	local designPath = 'vehicles/common/roofsign_gd/roofsign_gd-default.json'
  --if not designPath then
  --  designPath = veh:getDynDataFieldbyName("gdSignDesign", 0) or ''
 -- else
    veh:setDynDataFieldbyName("gdSignDesign", 0, designPath)
 -- end

  local design
  if designPath and designPath~="" and FS:fileExists(designPath) then
    design = jsonReadFile(designPath)
  end
   --dump(design)
   local txt
   if v.driverNumber ~= 0 then
	txt = v.driverNumber 
	--getSignText(v.vid, designPath)
	veh:setDynDataFieldbyName("gdSignText", 0, txt)
	else 
		return 
	end
----adding letter html generator and characterlayout to Json file

  if design then
    local designData = nil
    --if design.version == 1 then
     -- local dtmp = {}; dtmp.data={};dtmp.data.format={}
     -- dtmp.data.format["30-15"] = design.data
    --  design = dtmp;
   -- end
    for _,curFormat in pairs(formats) do
      designData={}; designData.data=design.data.format[curFormat]
      local textureTagPrefix = "@roofsign_gd-default"
      if curFormat ~= "30-20" then
        textureTagPrefix = string.format("@roofsign_gd-%s", curFormat)
      end
      if not designData.data then
        log("W", "gdletters", "roofsign format not found '"..tostring(curFormat).."' in style '"..tostring(designPath).."'")
        local defaultDesignFallBackPath = 'vehicles/common/roofsign_gd/roofsign_gd-'..curFormat..'.json'
        if FS:fileExists(defaultDesignFallBackPath) then
          local defaultDesign = jsonReadFile(defaultDesignFallBackPath)
          if defaultDesign then
            designData.data = defaultDesign.data.format[curFormat]
            log("I", "gdletters", "roofsign fallback used '"..tostring(defaultDesignFallBackPath).."'")
          else
            log('E',tostring(defaultDesignFallBackPath) , 'Json error')
            goto continue
          end
        else
          log('E', "gdletters", '[NO TEXTURE] No fallback for this roofsign format. Please create a default file here : "'..tostring(defaultDesignFallBackPath)..'"')
          goto continue
        end
      end
      if designData.data.characterLayout then
        if FS:fileExists(designData.data.characterLayout) then
          designData.data.characterLayout = jsonReadFile(designData.data.characterLayout)
        else
          log('E',tostring(designData.data.characterLayout) , ' File not existing')
        end
      else
        designData.data.characterLayout= "vehicles/common/roofsign_gd/gdfont.json"
        designData.data.characterLayout= jsonReadFile(designData.data.characterLayout)
      end

      if designData.data.generator then
        if FS:fileExists(designData.data.generator) then
          designData.data.generator = "local://local/" .. designData.data.generator
        else
          log('E',tostring(designData.data.generator) , ' File not existing')
        end
      else
        designData.data.generator = "local://local/vehicles/common/roofsign_gd/roofsign_gd-default.html"
      end

      designData.data.format = curFormat
      -- log('D', "gdletters", "cef tex :"..tostring(curFormat).. "   gen="..tostring(designData.data.generator) .. "prefix="..tostring(textureTagPrefix) )
      veh:createUITexture(textureTagPrefix, designData.data.generator, designData.data.size.x, designData.data.size.y, UI_TEXTURE_USAGE_AUTOMATIC, 1) --UI_TEXTURE_USAGE_MANUAL
      veh:queueJSUITexture(textureTagPrefix, 'init("diffuse","' .. txt .. '", '.. jsonEncode(designData) .. ');')

      veh:createUITexture(textureTagPrefix.."-normal", designData.data.generator, designData.data.size.x, designData.data.size.y, UI_TEXTURE_USAGE_AUTOMATIC, 1)
      veh:queueJSUITexture(textureTagPrefix.."-normal", 'init("bump","' .. txt .. '", '.. jsonEncode(designData) .. ');')

      --veh:createUITexture(textureTagPrefix.."-specular", designData.data.generator, designData.data.size.x, designData.data.size.y, UI_TEXTURE_USAGE_AUTOMATIC, 1)
      --veh:queueJSUITexture(textureTagPrefix.."-specular", 'init("specular","' .. txt .. '", '.. jsonEncode(designData) .. ');')
      ::continue::
    end
  end
 end
end

M.setSignText = setSignText

return M