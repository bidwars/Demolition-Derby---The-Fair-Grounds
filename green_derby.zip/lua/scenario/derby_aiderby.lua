﻿-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local helper = require('scenario/scenariohelper')
--local vdata = {}  -- Current ai vehicle data
--local tdata = {}  --Target data

local user = "Hawk"
local target = nil
local targetSet = false
local hitTarget =  false
local vName = nil
local lasthit = false
local backup = false
local brake = 0
local throttle = 0
local collision = false
local tdataPos = nil
local callReset = false

require('mathlib')
local function debug(aiDirVec, targetAiMidPos, targetLength, dt)
	--if test2 ~= nil then
	--	debugDrawer:drawSphere(test2:toPoint3F(), 4, ColorF(1,0,0,0.3))
	--end
	--local debugDrawer = obj.debugDrawProxy
	local vel = map.objects[map.objectNames[vName]].vel
	local tpos = map.objects[map.objectNames[target]].pos
	local pos = map.objects[map.objectNames[vName]].pos
	if tpos ~= nil and targetAiMidPos ~= nil then
		--debugDrawer:drawSphere(test:toPoint3F(), 1.5, ColorF(1,0,0,0.3))
	local speed = vel:length()
	if speed < 3 then
		speed = 2 
	else 
		speed = 1 
	end

	local tspeed = vel:length()
	
	local futurePos = pos + (vel):normalized() * speed
	local futureTarget = tpos +  ((vel:normalized()) * tspeed)
	local futurePos2 = pos + vel * speed
	--debugDrawer:drawSphere(futurePos:toPoint3F(), 0.5, ColorF(1,0,0,0.3))
	--debugDrawer:drawSphere(futureTarget:toPoint3F(), 0.5, ColorF(0,1,0,1))
	debugDrawer:drawSphere(futurePos2:toPoint3F(), 0.5, ColorF(1,1,0,1))
    --debugDrawer:drawSphere((aiDirVec*targetLength + futureTarget):toPoint3F(), 0.5, ColorF(0,1,0,1))
   -- debugDrawer:drawSphere(targetAiMidPos:toPoint3F(), 0.3, ColorF(1,0,0,0.3))
	end
end
-------------------------------------------------------------------------------------
--RETURNS A TARGET FOR THE AI  *vNotToTarget - set AI to not target itself
-------------------------------------------------------------------------------------
local function findRandomTarget(vNotToTarget)
	local sVehicles = scenario_derby_vehicles.sVehicles
	local vehIn = scenario_derby_main.vehIn
	local vTimeout = scenario_derby_main.vTimeout
	local targetList = {}
	local dirVec = map.objects[map.objectNames[vNotToTarget]].dirVec
	local pos = map.objects[map.objectNames[vNotToTarget]].pos
	local bestTargetVec = 0
	local lastbest = {}
	local far = 0
	local cCount = scenario_derby_vehicles.vehicleData[vNotToTarget].cCount
	if cCount < 1 then
		--for i = 0, 3 do
			local point = scenario_derby_util.findRandomPoint()
			local tDist = vec3(pos):distance(vec3(point))
			if tDist > 20 then
				scenario_derby_vehicles.vehicleData[vNotToTarget].targetObj = point
				target = "point"
				cCount = cCount + 1
				scenario_derby_vehicles.vehicleData[vNotToTarget].cCount = cCount
				--print(vNotToTarget .. " point")
				--break
			end
			--i = i + 1
		--end
		if target ~= "point" then
			if not vTimeout[user] then
				target = user 
			else 
				for k, vList in pairs(sVehicles) do
					if vList ~= vNotToTarget and not vTimeout[vList] then
						table.insert(targetList, vList)
					end			
				end
				local j = tableChooseRandomKey(targetList)
				target = targetList[j]
			end
		end
	else
		for k, vList in pairs(sVehicles) do
			if vList ~= vNotToTarget and not vTimeout[vList] then
				local vObj = scenetree.findObject(vList)
				if vObj then
					local position =  vObj:getPosition()
					local targetVec = (vec3(position) - vec3(pos)):normalized()
					local i = math.abs(dirVec:dot(targetVec))
						lastbest[vList] = i	
					if i >= bestTargetVec then	
						bestTargetVec = i
					end
				end
			end
		end
		for vList, i in pairs(lastbest) do
			if i == bestTargetVec then  
				table.insert(targetList, vList)
			end
		end
		local j = tableChooseRandomKey(targetList)
		target = targetList[j]	
	end
end
-------------------------------------------------------------------------------------
--GETS DIRECTION AND DISTANCE OF THE TARGET
-------------------------------------------------------------------------------------
local function aiPursuit(targetTemp)	
		local dir = map.objects[map.objectNames[vName]].dirVec
		local pos = map.objects[map.objectNames[vName]].pos
		local vel = map.objects[map.objectNames[vName]].vel
		local tpos = nil
		local tvel = vec3(0,0,0)
		if targetTemp == "point" or target == "point" or target == "line" then
			tpos = scenario_derby_vehicles.vehicleData[vName].targetObj
		else
			tpos = map.objects[map.objectNames[target]].pos
			tvel = map.objects[map.objectNames[target]].vel	
		end
		--debugDrawer:drawSphere(tpos:toPoint3F(), 0.5, ColorF(1,1,0,1))
		local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos, tvel, pos, dir, vel)
		--local curVel = tvel:length()
		--local targetLength = math.max(curVel * 0.6, 8)
		--local halfRemainder = targetLength * 0.5
		--local vec = pos - tpos
		--local vecLen = vec:length()
		--local targetAiMidPos =  tpos + vec * math.min(halfRemainder,vecLen) / vecLen
		-- local targetVec = (tpos - vpos):normalized()
		 local aiDirVec = dir
		return dirDiff, dirTarget
end
-------------------------------------------------------------------------------------
--RESET TARGET 
-------------------------------------------------------------------------------------
local function reset()
	targetSet = false
	target = nil
	--data.targetObj = {}
end
-------------------------------------------------------------------------------------
--CHECK IF WE ARE GONG TO HIT WALLS
-------------------------------------------------------------------------------------
local function wall()
	local wpNum1 = scenario_derby_main.wp1
	local wpNum2 = scenario_derby_main.wp2
	local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
	local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
	--debugDrawer:drawSphere(wp1:toPoint3F(), 0.5, ColorF(1,0,0,0.3))
	--debugDrawer:drawSphere(wp2:toPoint3F(), 0.5, ColorF(1,0,0,0.3))
	local vel = map.objects[map.objectNames[vName]].vel
	local pos = map.objects[map.objectNames[vName]].pos
	
	local speed = vel:length()	
	if speed < 1 then
		vel = vel * 2
	else 
		vel = vel * 1.4
	end
	local ahead = pos + vel
	--debugDrawer:drawLine(pos:toPoint3F(), ahead:toPoint3F(), 0.5, ColorF(1,0,0,0.5))
	--local result = nil
	local dx = nil
	local dy = nil
	local dz = nil
	local lineIntersect = nil
		dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp1.x, wp2.y,true,true)
	if dx == false then
		dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp2.x, wp1.y,true,true)
	end
	if dx == false then
		 dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp2.x, wp1.y,true,true)
	end
	if dx == false then
		dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp1.x, wp2.y,true,true)
	end

	
	if dx ~= false then
		dz = pos.z
		lineIntersect = vec3(dx, dy, dz)
		--print(lineIntersect)
		--debugDrawer:drawSphere(lineIntersect:toPoint3F(), 1.5, ColorF(1,0,0,1))
		return true, lineIntersect
	else
		return false, nil
	end
	
end
-------------------------------------------------------------------------------------
--CHECKS FOR COLLISIONS WITH OBJECTS 
-------------------------------------------------------------------------------------
local function collisionCheck()
	local Arena = scenario_derby_main.Arena
	local result, line = wall()
	--print(result)
	--print(lineIntersect)
	if result == true then
		collision = true
		--debugDrawer:drawSphere(line:toPoint3F(), 0.5, ColorF(1,1,0,1))
		local point = nil
		if Arena == 1 then
			point = scenario_derby_vehicles.vehicleData[vName].startPos
		else
			local wpNum1 = scenario_derby_main.wp1
			local wpNum2 = scenario_derby_main.wp2
			local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
			local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
			local xpos = (wp1.x + wp2.x) / 2
			local ypos = (wp1.y + wp2.y) / 2
			local zpos = wp1.z
			point = vec3(xpos, ypos, zpos)
		end
		scenario_derby_vehicles.vehicleData[vName].targetObj = point
		--scenario_derby_vehicles.vehicleData[vName].line = line
		target = "line"
		targetSet = true
	end
   local circleOffset
   local targetTemp = nil
	if Arena == 1 then
			
			local cr = 7.5
			local cx = 157.99
			local cy = -198.1715
			local z = 58.55
			local circle = vec3(cx,cy, z)
			local offset = vec3(0,0,0)
			--debugDrawer:drawSphere(circle:toPoint3F(), cr, ColorF(1,0,0,0.3))
			--scenario_derby_vehicles.vehicleData[vName].targetTemp = nil
			
			local seg_b = map.objects[map.objectNames[vName]].vel
			local seg_a = map.objects[map.objectNames[vName]].pos

			if seg_b:length() < 1 then
				seg_b = seg_b * 1
			else 
				seg_b = seg_b * 1.3
			end
			seg_b = seg_a + seg_b

			local closest, dist_c = scenario_derby_util.normalPoint(seg_a, seg_b, circle)
			if dist_c > cr then
				if target ~= "point" and target ~= "line" then
					scenario_derby_vehicles.vehicleData[vName].targetObj = nil
				end
			elseif dist_c <= 0 then
			
			else
				local pos = map.objects[map.objectNames[vName]].pos
				local dx = pos.x - circle.x
				local dy = pos.y - circle.y
				local l = math.sqrt(dx * dx + dy * dy)
				local k = (cr * 2) / l
				offset.x = circle.x - dy * k
				offset.y = circle.y + dx * k
				offset.z = circle.z
				print(dist_c)
				--offset = dist_v /dist_c * (cr - dist_c)
				--local t = offset + circle
				--debugDrawer:drawSphere(offset:toPoint3F(), 0.5, ColorF(1,1,1,1))
				scenario_derby_vehicles.vehicleData[vName].targetObj = offset
				targetTemp = "point"
				return targetTemp
			end
	end
end
-------------------------------------------------------------------------------------
--CHANGES THE DIRECTION FOR FORWARE TO BACKWARDS
-------------------------------------------------------------------------------------
local function changeDir()
	if backup == false then
		backup = true
	else 
		backup = false
	end
end
-------------------------------------------------------------------------------------
--SETS THE COUNT FOR HOW LONG WE GO FORWARD OR BACKWARDS
-------------------------------------------------------------------------------------
local function counts(dirTarget)
	local lCount = scenario_derby_vehicles.vehicleData[vName].lCount
	local dtCount = scenario_derby_vehicles.vehicleData[vName].dtCount
	local pos = map.objects[map.objectNames[vName]].pos
	local tpos = nil
	if target == "point" or target == "line" then
		tpos = scenario_derby_vehicles.vehicleData[vName].targetObj
	else
		tpos = map.objects[map.objectNames[target]].pos
	end
	local stopTicks = scenario_derby_main.stopTicks[vName]
	--print(lCount .."lCount " ..dtCount .. "dtCount")
	if collision == false then	
		if stopTicks > 100 then
			lasthit = true
		end				
		if lasthit == true then
			if lCount == 1 then 
				changeDir()
			end
			local hDist = vec3(pos):distance(vec3(tpos))
			if lCount > 150 or hDist > 15 then
				if hitTarget == true then
					reset()
					hitTarget = false
					scenario_derby_vehicles.vehicleData[vName].cCount = 0
				end
				lasthit = false
				lCount = 0
				dtCount = 0
			else
				lCount = lCount + 1
			end
		else
			if target == "point" then
				local pDist = vec3(pos):distance(vec3(tpos))
				if pDist < 14 then
					dtCount = 0 
					lCount = 0
					reset()
				end
			end
			if dtCount < 400 then	
				dtCount = dtCount + 1 
				if dirTarget < 0 then
					backup = true
				else
					backup = false	
				end
			else
				dtCount = 0
				lCount = 0
				reset()
			end
		end
	else
		local lDist = vec3(pos):distance(vec3(tpos))
		if lDist < 20 then
			reset()
			collision = false 
			brake = 0 
			throttle = 0 
		else
			if stopTicks > 100 and stopTicks < 401 then
				if stopTicks == 101 or stopTicks == 400 then
					lasthit = true
					collision = false
				end
			else
				if dirTarget < -0.4 then
					backup = true
					throttle = 0
					brake = 0.7
					if lDist > 10 then
						brake = 0.3	
					end
				else 
					backup = false
					brake = 0
					throttle = 0.8 
					if lDist > 10 then
						throttle = 0.3
					end
				end
			end
		end
	end
	scenario_derby_vehicles.vehicleData[vName].lCount = lCount
	scenario_derby_vehicles.vehicleData[vName].dtCount = dtCount
end
-------------------------------------------------------------------------------------
--AI CODE
-------------------------------------------------------------------------------------
local function update(idName, dt)	
	vName = idName
	if not map.objects[map.objectNames[vName]] then return end
	if not scenario_derby_vehicles.vehicleData[vName] then return end
	targetSet = scenario_derby_vehicles.vehicleData[vName].targetSet
	hitTarget =  scenario_derby_vehicles.vehicleData[vName].hitTarget
	lasthit = scenario_derby_vehicles.vehicleData[vName].lasthit
	backup = scenario_derby_vehicles.vehicleData[vName].backup
	brake = scenario_derby_vehicles.vehicleData[vName].brake
	throttle = scenario_derby_vehicles.vehicleData[vName].throttle
	collision = scenario_derby_vehicles.vehicleData[vName].collision
	target = scenario_derby_vehicles.vehicleData[vName].target
	--if we don't have a target find one
	--if not target then target = user end
	if targetSet ~= true then
		findRandomTarget(vName)  --find a random target
		--targetObj = scenetree.findObject(target)
		targetSet = true
	else
		local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions
			--local targetObj = scenetree.findObject(target)
			--local targetID = targetObj.obj:getID()  --get target id
		local targetID = nil
		if target == "point" or target == "line"  then		
		else
			local to = scenetree.findObject(target)
			if to.obj and to.obj:getID() then
				targetID = to.obj:getID()
			end
		end
		if aiCollisions ~= nil then
			--dump (aiCollisions)
			for k,v in pairs (aiCollisions) do
			--if targetID then print(k.." "..targetID) end
				if k == targetID then		
					hitTarget = true
				end			 
				if not scenario_derby_vehicles.sVehiclesID[k] then
				--print(k)
				else
					lasthit = true
				end 
					
			end	
		end
		local targetTemp = collisionCheck()
		local dirDiff, dirTarget = aiPursuit(targetTemp)
		local bt = nil 
		--local wheelSlip = scenario_derby_wheels.slipHigh()
		counts(dirTarget)
		local vel = map.objects[map.objectNames[vName]].vel
		local pos = map.objects[map.objectNames[vName]].pos
		if collision == false then
			if backup == true  then
				bt = scenario_derby_vehicles.adjustBrakeThrottle(brake,vel, dirTarget)
				throttle = 0
				brake = bt
			else
				bt = scenario_derby_vehicles.adjustBrakeThrottle(throttle,vel, dirTarget)
				brake = 0 
				throttle = bt
			end
		end
	--	if brake > 0 then
		--	pos.y = pos.y - brake
		--	debugDrawer:drawSphere(pos:toPoint3F(), 0.5, ColorF(1,1,1,1))
		--else
		--	pos.y = pos.y + throttle
		--	debugDrawer:drawSphere(pos:toPoint3F(), 0.5, ColorF(1,1,0,1))
	--	end
		
		print(collision)
		print("collision")
		
		
		
		--print(backup)
		--print("backup")
		--print(hitTarget)
		--print("hitTarget") 
		--print(lasthit) 
		--print("lasthit")
		print(brake .. " " .. throttle)
		print(dirTarget.. "dirTarget ".. dirDiff .. "dirDiff ")
		--guihooks.trigger('DerbyPlaceChange', { one = dirTarget, two = throttle, three = brake} )	
		--local vObj = scenetree.findObject(vName)
		--if collision == true then 
		--	vObj:queueLuaCommand('input.event("throttle", '..throttle..', 2)')
		--	vObj:queueLuaCommand('input.event("brake", '..brake..', 2)')
		--end
		
		
		--if vObj then
		--	vObj:queueLuaCommand('input.event("steering", '..-dirDiff..', 1)')
		--end
		--print("throttle".. throttle.. "brake ".. brake.. " " .. vName .. " " ..target.."")
		scenario_derby_vehicles.driveCar(vName,-dirDiff,throttle,brake,0)	
		
	end
	scenario_derby_vehicles.vehicleData[vName].target = target
	scenario_derby_vehicles.vehicleData[vName].targetSet = targetSet 
	scenario_derby_vehicles.vehicleData[vName].hitTarget = hitTarget
	scenario_derby_vehicles.vehicleData[vName].lasthit = lasthit
	scenario_derby_vehicles.vehicleData[vName].backup = backup
	scenario_derby_vehicles.vehicleData[vName].brake = brake
	scenario_derby_vehicles.vehicleData[vName].throttle = throttle
	scenario_derby_vehicles.vehicleData[vName].collision = collision
end

M.update = update


return M