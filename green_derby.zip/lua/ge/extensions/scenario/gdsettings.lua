-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local lookback = 'forward'
local currentcam = nil

local function adjustCamera()
	local camera = gdloader.options.camera
	if camera == true then return end
	local cam = core_camera.getActiveCamName(0)
	if cam == 'driver' then
		gdcallback.driveTrain()
		local drive = gdloader.driveTrain
		if drive and type(drive) == 'table' then
			if drive.gear > 0 then
				if lookback == 'back' or currentcam ~= cam then
					core_camera.rotate_yaw_right(0, 0)
					core_camera.rotate_yaw_left(0, 0)						
					lookback = 'forward' 
				end
			elseif drive.gear < 0 then
				if lookback == 'forward' or currentcam ~= cam then
					core_camera.rotate_yaw_right(1, 0)
					core_camera.rotate_yaw_left(-1, 0)
					lookback = 'back'
				end
			end
		end
		if currentcam ~= cam then
			currentcam = cam
		end
	end
end

local function adjustSettings()
	local fuel = gdloader.options.fuel
	local fire = gdloader.options.fire
	local radiator = gdloader.options.radiator
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
	--extinguish fire on all vehicles
	for _,vName in ipairs(sVehicles) do
		local vObj = scenetree.findObject(vName)
		if vObj then
			if fire == false then
				vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
			end	
		end
	end
	--set the radiator damage and fuel amount only on vehicles still running
	local vehIn = gdloader.vehIn
	for _, v in ipairs(vehIn) do	
		local vObj = be:getObjectByID(v.vid)
		if vObj then
			if fuel == false then
				vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
			end
			local radDamage = tonumber(radiator)
			local low = .0005
			if radDamage > 0 then
				if radDamage > 80 then
					low = .001
				end
				radDamage = radDamage * low
				vObj:queueLuaCommand([[
				local maxrd = ]]..radDamage..[[
				local maxEngineTemp = 0
				local maxCylinderTemp = 0
				local maxOilTemp = 125
				local engine = powertrain.getDevice("mainEngine")
				if engine then
					local ebm = engine.jbeamData.engineBlockMaterial
					if ebm == 'iron' then
						maxEngineTemp = 1000
						maxCylinderTemp = 130
					else
						maxEngineTemp = 600
						maxCylinderTemp = 130
					end
					local cwt = engine.thermals.cylinderWallTemperature
					local ebt = engine.thermals.engineBlockTemperature
					local rd = engine.thermals.radiatorDamage
					local ot = engine.thermals.oilTemperature
					rd = tonumber(rd)
					rd = math.abs(rd)
					maxrd = math.abs(maxrd)
					if rd < maxrd or rd > 3 then
						if ot > maxOilTemp then
							engine.thermals.oilTemperature = maxOilTemp
						end
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp
						end
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp
						end
					end
				end
				]])
			end
		end
	end
end
local function update()
	adjustCamera()
	adjustSettings()
end

M.update = update
return M