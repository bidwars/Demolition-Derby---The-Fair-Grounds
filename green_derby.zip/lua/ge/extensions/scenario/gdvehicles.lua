-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
--local removePartsFile = {} --Table of parts to remove
local startData = {}
M.saveVehicleInfo = {}

local function getPosRot(i)
	local arena = gdloader.options.arena.name
	if not startData[arena] then
		local map = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
		local fn = string.format('levels/'..map..'/prefabs/StartPos.json')
		local file = {}
		if FS:fileExists(fn) then
			startData = readJsonFile(fn)
		else
			startData = {}
		end
	end
	local data = startData[arena]
		if not data then 
			if i == 1 then 
			local pos = gdloader.startPos.pos
			local rot = gdloader.startPos.rot
				return  pos, rot 
			else
				local rot = quat(1, 0, 0, 0)
				local dir = vec3(0, -1, 0)
				local pos = vec3(0,0,0)
				
				local playerVehicleID = be:getPlayerVehicleID(0)
				for k, v in pairs(map.objects) do
					if k == playerVehicleID then
						dir = v.dirVec:normalized()
						rot = quatFromDir(dir)
					end
				end
				local playerVehicle = be:getPlayerVehicle(0)
				local offset = vec3(-dir.y, dir.x, 0)
				pos = vec3(playerVehicle:getPosition()) + offset * 5
				return pos , rot
			end
		end	
		local position = {}
		local rotation = {}
		for j,t in pairs(data) do
			j = tonumber(j)
			if j == i then
				position = t.pos
				rotation = t.rot
				return position, rotation
			end
		end
end
local function setRotation(rot)
	local veh = be:getPlayerVehicle(0)
	if veh then
		local driver = veh.name 
		--print(driver)
		TorqueScript.eval([[
		]]..driver..[[.rotation = "]]..rot.x..' '..rot.y..' '..rot.z..' '..rot.w..[[";]])
	end
end
local function setPlayer(position,rotation)
	local veh = be:getPlayerVehicle(0)
	if veh then
		veh:setPosRot(position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w)
		setRotation(rotation)
	end
end
local function getConfig(veh)
	local vehHeat = gdloader.vehHeat
	local model
	local pcs
	if vehHeat ~= 0 then
		local filename =  "vehicles/heats"..veh.."parts.pc"
		local save = jsonReadFile(filename)
		if not save then
			log("E", "save", "unable to get heats file")
			return
		end
		model = save.model
		--local fileparts = "vehicles/heats"..veh.."parts.pc"
		--serializeJsonToFile(fileparts, save.parts, true)
		pcs = save.pcs --fileparts
	else 
		
		model, pcs = scenario_gdclasses.loadClass()
		local currentHeat = gdloader.currentHeat
		if M.saveVehicleInfo[currentHeat] == nil then
			M.saveVehicleInfo[currentHeat] = {}
			M.saveVehicleInfo[currentHeat][veh] = {}
		end
		M.saveVehicleInfo[currentHeat][veh] =
				{
				vid = 0, 
				model = model, 
				pcs = pcs
				}
	end
	return model, pcs
end
local function loadPosition(vid,k)
	local veh = be:getObjectByID(vid)
	local position, rotation = getPosRot(k)
	if veh then	
		--veh:setPosRot(position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w)
		setRotation(rotation)
	end
end
-------------------------------------------------------------------------------------
--SETS THE PARTS FOR EACH vehicle
-------------------------------------------------------------------------------------
local function createPlayerVehicle()
	local model, pcs = getConfig(1)
	--dump(pcs)	
	local position, rotation = getPosRot(1)
	local options = {config = pcs, pos = position}
	gdloader.vehIn = {}
	core_vehicles.spawnNewVehicle(model, options)
	setPlayer(position,rotation)
end
-------------------------------------------------------------------------------------
--CREATES THE AI VEHICLES FOR THE SCENARIO  
-------------------------------------------------------------------------------------
local function createVehicles()	
	local count =  gdloader.options.opponents
	--local fn = string.format('levels/derby/configs/removeParts.pc')
	--removePartsFile = scenario_gdclasses.readPartsFile(fn)
	createPlayerVehicle()
	for i=1,count do
		--model is the vehicle type, and pcs is the parts Configuration
		local k = i + 1
		local model, pcs = getConfig(k)
		local position, rotation = getPosRot(k)
		local options = {config = pcs, pos = position}
		core_vehicles.spawnNewVehicle(model, options)
		setRotation(rotation)
	end
end
local function loadHeat(vid, k)
	local veh = be:getObjectByID(vid)
	if veh then	
		veh:queueLuaCommand('beamstate.load("vehicles/heats'..k..'.json")')
	end
end


M.loadHeat = loadHeat
M.loadPosition = loadPosition
M.createVehicles = createVehicles


return M