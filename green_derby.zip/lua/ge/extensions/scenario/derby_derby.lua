﻿-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local user = "Hawk"
local helper = require('scenario/scenariohelper')
local aiPos = nil 
local curVelVec = nil
local curVel = nil
local aiDirVec = nil
M.drive = {}
local lookback = 'forward'
local currentcam = nil
require('mathlib')


-------------------------------------------------------------------------------------
--CHECKS FOR COLLISIONS WITH WALLS
-------------------------------------------------------------------------------------
local function checkWalls()
	local wpNum1 = scenario_derby_main.wp1
	local wpNum2 = scenario_derby_main.wp2
	local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
	local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
	local Arena = scenario_derby_main.Arena

	local vData = scenario_derby_vehicles.vehicleData[vName]
		local ahead = lookahead()
		local dx = nil
		local dy = nil
		local dz = nil
		local lineIntersect = nil
		dx, dy = scenario_derby_util.findIntersect(aiPos.x, aiPos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp1.x, wp2.y,true,true)
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(aiPos.x, aiPos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(aiPos.x, aiPos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(aiPos.x, aiPos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp1.x, wp2.y,true,true)
		end

		if dx ~= false then
			dz = aiPos.z
			lineIntersect = vec3(dx, dy, dz)
			vData.collision = true
			local point = nil
			if Arena == 1 then
				point = vData.startPos
			else
				local xpos = (wp1.x + wp2.x) / 2
				local ypos = (wp1.y + wp2.y) / 2
				local zpos = wp1.z
				point = vec3(xpos, ypos, zpos)
			end
			vData.targetObj = point
			vData.target = "line"
			vData.targetSet = true
		else
			local circleOffset
			local targetTemp = nil
			if Arena == 1 then
				local cr = 7.5
				local cx = 157.99
				local cy = -198.1715
				local z = 58.55
				local circle = vec3(cx,cy, z)
				local offset = vec3(0,0,0)	
				local seg_b = curVel
				local seg_a = aiPos

				if seg_b:length() < 1 then
					seg_b = seg_b * 1
				else 
					seg_b = seg_b * 1.3
				end
				seg_b = seg_a + seg_b

				local closest, dist_c = scenario_derby_util.normalPoint(seg_a, seg_b, circle)
				if dist_c > cr then
					if vData.target ~= "point" and vData.target ~= "line" then
						vData.targetObj = nil
				end
				elseif dist_c <= 0 then
			
				else
					local dx = aiPos.x - circle.x
					local dy = aiPos.y - circle.y
					local l = math.sqrt(dx * dx + dy * dy)
					local k = (cr * 2) / l
					offset.x = circle.x - dy * k
					offset.y = circle.y + dx * k
					offset.z = circle.z
					print(dist_c)
					--offset = dist_v /dist_c * (cr - dist_c)
					--local t = offset + circle
					--debugDrawer:drawSphere(offset:toPoint3F(), 0.5, ColorF(1,1,1,1))
					vData.targetObj = offset
					vData.target = "point"
				end
			end
		end
	
end

local function record(t, b)
	local name = nil
	local pos = nil
	local val = nil
	for n,tdata in pairs(t) do
		if tdata.val == b then  
			name = n
			pos = tdata.pos
			val = tdata.val
		end
	end
	return name, pos, val
end
-------------------------------------------------------------------------------------
--RETURNS A TARGET FOR THE AI  *vNotToTarget - set AI to not target itself
-------------------------------------------------------------------------------------
local function findTarget(vNotToTarget)
	local sVehicles = scenario_derby_vehicles.sVehicles  --All Vehicles	
	local target = scenario_derby_vehicles.vehicleData[vNotToTarget].target
	local targetPos = nil
	if not target then
		local bList = {}
		local targetList = {}
		local bestValue = 0
		local targetIndex = 1
		--for i = 1, 3 do
			--local mapNodes = map.getMap()
			--local wp1Pos, wp2Pos = map.findClosestRoad(aiPos)
		--	local wp1 = scenetree.findObject(wp1Pos):getPosition()
			--local wp2 = scenetree.findObject(wp2Pos):getPosition()
			--local rp = scenario_derby_util.findRandomPoint()
			--local rp = vec3(0,0,0)
			--rp.x = (wp1.x + wp2.x) / 2
			--rp.y = (wp1.y + wp2.y) / 2
			--rp.z = aiPos.z 
			--if i == 1 then
				--rp.x = wp1.x + 20
			--elseif i == 2 then
				--rp.x = wp2.x - 20 
			--end
				
			--local rppos = vec3(rp)
			--local rpdist = aiPos:distance(rppos)
			--if rpdist > bestValue then
				--bestValue = rpdist
				--bList['point'..i] = {tpos = rpdist, val = rpdist}
			--end
		--	i = i + 1
		--end
		--local n, p, v = record(bList, bestValue)
		--targetList[targetIndex] = {vName = n, tpos = p, val = v}
		--bList = {}
		--bestValue = 0
		local numV = #sVehicles
		for _,vToTarget in pairs(sVehicles) do
			if vToTarget ~= vNotToTarget then
				local stopTicks = scenario_derby_main.stopTicks[vToTarget]
				if stopTicks < 100 or numV < 2 then
					local tveh = scenetree.findObject(vToTarget)
					local tpos = vec3(tveh.obj:getPosition())
					local tdist = aiPos:distance(tpos)
					if tdist > bestValue then
						bestValue = tdist
						bList[vToTarget] = {tpos = tpos, val = tdist}
					end
				end	
			end
		end
		local n, p, v = record(bList, bestValue)
		--targetIndex = targetIndex + 1
		targetList[targetIndex] = {vName = n, tpos = p, val = v}
		if not targetList[targetIndex] then
			local tveh = scenetree.findObject(user)
			local tpos = vec3(tveh.obj:getPosition())
			bestValue = aiPos:distance(tpos)
			bList[user] = {tpos = tpos, val = tdist}
			n, p, v = record(bList, bestValue)
			targetList[targetIndex] = {vName = n, tpos = p, val = v}
		end
		bList = {}
		bestValue = 0
		for _,vToTarget in pairs(sVehicles) do
			if vToTarget ~= vNotToTarget then
				local tveh = scenetree.findObject(vToTarget)
				local tpos = vec3(tveh.obj:getPosition())
				local targetVec = (tpos - aiPos):normalized()
				local tVec = math.abs(aiDirVec:dot(targetVec))
				if tVec >= bestValue then
					bList[vToTarget] = {tpos = tpos, val = tVec}
					bestValue = tVec
				end
			end	
		end
		n, p, v = record(bList, bestValue)
		targetIndex = targetIndex + 1
		targetList[targetIndex] = {vName = n, tpos = p, val = v}
		--dump(targetList)
		if targetList[1].vName == targetList[2].vName then
			target = targetList[2].vName
			targetPos = targetList[2].tpos
		else
			local tveh = scenetree.findObject(targetList[2].vName)
			local tpos = vec3(tveh.obj:getPosition())
			local targetVec = (tpos - aiPos):normalized()
			local tVec = math.abs(aiDirVec:dot(targetVec))	
			if tVec > .60 and targetList[1] and targetList[1].val > 10 then
				target = targetList[1].vName	
				targetPos = targetList[1].tpos
				--print(tVec)
			else
				if targetList[2].val > .90 then
					target = targetList[2].vName
					targetPos = targetList[2].tpos
					--print(targetList[3].val)
				else 
					--if targetList[1].val >= targetList[2].val then
						--target = targetList[1].vName
						--targetPos = targetList[1].tpos
						--print(targetList[1].val)
					--else
						local rt = tableChooseRandomKey(targetList)
						target = targetList[rt].vName
						targetPos = targetList[rt].tpos
						--print('random')
					--end	
				end
			end	
				
		end	
	scenario_derby_vehicles.vehicleData[vNotToTarget].target = target
	--scenario_derby_vehicles.vehicleData[vNotToTarget].targetObj = targetPos
	return target, targetPos
	end
end	
-------------------------------------------------------------------------------------
--AI CODE
-------------------------------------------------------------------------------------
local function update(mode)	
	local sVehicles = scenario_derby_vehicles.sVehicles
	for k,vName in pairs(sVehicles) do
		if vName == user then
			local cam = core_camera.getActiveCamName(0)
			if cam == 'observer' or cam == 'orbit' then
			else
				scenario_derby_wheels.driveTrain(vName)
				local drive = M.drive
				if drive.gear then
					if drive.gear > 0 then
						if lookback == 'back' or currentcam ~= cam then
							core_camera.lookBack(0)						
							lookback = 'forward' 
						end
					elseif drive.gear < 0 then
						if lookback == 'forward' or currentcam ~= cam then
							core_camera.lookBack(0)
							lookback = 'back'
						end
					end
				end
				if currentcam ~= cam then
					currentcam = cam
				end
			end
		end
	end
	local vInList = scenario_derby_main.vehIn  --Vehicles in without Player
	if vInList then
		for k,v in pairs (vInList) do
			local veh = scenetree.findObject(v)
			aiPos = vec3(veh.obj:getPosition())
			curVelVec = vec3(veh.obj:getVelocity())  --current ai velocity vector
			curVel = curVelVec:length()  -- current ai velocity "speed"
			aiDirVec = vec3(veh.obj:getDirectionVector()) --ai direction vector
			local targetName, targetPos = findTarget(v)
			if targetName ~= nil then
				if targetName == "point1" or targetName == "point2" or targetName == "point3" or targetName == "point" or targetName == "line" then
					helper.queueLuaCommandByName(v, 'greenai.setState({mode="'..mode..'", targetObjectID='..vec3(targetPos)..'})')
				else
					local tveh = helper.getVehicleByName(targetName)
					local tvehID = tveh.obj:getID()
					if not tvehID then print("no target"..v) end
					helper.queueLuaCommandByName(v, 'greenai.setState({mode="'..mode..'", targetObjectID='..tvehID..'})')
				end
			end
		end
	end
	
end	
M.update = update

return M