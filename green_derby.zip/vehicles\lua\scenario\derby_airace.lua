---------------
----------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
local helper = require('scenario/scenariohelper')
local raceMarker = require("scenario/race_marker")
require('mathlib')
local vdata = {}
local tdata = {}
local data = {}
local Arena = 0
M.mapPath = {}
local saveData ={}
M.elec = {}
local pathData = {}
local bestTime = math.huge--17.520500808954
local newbestTime = false
local user = "Hawk"
local newPath = 1
local startTimer = {}
local abs, floor, min, max, stringformat, tableconcat = math.abs, math.floor, math.min, math.max, string.format, table.concat

local function seeks(target)
	local tpos = data.target
	if target then
		tpos = target
	end
	local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos,nil,vdata.pos,vdata.dirVec, vdata.vel)
	return dirDiff, dirTarget
end
local function encodefile(v)
	local vtype = type(v)
	
	-- Handle strings
	if vtype == 'string' then
		return stringformat('%s', v)
	end
	
	-- Handle numbers and booleans
	if vtype == 'number' then
		if v == v + 1 then -- test for inf
		if n == math.huge then
			return '"inf"'
		elseif n == -math.huge then
			return '"-inf"'
		end
		else
		return tostring(v)
		end
	end
	
	-- Handle tables
  if vtype == 'table' then
    if next(v) ~= 1 then
      local tmp = {}
      local tmpidx = 1
      for kk, vv in pairs(v) do
        tmp[tmpidx] = stringformat('%q:%s', kk, encodefile(vv))
        tmpidx = tmpidx + 1
      end
      return stringformat('%s', tableconcat(tmp, ''))
    else
      local vcount = #v
      local tmp = table.new(vcount, 0)
      for i = 1, vcount do
        tmp[i] = encodefile(v[i])
      end
      return stringformat('%s', tableconcat(tmp, ''))
    end
  end
  
  if vtype == 'boolean' then return tostring(v) end

  return "null"

end
local function writeFile(filename,obj)
	local f = io.open(filename, "w")
	if f then
		local content
		content = encodefile(obj)
		
		f:write(content)
		f:close()
		return true
	end
	return false
end
local function lapInfo()
	local p = newPath
	local save = string.format('levels/derby/racedata/road'..p..'.txt')
	local file = {}
	
	for v,t in pairs(M.mapPath[p].road)do
		file[v] = 'node = "'..t.pos.x..' '..t.pos.y..' '..t.pos.z..' '..t.radius..'";\r'
	end
	writeFile(save,file)
end
local function endme()
	if newbestTime == true then
		local p = newPath
		local l = string.format('levels/derby/racedata/lap.json')
		local t = string.format('levels/derby/racedata/time.json')
		serializeJsonToFile(l, bestTime, true)
		serializeJsonToFile(t, M.mapPath[p].road, true)
	end
end
local function separate()
	local sum = nil
	local count = 0 
	local desiredseparation = 5 
	for id,v in pairs(tdata) do
		local d = vdata.pos:distance(v.pos)
		if d > 0 and d < desiredseparation then
		 local diff = (vdata.pos - tdata[id].pos):normalized()
		 diff = diff / d
		 sum = sum + diff
		 count = count + 1
		end
	end
	if count > 0 then
		sum = sum / count
		sum = sum * maxspeed
		local steer = sum - vdata.vel
		return steer
	end

end
local function collisions(vName)
	local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions

	if aiCollisions ~= nil then
			--dump (aiCollisions)
			for k,v in pairs (aiCollisions) do
				local tobj = scenetree.findObjectById(k)
				local pos = tobj:getPosition()
				local posv3 = vec3(pos)
				
				return true, posv3
			end
	else 
		return false
	end
end
local function applyBehaviors(vName)
	local steer, dirTarget = seeks()
	local brake = 0 
	local throttle = data.throttle
	local timeData = scenario_derby_vehicles.timeData[vName]
	--dump(elec)
	local stopTicks = scenario_derby_main.stopTicks[vName]
	--print(stopTicks .. vName)
	local collision, colpos 

	local vel = vdata.vel
	
	local dis = nil
	
	if stopTicks > 60 then
		if throttle > 0 then
			data.collision = true
			data.sDist = vdata.pos
				--scenario_derby_main.stopTicks[vName] = 0
		end
		if brake > 0 then
			dis = 2
				--scenario_derby_main.stopTicks[vName] = 0
		end
	end
	if data.collision == true then
			dis = vdata.pos:distance(data.sDist)
			--print(dis.." Distance")
			if dis > 1.5 then
				steer = 0
				throttle = 0.3
				brake = 0
				if vel:length() > 2 then
					data.collision = false
				end
			else
				steer = 0
				brake = 0.3 
				throttle = 0
			end		
	else
		local lastTime = timeData.lastTime
		if data.cCount >= 12 then
			local wps = 1--data.cCount - 12
			
			throttle = throttle + (wps / data.wheelspeed)
			
			local steerAngle = math.abs(steer) / 1.3
			if throttle > .1 then
				throttle = throttle - (throttle * steerAngle)
			else
				throttle = throttle + (throttle * (1.55 - math.abs(steer)))
			end
		
			if throttle > wps then 
				throttle = wps
			end
	
			--throttle = scenario_derby_vehicles.adjustBrakeThrottle(throttle, vel, dirTarget)
			brake = 0 
		elseif data.cCount >= 11 then
			brake = data.cCount - 11
			--brake = scenario_derby_vehicles.adjustBrakeThrottle(data.brake, vel, 1)
			throttle = 0
			if brake > 1 then 
			brake = 1 
			end
		else
			if vel:length() < 6 then
				throttle = throttle + 0.009
				if throttle > 1 then
					throttle = 1
				end
			else
			throttle = 0
			end
			brake = 0	
		end
	end		
		if vName ~= user then
			scenario_derby_vehicles.driveCar(vName,-steer,throttle,brake,0)--------------------------------------------------------------------------------	
		end
		
		data.throttle = throttle
		data.brake = brake
end
local function trackTime(vName)	
	scenario_derby_wheels.electrics(vName)
	local elec = M.elec
	local pos = vdata.pos
	local brake = data.brake 
	local throttle = data.throttle
	local vel = vdata.vel
	local dist = data.target:distance(pos)
	local timeData = scenario_derby_vehicles.timeData[vName]
	local playerpos = ""..pos.x.." "..pos.y.." "..pos.z..""
	local targetpos = "" ..data.target.x.. " " ..data.target.y.."" 
		
		--Time Data
		
		local timeDiff = timeData.timeDiff   
		--local pointNew = data.dtCount  --dtCount is the next node
		local lastTime = timeData.lastTime
		local lapTime = timeData.lapTime
		local i = timeData.index
		
		--Path Data
		local nodeCount = pathData.cpCount  --current checkpoint
		local lapCount = pathData.lapCount  --current lap
		local cpLast = pathData.cpLast   --previous checkpoint
		local lapLast = pathData.lapLast --previous lap
		
		local bestLap = false
		
		if vName == "ai1" then
			print(data.dtCount.." ".. data.throttle.. " " ..data.cCount)		
			--print(i.. " " .. playerpos)
		end
		
		if data.dtCount == 1 then
			if lastTime == 0 then
				lastTime = scenario.timer  -- start timer
			end
			print("timer start")
			startTimer[vName] = true
		end
		if data.dtCount == nodeCount  then
			print("timmerend")
			local curTime = scenario.timer      --  current  time in scenario curTime
			lapTime = curTime - lastTime  -- add time
			lastTime = curTime
			print(lapTime)
			
			--fastest lap
			if lastTime > 0 and startTimer[vName] == true and lapTime > 10 and lapTime < bestTime  then
				bestTime = lapTime
				newbestTime = true
				print("besttime".. bestTime)
				local p = pathData.line
				p = p + 1
				local num = #saveData[vName]
				for id,q in ipairs(saveData[vName]) do
					local radius = 0
					
					if q.eThrottle > 0.00 then
						radius = 12 + q.eThrottle
					elseif q.eBrake > 0.00 then
						radius = 11 + q.eBrake
					else	
						radius = 10
					end
					if id == 1 then
						M.mapPath[p] = {road = {}}
						radius = 12.2
					end
					local link = id
					if link == num then
						link = 1
					else
						link = link + 1
					end
						
					M.mapPath[p].road[id] = {
						node = id, 
						pos = vec3(q.pPos), 
						radius = radius, 
						links = link, 
						segTags = {}
						}
				end
				--dump(M.mapPath[p].road)
				newPath = p
				lapInfo()
			end
			lapTime = 0
			startTimer[vName] = false
			i = 1
			if pathData.line ~= newPath then
				pathData.line = newPath
				data.lCount = 0
			end
		end	
		
		if i == 1 then
			saveData[vName] = {}
			cpLast = vdata.pos  --save the current pos
		end
		local dis = vdata.pos:distance(cpLast)
		if dis > 2 or i == 1  then
			cpLast = vdata.pos
		
			saveData[vName][i] = { 
				Index = i,
				Name = vName,
				--LapTime = lapTime,
				pPos = playerpos,
				--Pointcp = cpPoint,
				--Vel = vel:length(),
				--TargetDir = dirTarget,
				eThrottle = elec.throttle or 0,
				--Throttle = throttle,
				eBrake = elec.brake or 0,
				--Brake = brake,
				--eSteer = elec.steering or 0,
				--Steer = steer,
				--Tick = stopTicks,
				--tPos = targetpos,
				--tDis = dist
					}
			i = i + 1 
		end
		
		timeData.lastTime =  lastTime
		timeData.lapTime = lapTime
		pathData.cpLast = cpLast
		--pathData.lapLast = lapLast
		timeData.index = i 
		--timeData.timeDiff = timeDiff	
end
local function debug(test)
	if data.target ~= nil then
		local radius = data.cCount 
		debugDrawer:drawSphere(data.target:toPoint3F(), 1, ColorF(1,0,0,0.3))
	end
	if test ~= nil then
		debugDrawer:drawSphere(test:toPoint3F(), 1, ColorF(1,0,0,0.3))
	end
end
local function followPath(vName)
	local p = pathData.line
	local mapData = M.mapPath[p]
	local dis = data.target:distance(vdata.pos)
	local node = mapData.road[data.dtCount]
	if not node then return end
	--dump(node)
	if vName == "ai1" then debug(mapData.road[1].pos) end
	local r = data.cCount
	r = r - 3
	local vel = vdata.vel
	if dis < r then 
		--dump(mapData)
		data.wheelspeed =  dis 
		data.dtCount = node.links
		data.target = node.pos
		data.cCount = node.radius
			
	--go to the next node if we are not moving and the current node is not throttle
	elseif vel:length() < 3 and data.cCount == 10 then 
		data.wheelspeed = dis  --we take the node distance and divide by the throttle amount
		data.dtCount = node.links
		data.target = node.pos
		data.cCount = node.radius
	end	
end
local function startPath(vName)
	local p = pathData.line
	local mapData = M.mapPath[p]
	local bestNode = {}
	local largeDis = math.huge
	local bestdTarget = 0
	if not mapData then return end
	pathData.cpCount = table.maxn(mapData.road)
	print(pathData.cpCount)
	for _,nodeList in ipairs(mapData.road) do
		--if the node list is along the starting line and is a throttle node and it is the longest away from my position. 
				
		if nodeList.radius >= 12.01 then  
					
			local targetVec = (nodeList.pos - vdata.pos):normalized()
			local dirTarget = vdata.dirVec:dot(targetVec)
			if dirTarget > 0 then
				local dis = nodeList.pos:distance(vdata.pos)
				if dis < largeDis then
					if dirTarget > bestdTarget then
						bestNode = nodeList
						largeDis = dis
						bestdTarget = dirTarget
						print(nodeList.node.." "..dis.." "..dirTarget)
					end
				end
			end
		end
	end
			
	if bestNode.node then
		local dis = bestNode.pos:distance(vdata.pos)
		data.wheelspeed = dis
		data.target = bestNode.pos
		data.dtCount = bestNode.node
		data.cCount = bestNode.radius
		data.lCount = 1
	end			
end
local function initial(vName)
 	--map.objects returns objId, isactive, pos, vel, dirVec, dirVecUp, damage, objectCollisions
		vdata = map.objects[map.objectNames[vName]]
		tdata = map.objects 
		data = scenario_derby_vehicles.vehicleData[vName]
		pathData = scenario_derby_vehicles.pathData[vName]
		if not M.mapPath[1] then scenario_derby_race.getRoads() return end
end
local function update(sc)
	scenario = sc
	Arena = scenario_derby_main.Arena 
	--Update Data
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _,vName in ipairs(sVehicles) do
		scenario_derby_race.checkPoints(vName,scenario)
		if vName == user then
			raceMarker.hide(true)
		end
		initial(vName)
			
		if not vdata then return print("novdata") end
		if not tdata then return print("notdata") end	
		if data.lCount == 0 then
			startPath(vName)
		else
			followPath(vName)
		end
		applyBehaviors(vName)
		trackTime(vName)	
	end
end
local function onScenarioRestarted()
	M.mapPath = {}
end

M.update = update
M.endme = endme
M.onScenarioRestarted = onScenarioRestarted 
return M