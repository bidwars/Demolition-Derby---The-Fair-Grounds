angular.module('beamng.apps')

.directive('gdScenario', ['bngApi', function ( bngApi) {
  return {
    templateUrl: 'modules/apps/DerbyScenario/app.html',
    replace: false,
    restrict: 'E',
    scope: false,

    controller: function ($scope, $element, $attrs) {
      var vm = this;

		$scope.startScenario = function() {
		console.log('startScenario');
		var luaCmd = 'gdmain.loadgdscenario()';
		$scope.$emit('CloseMenu');
		bngApi.engineLua(luaCmd);
		};
	},
    controllerAs: 'gdS'
  };
}]);



