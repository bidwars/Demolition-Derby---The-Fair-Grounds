local M = {}
M.vehIn = {}
M.stopTicks = {}
M.mode = 'disabled'
M.options = {}
M.startPos = {}
M.oldScenario = {}
local maxStopTicks = 60-- should be 60
local dropPos = nil
local lastPosition = {}
local helper = require('scenario/scenariohelper')
local playerID
local gdState = 'stop'
M.currentHeat = 1
local vehHeat = 0
M.vehHeat = 0
local totalHeats = 0
M.driveTrain = 0
local nextHeat = 0
M.heatsDone = false
local message = {}
local function deletePrefabs()
	local objName = nil
	local obj = nil
	local unload = false
	local arena = M.options.arena.name
	local objNames = {'derby',arena}
	for _,objName in ipairs(objNames) do
		obj = scenetree[objName]
		if obj then
			unload = true
		end
		if unload == true then 
			obj:unload()
			obj:delete()
			be:reloadCollision()
			log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
			unload = false
		end
	end
end
local function freezeAll(state)
	for _, v in pairs(M.vehIn) do
		local bo = be:getObjectByID(v.vid)
		if bo then
			helper.queueLuaCommand(bo, 'controller.setFreeze('..tostring(state) ..')')
		end
    end
end
local function selection(response)
	M.options = response --M.optionsDefault
	if M.options then 
		for k,v in pairs(M.options) do
			if k == "opponents" then
				v = tonumber(string.match(M.options.opponents, "%d+"))
			end
			M.options[k] = v
		end
	end
	--dump(M.options)
end
local function onVehicleDestroyed(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		--print('unloaded vehicle')
		helper.queueLuaCommand(veh, 'extensions.unload("gdai")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdcallback")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdmain")')
	else
		log('D', 'Delete Vehicle', "Error unloading extensions")
	end
end
local function reset(state)
	--print('reset'..state)
	if gdState == 'stop' then return end  -- need this so it does not break other scenarios
	M.mode = 'disabled'
	for _, v in pairs(M.vehIn) do
		local bo = be:getObjectByID(v.vid)
		if bo then
			local mode = 'stop'
			helper.queueLuaCommand(bo, 'gdai.setState({mode = "'..mode..'"})')
			if state == 2 then
				vehHeat = vehHeat + 1 
				local fileparts = "vehicles/heats"..vehHeat.."parts.pc"
				serializeJsonToFile(fileparts, v, true)
				bo:queueLuaCommand([[
					local vehHeat = ]]..vehHeat..[[
					print("heats"..vehHeat)
					beamstate.save("vehicles/heats"..vehHeat..".json")
				]])
			end
		end
	end
	if gdState ~= 'custom' then
		deletePrefabs()
	end
	M.vehIn = {}
	M.driveTrain = 0
	M.stopTicks = {}
	dropPos = nil
	lastPosition = {}
	if state == 1 then
		vehHeat = 0
		M.vehHeat = 0
		M.currentHeat = 1
		totalHeats = 0
		nextHeat = 0
		M.heatsDone = false
		gdState = 'stop'
	elseif state == 2 then
		gdState = 'heat'
	else
		gdState = 'pre-running'
	end
end
local function onScenarioRestarted()
	reset(1)
end
local function fail(result)
	--print("fail")
	--dump(result)
	scenario_scenarios.finish({failed = result})
end
local function success(result)
	--print("success")
	--dump(result)
	scenario_scenarios.finish({msg = result})
end
local function onRaceResult(finished)
	if gdState == 'running' or gdState == 'custom' or finished then
		local vehIn = #M.vehIn
		local result	
		if vehIn == 1 then
			local v = M.vehIn[1]
			if v.vid == playerID then
				result = 'Congratulations, '..v.driverName..' you are the winner!'
				success(result)
			else
				local mode = 'stop'
				local veh = be:getObjectByID(v.vid)
				helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				result = 'You have been defeated by '..v.driverName..' #'..v.driverNumber..'. '
				fail(result)
			end
			gdState = 'finished'
			if gdState == 'custom' then 
				onScenarioRestarted()
			end
		elseif finished then
			local place = scenario_gdrace.racePlace
			if place and place[1] then
				local driverName
				for k,v in ipairs(M.vehIn) do
					if v.vid == playerID then
						driverName = M.vehIn[k].driverName
					end
				end
				if driverName and place[1] == driverName or place[1].driver == 'You' then
					result = 'Congratulations, '..driverName..' you are the winner! / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' '
					success(result)
				else
					result = '1st Place ' .. place[1].driver..' / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' '
					fail(result)
				end
			else
				result = 'Error loading places'
				fail(result)
			end
			gdState = 'finished'
		end
	end
end
local function breakStick(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		veh:queueLuaCommand(
		[[
			if v.data.flexbodies then
				 for _, flexbody in pairs(v.data.flexbodies) do
					if type(flexbody.mesh) == "string" and (string.find(flexbody.mesh, "stickbreak") ~= nil) then
						--dump(flexbody)
						 if flexbody.fid then
							local f = obj.ibody:getFlexmesh(flexbody.fid)
							if f then
								obj:setMeshAlpha(f, 0)
							end
						--else
							--obj:setMeshNameAlpha(0, flexbody.mesh, true)
						end
					end
				end
			end
		]])	
	end
end
local function addStopTicks(dt)
	for k,v in ipairs(M.vehIn) do
		local veh = be:getObjectByID(v.vid)
		if veh then
			local pos = veh:getPosition()	
			if not M.stopTicks[v.vid] then M.stopTicks[v.vid] = 0 end 
			local stopTicks = M.stopTicks[v.vid] 
			if stopTicks ~= nil then
				if not dropPos then
					dropPos = pos.z
				end
				if lastPosition[v.vid] == nil then lastPosition[v.vid] = pos end
				local distance =  math.abs((pos - lastPosition[v.vid]):len())
				if pos.z < dropPos - 2 and M.options.arena.name == 'Free Fall' then
					stopTicks = maxStopTicks + 1
				elseif distance > 0.4 then
					--vehicles still moving
					lastPosition[v.vid] = pos
					stopTicks = 0			
				else
					--Add one stop tick to the vehicles stop ticks
					stopTicks = stopTicks + dt 
				end
				--If they reach the max stop ticks then they are out
				if stopTicks > maxStopTicks  then	
					if gdState == 'custom' then
						guihooks.trigger('Message', {ttl = 3, msg = 'Player Out', icon = 'directions_bus'})
					else
						breakStick(v.vid)
						if v.vid == playerID then 
							local msg = 'You have been eliminated!'
							helper.flashUiMessage(msg, 4)
						else
							local msg = '#'..v.driverNumber..' - '..v.driverName..' was eliminated!'
							helper.flashUiMessage(msg, 4)
						end
					end
					table.remove(M.vehIn, k)
					helper.queueLuaCommand(veh, 'controller.setFreeze('..tostring(1) ..')')
				end
				M.stopTicks[v.vid] = stopTicks			
			end
		end
	end
end
local function onCountdownStarted()
	local currentUserVehicle = be:getPlayerVehicle(0)
	local currentVehID = currentUserVehicle:getID()
	if currentVehID ~= playerID then
		local veh = be:getObjectByID(playerID)
		if veh then
			be:enterVehicle(0, veh.obj)
			commands.setCameraPlayer()
		end
	end
end
local function onCountdownEnded()
	if gdState == 'start' or gdState == 'custom' then
		scenario_gdrace.initScenario(playerID)
		for _,v in ipairs(M.vehIn) do
			if v.vid ~= playerID then
				local veh = be:getObjectByID(v.vid)
				--helper.queueLuaCommandByName(vName, 'gdai.setState({mode = "'..mode..'", debugMode = "speeds"})')
				if veh then
					if M.mode == 'derby' then
						helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
					else
						scenario_gdrace.setAiRacing(v.vid)
					end
				else
					log('D', 'logTag', 'veh not found on Countdown End', vid)
				end
			end
		end
		freezeAll(0)
	end
	if gdState == 'start' then
		gdState = 'running'
	end
end
local function startScenario()
	local group = M.options.arena.type
		if group == 'Derby' then 
			M.mode = 'derby' 
		else
			M.mode = 'race'
			local uiMods = ui_apps.getList()
			local layouts = ui_apps.getLayouts()
			local appFound = false
			if layouts['scenario'] == nil then
				log('D', 'logTag', 'layout not existing', layout)
					return
			end
			for k,v in pairs(layouts['scenario']) do
				if v.directive == 'derbyPlace' then
					appFound = true
				end
			end
			if appFound == false then
				for k,v in pairs(uiMods) do
					if v.directive == 'derbyPlace' then
						table.insert(layouts.scenario, uiMods[k])
						ui_apps.saveLayouts(layouts)
					end
				end
			end
		end
		scenario_gdrace.setScenario()
		gdState = 'start'
	--	onSpineAnimationFinished_callback = true
		
		extensions.hook('onScenarioChange', scenario) --One last call to let everything know we can start
end
local function onScenarioChange()
	local scenario = scenario_scenarios.getScenario()
	if not scenario then return end
	print(scenario.state)
	print(gdState)
	if scenario.scenarioName == 'gdcommon' then 
		if scenario.state == 'pre-start' or scenario.state =='pre-running' then
			if gdState == 'stop' then
				gdState = 'pre-running'
			end
			if gdState == 'pre-running' and scenario.state == 'pre-running' then
				core_vehicles.removeAll()
			end
		end
		if scenario.state == 'running'and gdState == 'pre-running' then
			gdState = 'pre-start'
	--testing a loading screen
		--guihooks.trigger('ShowApps', false)
		--guihooks.trigger('ChangeState', {state = 'gdloading'})
		
		end
		if scenario.state == 'running'and gdState == 'pre-start' then
			startScenario()
			return
		end
		if scenario.state == 'post' and gdState ~= 'stop' then
			reset(1)
		end
		if scenario.state == 'restart' and gdState ~= 'stop' then
			reset(1)
		end
	end
end
local function onPhysicsUnpaused()
	if gdState == 'paused' or gdState == 'cpaused' then
		scenario_gdvehicles.loadExtensions(2)
		for k,v in ipairs(M.vehIn) do
			if v.vid ~= playerID then
				local veh = be:getObjectByID(v.vid)
				if veh then
					if M.mode == 'derby' then
						helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
					else
						scenario_gdrace.setAiRacing(v.vid)
					end
				end
			end
		end			
		if gdState == 'paused' then
			gdState = 'running'
		else
			
			gdState = 'custom' 
		end
	end
end
local function onPhysicsPaused()
	if gdState == 'running' or gdState == 'custom' then
		if gdState == 'running' then
			gdState = 'paused'
		else
			gdState = 'cpaused'
		end
		for k,v in ipairs(M.vehIn) do
			if v.vid ~= playerID then
				local veh = be:getObjectByID(v.vid)
				if veh then
					local mode = 'stop'
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				end
			end
		end
	end
end
local function onVehicleSpawned(vid)
	--log('D', 'GD On Spawned ID', 'Spawn'..vid)
end
local function setPlayer(renew)
	local vehPick =	M.options.vehicles.name
	--print(vehPick)
	if vehPick == 'Auto Select' and renew == 1 then
		local vehIn = #M.vehIn
		local player = math.random(1,vehIn)
		playerID = M.vehIn[player].vid
	elseif renew == 2 then
		local veh = be:getPlayerVehicle(0)
		if veh then
			playerID = veh:getID()
		else
			playerID = M.vehIn[1].vid
		end
	else
		playerID = M.vehIn[1].vid
			--print(playerID)
	end	
	local veh = be:getObjectByID(playerID)
	if veh then
		be:enterVehicle(0, veh.obj)
		commands.setCameraPlayer()
	end
	--scenario_gdrace.initScenario(playerID)
	M.options.vehicles.name = 'Auto Select'
	return playerID
end
local function restartHeat()
	print('loading saved vehicles')
	for k,v in ipairs(M.vehIn) do	
		scenario_gdvehicles.loadHeat(v.vid, k)
	end
end
local function checkHeats()
	local heat = M.options.heat
	if heat == true and M.heatsDone == false then
		local opponents = M.options.opponents + 1 
		if opponents < 7 then
			totalHeats = 2
		elseif opponents >= 7 then
			totalHeats = 3 	
		end
		local oppHeats =  opponents / totalHeats
		if opponents <= 3 then
			oppHeats = 2
			if opponents == 2 then
				oppHeats = 1
			end
		end
		local vehIn = #M.vehIn	
		if vehIn <= oppHeats then
			print(oppHeats)
			print(M.currentHeat)
			print(totalHeats)
			local currentHeat = M.currentHeat
			M.currentHeat = M.currentHeat + 1
			if currentHeat == totalHeats then
				print('heatsdone')
				reset(2)
				M.vehHeat = vehHeat 
				nextHeat = 2
				M.heatsDone = true
			elseif currentHeat < totalHeats then
				print('next heat')
				reset(2)
				nextHeat = 1
			end 
		end
	end
end
local function heat()
		local count = M.options.opponents + 1
		if M.vehHeat ~= 0 then
			count = M.vehHeat
		end
		local vehIn = #M.vehIn
		if vehIn == count then
			if nextHeat == 1 then
				print("restartHeat")
				nextHeat = 3
			elseif nextHeat == 2 then
				restartHeat()
				nextHeat = 1
			end
		end
end
local msgTimer = 6
local function updateGFX(dt,dtSim)
	if gdState == 'heat' then
		if msgTimer == 6 then
			core_vehicles.removeAll()
		end
		if msgTimer > 0 then
			local msg 
			if nextHeat == 2 then
				msg = 'Loading Feature... Please Wait'
			else
				msg = 'Loading Next Heat... Please Wait'
			end
			msgTimer = msgTimer - dt
			helper.flashUiMessage(msg, 5)
		else
			gdState = 'loading'
			msgTimer = 6
			scenario_gdrace.resetHeat()
			startScenario()
			print("startheat")
		end
	elseif nextHeat == 2 or nextHeat == 1 and gdState ~= 'heat' then
		heat()
	elseif nextHeat == 3 then
		nextHeat = 0	
	elseif nextHeat == 0 then
		if gdState == 'running' or gdState == 'custom' then
			if scenario_gdsettings then
				scenario_gdsettings.update()
			end
			addStopTicks(dt)
			local finished
			if M.mode == 'race' then
				finished = scenario_gdrace.update(playerID)	
			else
				checkHeats()
			end
			onRaceResult(finished)
		end
	end
end
local function Start()
	M.vehIn = {}
	local vehIn = be:getObjectCount()
	playerID = be:getPlayerVehicleID(0)
	local gdvehicles = require('scenario/gdvehicles')
	gdvehicles.loadExtensions(2)
	local vehIn = #M.vehIn
	if vehIn > 1 then
		M.mode = 'derby'
		gdState = 'custom'
		onCountdownEnded()
	end
end
--M.onSpineAnimationFinished = onSpineAnimationFinished
M.pauseScenario = pauseScenario
M.getDriver = getDriver
M.setPlayer = setPlayer
M.selection = selection
M.onVehicleDestroyed = onVehicleDestroyed
M.onCountdownEnded = onCountdownEnded
M.onCountdownStarted = onCountdownStarted
M.onScenarioChange = onScenarioChange
M.onPhysicsPaused = onPhysicsPaused
M.onVehicleSpawned = onVehicleSpawned
M.updateGFX = updateGFX
M.Start = Start
M.onPhysicsUnpaused = onPhysicsUnpaused
M.onPhysicsPaused = onPhysicsPaused
M.onScenarioRestarted = onScenarioRestarted
return M