singleton Material("roofsign_gd-default")
{
    mapTo = "roofsign_gd-default";
    diffuseMap[0] = "@roofsign_gd-default";
    normalMap[0] = "@roofsign_gd-default-normal";
    //doubleSided = "1";
};
singleton Material("roofsign_gd")
{
   mapTo = "roofsign_gd";
   diffuseMap[0] = "roofsign_gd_d.png";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
};