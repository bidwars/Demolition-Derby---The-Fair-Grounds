local M = {}

local function loadScenario(scenarioPath, key)
  -- log('D', logTag, 'Load scenario - '..scenarioPath)
  local processedScenario = nil
  if scenarioPath then
    local scenarioData = readJsonFile(scenarioPath)
    
    if scenarioData then
      -- readJsonFile for valid scenarios returns a table with 1 entry
      if type(scenarioData) == 'table' and #scenarioData == 1 then
	  local levelPath, levelName, _ = path.split( getMissionFilename() )
	   levelPath = string.sub(levelPath, 9)
        processedScenario = scenario_scenariosLoader.processScenarioData(key, scenarioData[1], levelPath)
      end
    else
      log('E', logTag, 'Could not find scenario '..scenarioPath)
    end
  end
  
  return processedScenario
end
local function scenarioStart()
	local path = '/levels/common/scenarios/green_derby_common'
	if not string.find(path, ".json") then
		path = path..".json"
	end
	if not FS:fileExists(path) then
		log('E', logTag, path .." does not exist")
		return
	end
	local newScenario = loadScenario(path)
	scenario_scenariosLoader.start(newScenario)
end

M.scenarioStart = scenarioStart
return M