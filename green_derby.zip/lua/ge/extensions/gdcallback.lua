-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
M.vehIn = {}
local function driveTrainCallback(data)
	gdloader.driveTrain = data
end
local function driveTrain()
	local vehicle = scenetree.findObjectById(be:getPlayerVehicle(0):getID())
	local command = "obj:queueGameEngineLua(string.format('gdcallback.driveTrainCallback(%s)',serialize({gear = drivetrain.gear})))"
	vehicle:queueLuaCommand(command)
end
local function request(vid)
	M.vehIn = gdloader.vehIn
	local vehicle = scenetree.findObjectById(vid)
	vehicle:queueLuaCommand('gdcallback.vehInCallBack(' .. serialize(M.vehIn) .. ')')
end

M.driveTrain = driveTrain
M.driveTrainCallback = driveTrainCallback
M.request = request
return M
