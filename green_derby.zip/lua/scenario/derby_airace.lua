---------------
----------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

math.randomseed(os.time())  --This is used for Random Math.
local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
require('mathlib')
local maxspeed = 4
local vdata = {}
local tdata = {}
local data = {}
local Arena = 0
M.mapPath = {}
local pathData = {}
local helper = require('scenario/scenariohelper')

local function seek(target)
	local tpos = data.target
	if target then
		tpos = target
	end

	local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos,nil,vdata.pos,vdata.dirVec, vdata.vel)
	return dirDiff, dirTarget
end
local function predict(vName)
	local vel = map.objects[map.objectNames[vName]].vel
	local lookahead = vdata.pos + vel
	return lookahead
end 
local function separate()
	local sum = nil
	local count = 0 
	local desiredseparation = 5 
	dump(tdata)
	for id,v in pairs(tdata) do
		local d = vdata.pos:distance(v.pos)
		if d > 0 and d < desiredseparation then
		 local diff = (vdata.pos - tdata[id].pos):normalized()
		 diff = diff / d
		 sum = sum + diff
		 count = count + 1
		end
	end
	if count > 0 then
		sum = sum / count
		sum = sum * maxspeed
		local steer = sum - vdata.vel
		return steer
	end

end
local function gasbrake(dirTarget)
	local max = 1
	local adjust = 0.01
	local lowadjust = 0.03
	local vel = vdata.vel:length()
	local steer = nil
	local vehicleClass = scenario_derby_main.vehicleClass

	if data.target ~= nil then
	if vel > 4 and dirTarget > .96  then 
		 data.throttle = data.throttle + adjust
		 data.brake = 0	
	elseif vel > 16 and dirTarget < .92 and dirTarget > .5 then
		data.throttle = data.throttle - lowadjust
		data.brake = 0
	elseif dirTarget > -0.3 then
		data.throttle = lowadjust * 10
		data.brake = 0
	elseif  dirTarget < -0.3  then
		steer = 1.55
		data.brake = data.brake + adjust
		data.throttle = 0
	end
	end
	if data.throttle >= max then
		data.throttle = max
	elseif data.throttle < adjust then
		data.throttle = 0 
	end
	if data.brake >= max then
		data.brake = max
	elseif data.brake < adjust then
		data.brake = 0
	end
	if vehicleClass == 3  then
		if data.throttle > 0.3 then
			data.throttle = data.throttle / 1.2
		end
	end
	--print(vel)
	--print(dirTarget)
	--print(data.throttle)
	return data.throttle, data.brake
end
local function collisions(vName)
	local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions

	if aiCollisions ~= nil then
			--dump (aiCollisions)
			for k,v in pairs (aiCollisions) do
				local tobj = scenetree.findObjectById(k)
				local pos = tobj:getPosition()
				local posv3 = vec3(pos)
				
				return true, posv3
			end
	else 
		return false
	end
end
local function applyBehaviors(vName)
	local steer, dirTarget = seek()
	local obj = scenetree.findObject(vName)
	local stopTicks = scenario_derby_main.stopTicks[vName]
	--print(stopTicks .. vName)
	local collision, colpos 
	if stopTicks > 20 and data.sDist == 0 then  --vehicle is not moving find out why
		data.startPos = vec3(obj:getPosition())
		collision, colpos = collisions(vName)  --check for collisions with other ai
		if collision == true then
			data.sDist = 1  --collision with car
		else
			data.sDist = 2  --collision with wall or something else
		end
	end

	if data.sDist > 0 then
		local currentPos = vec3(obj:getPosition())
		local movement = (data.startPos - currentPos):length()
		--print(movement.. vName)
		--print(data.sDist)
		if movement > 7  then
			data.sDist = 0
		else
			
			if data.sDist == 1 then
				local coldir = nil  	
				steer, coldir = seek(colpos)	
				if coldir > 0 and data.throttle > 0 then
					dirTarget = -1
				else		
					dirTarget = 1
				end
			else
				if data.brake > 0  then
					dirTarget = 1
				else 
					dirTarget = -1
				end
			end
		end	
	end
		local vel = vdata.vel
		local brake = data.brake or 0.00
		local throttle = data.throttle or 0.00
		if dirTarget > 0 then
			throttle, brake = scenario_derby_vehicles.adjustBrakeThrottle(data.throttle, vel, dirTarget)
			brake = 0 
		else
			brake = scenario_derby_vehicles.adjustBrakeThrottle(data.brake, vel, dirTarget)
			throttle = 0
		end
		data.throttle = throttle
		data.brake = brake

	scenario_derby_vehicles.driveCar(vName,-steer,throttle,brake,0)--------------------------------------------------------------------------------	
end
local function debug(test)
if data.target ~= nil then
   debugDrawer:drawSphere(data.target:toPoint3F(), 2.5, ColorF(1,0,0,0.3))
  end
 if test ~= nil then
    debugDrawer:drawSphere(test:toPoint3F(), 4, ColorF(1,0,0,0.3))
end
end
local function path(vName)
		local predictLoc = predict(vName)	
		local normal = nil
		local largeDis = math.huge
		local a = nil
		local b = nil
		local saveA = nil
		local saveB = nil
		local saveLine = nil
		if data.targetOut == nil then
			data.targetOut = 1
		end
		 data.target = nil
		 if pathData.line == nil then
			pathData.line = math.random(1,2)
		end
		 local p = pathData.line
		-- print(p)
		 local mapData = M.mapPath[p]
		 --dump(mapData)
		for _,raceLine in ipairs(mapData.road) do
			--print(data.targetObj.node)
			 
			a = vec3(raceLine.pos)
			--print(a)	
			local link = raceLine.links
			b = vec3(mapData.road[link].pos)
			--print(b)
			local normalPoint, distance = scenario_derby_util.normalPoint(a,b,predictLoc)
			
			if distance < largeDis then
				--if raceLine.node < data.targetOut + 2 then
				largeDis = distance
				--print(distance)
				--print(normalPoint)
				normal = normalPoint
				saveA = a
				saveB = b
				saveLine =  raceLine
				--if raceLine.links == 1 then 
				--	data.targetOut = 1 
				--else
				--	data.targetOut = raceLine.node
				--end
				--end
			end
			--end
		end
			
				--debugDrawer:drawSphere(normal:toPoint3F(), .5, ColorF(1,0,0,1))
			
			local pathseg = (saveB - saveA):normalized()
			--local radius = saveLine.radius
			local radius = saveLine.radius   --saveLine.radius / 2
			pathseg = pathseg * radius		
			data.target = normal + pathseg
			--debugDrawer:drawSphere(data.target:toPoint3F(), .5, ColorF(1,0,0,0.3))
			--print(saveLine.links)
			--print(saveLine.node)
			--data.targetObj.node = saveLine.links
			--debug(predictLoc)
end
local function intial(vName)
 	--map.objects returns objId, isactive, pos, vel, dirVec, dirVecUp, damage, objectCollisions
		vdata = map.objects[map.objectNames[vName]]
		tdata = map.objects 
		data = scenario_derby_vehicles.vehicleData[vName]
		pathData = scenario_derby_vehicles.pathData[vName]
		if not M.mapPath[1] then scenario_derby_race.getRoads() return end
end

local function update(vName)	
		Arena = scenario_derby_main.Arena 
		--Update Data
		intial(vName)
		if not vdata then return end
		if not tdata then return end
		path(vName)
		
		
		applyBehaviors(vName)
end

M.update = update

return M