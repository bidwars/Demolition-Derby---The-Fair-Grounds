local logTag = 'gdscenariosLoader'

local M = {}

M.scenarioModules   = {'scenario_scenarios', 'scenario_waypoints', 'statistics_statistics', 'scenario_raceUI', 'scenario_raceGoals'}

local displayedRestrictMessage = nil
local function processScenarioData(scenarioKey, scenarioData, scenarioFilename)
    scenarioData.scenarioKey = scenarioKey
-------------------Change for Derby--------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
	local map = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
	
	--dump(scenarioData)
    if scenarioFilename then
      scenarioData.sourceFile = scenarioFilename
      scenarioData.official = isOfficialContent(FS:getFileRealPath(string.sub(scenarioFilename,0)))
      scenarioData.levelName = map--string.gsub(scenarioFilename, "(.*/)(.*)/scenarios/(.*)%.json", "%2")
----------------add for derby-------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------
  -- improve the data a little bit
      scenarioData.mission = 'levels/'..scenarioData.levelName..'/main.level.json'

      if not FS:fileExists(scenarioData.mission) then
        -- Fallback to old MIS file
        scenarioData.mission = 'levels/'..scenarioData.levelName..'/'..scenarioData.levelName..'.mis'
      end

      if not FS:fileExists(scenarioData.mission) then
        -- Fallback to level directory
        scenarioData.mission = 'levels/'..scenarioData.levelName..'/'
        if not FS:directoryExists(scenarioData.mission) then log('E', logTag, scenarioData.levelName.." scenario file not found") end
      end

      scenarioData.scenarioName = string.gsub(scenarioFilename, "(.*/)(.*)%.json", "%2")
      scenarioData.directory = string.gsub(scenarioFilename, "(.*)/(.*)%.json", "%1")
    end

    local tmp = 'levels/' .. scenarioData.levelName .. '/info.json'
    if FS:fileExists(tmp) then
      local infoJson = jsonReadFile(tmp)
      if infoJson and infoJson.title then
        scenarioData.map = infoJson.title
      end
    end

    -- below are the defaults for a scenario including automatic file guessing for some fields
    if not scenarioData.vehicles then
      scenarioData.vehicles = {scenario_player0 = {playerUsable = true, startFocus = true}, ['*'] = {playerUsable = false}}
    end

    if not scenarioData.difficulty then
      scenarioData.difficulty = 'easy'
    end
    scenarioData.extensions = scenarioData.extensions or {}
    table.insert(scenarioData.extensions, {name=scenarioData.scenarioName, optional=true}) -- try to load an extension with the scenarioname by default

    -- figure out if a html start file is existing
    local htmldiscovered = false
    if not scenarioData.startHTML then
      scenarioData.startHTML = scenarioData.scenarioName .. '.html'
      htmldiscovered = true
    end
    if not FS:fileExists(scenarioData.directory.."/"..scenarioData.startHTML) then
      if not htmldiscovered then
        log('W', logTag, 'start html not found, disabled: ' .. scenarioData.startHTML)
      end
      scenarioData.startHTML = nil
    end


    if not scenarioData.introType then
        scenarioData.introType = 'htmlOnly'
    end

    -- figure out the prefabs: add default and check them
    if not scenarioData.prefabs then
      scenarioData.prefabs = {}
    end

    -- try to load some defaults
    tmp = scenarioData.directory .. "/" .. scenarioData.scenarioName .. '.prefab'
    if FS:fileExists(tmp) then
      table.insert(scenarioData.prefabs, tmp)
    end

    tmp = scenarioData.directory .. "/" .. scenarioData.scenarioName .. '_intro' .. '.prefab'
    if FS:fileExists(tmp) then
      table.insert(scenarioData.prefabs, tmp)
    end

    local levelPath = 'levels/' .. scenarioData.levelName
    tmp = levelPath .. "/" .. scenarioData.scenarioName .. '.prefab'
    if FS:fileExists(tmp) then
      table.insert(scenarioData.prefabs, tmp)
    end

    local np = {}
    for _,p in pairs(scenarioData.prefabs) do
      if FS:fileExists(p) then
        if not tableContainsCaseInsensitive(np, p) then
          table.insert(np, p)
        end
      else
        tmp = levelPath.."/"..p..'.prefab'
        local dirtmp = scenarioData.directory .. "/"..p..'.prefab'
        if not tableContainsCaseInsensitive(np, tmp) and FS:fileExists(tmp) then
          table.insert(np, tmp)
        elseif not tableContainsCaseInsensitive(np, dirtmp) and FS:fileExists(dirtmp) then
          table.insert(np, dirtmp)
        else
          log('E', logTag, 'Prefab not found: ' .. tostring(p) .. ' - DISABLED')
          log('E', logTag, 'Used in scenario: ' .. tostring(scenarioFilename))
        end
      end
    end
    scenarioData.prefabs = np

    -- figure out the previews automatically and check for errors
    if not scenarioData.previews then
      local tmp = FS:findFilesByRootPattern(scenarioData.directory.."/", scenarioData.scenarioName..'*.jpg', 0, true, false)
      local matchedScenarios = FS:findFilesByRootPattern(scenarioData.directory.."/", scenarioData.scenarioName..'*.json', 0, true, false)
      local otherScenarios = {}
      for i,v in ipairs(matchedScenarios) do
        local otherScenarioName = string.gsub(v, "(.*/)(.*)%.json", "%2")
        if otherScenarioName ~= scenarioData.scenarioName then
          table.insert(otherScenarios, otherScenarioName)
        end
      end

      scenarioData.previews = {}
      for _, p in pairs(tmp) do
        if string.startswith(p, scenarioData.directory) then
          local imageFilename = string.sub(p, string.len(scenarioData.directory) + 2, string.len(p) - 4)
          local foundClash = false
          for i,otherScenarioName in ipairs(otherScenarios) do
            if imageFilename == otherScenarioName then
              foundClash = true
            end
          end
          if not foundClash then
            table.insert(scenarioData.previews, imageFilename..'.jpg')
          end
        end
      end
    end
    np = {}
    for _,p in pairs(scenarioData.previews) do
        table.insert(np, imageExistsDefault(scenarioData.directory.."/"..p))
    end
    if tableSize(np) == 0 then
       table.insert(np, imageExistsDefault(''))
    end
    scenarioData.previews = np
    if #scenarioData.previews == 0 then
      log('W', logTag, 'scenario has no previews: ' .. tostring(scenarioData.scenarioName))
    end

    if not scenarioData.playersCountRange then scenarioData.playersCountRange = {} end
    if not scenarioData.playersCountRange.min then scenarioData.playersCountRange.min = 1 end
    scenarioData.playersCountRange.min = math.max( 1, scenarioData.playersCountRange.min )
    if not scenarioData.playersCountRange.max then scenarioData.playersCountRange.max = scenarioData.playersCountRange.min end
    scenarioData.playersCountRange.max = math.max( scenarioData.playersCountRange.min, scenarioData.playersCountRange.max )

    scenarioData.extraTime = 0

    -- set defaults if keys are missing
    scenarioData.lapCount = scenarioData.lapCount or 1
    scenarioData.whiteListActions = scenarioData.whiteListActions or {"default_whitelist_scenario"}
    scenarioData.blackListActions = scenarioData.blackListActions or {"default_blacklist_scenario"}
    scenarioData.radiusMultiplierAI = scenarioData.radiusMultiplierAI or 1

    local restrictScenarios = settings.getValue("restrictScenarios")
    if restrictScenarios == nil then restrictScenarios = true end
    if (shipping_build and campaign_campaigns and campaign_campaigns.getCampaignActive()) then restrictScenarios = true end

    if not restrictScenarios then
      if not displayedRestrictMessage then
        displayedRestrictMessage = true
        log('W', logTag, '**** Restrictions on Scenario Turned off in game settings. Removing restrictions. ****')
      end
      scenarioData.whiteListActions = {}
      scenarioData.blackListActions = {"loadHome", "saveHome", "recover_vehicle", "reload_vehicle", "reload_all_vehicles"}
    end

    -- process lapConfig
    scenarioData.BranchLapConfig = scenarioData.BranchLapConfig or scenarioData.lapConfig or {}
    scenarioData.lapConfig = {}
    for i, v in ipairs(scenarioData.BranchLapConfig) do
      if type(v) == 'string' then
        table.insert(scenarioData.lapConfig, v)
      end
    end
    scenarioData.initialLapConfig = deepcopy(scenarioData.lapConfig)

    if scenarioData.attemptsInfo then
      scenarioData.attemptsInfo.allowedAttempts = scenarioData.attemptsInfo.allowedAttempts or 0
      scenarioData.attemptsInfo.delayPerAttempt = scenarioData.attemptsInfo.delayPerAttempt or 1
      scenarioData.attemptsInfo.allowVehicleSelectPerAttempt = scenarioData.attemptsInfo.allowVehicleSelectPerAttempt or false
      scenarioData.attemptsInfo.failAttempts = scenarioData.attemptsInfo.failAttempts or {}
      scenarioData.attemptsInfo.completeAttempt = scenarioData.attemptsInfo.completeAttempt or {}
      scenarioData.attemptsInfo.attemptNumber = 0
      scenarioData.attemptsInfo.waitTimerStart = false
      scenarioData.attemptsInfo.waitTimer = 0
      scenarioData.attemptsInfo.waitTimerActive = false
      scenarioData.attemptsInfo.currentAttemptReported = false
    end
    return scenarioData
end
------------------------------------------------------------------
--derby change-----------------------------------------------
local function derbyLoad()
	
		local veh = be:getPlayerVehicle(0)
		if veh then
			--print('startPos')
			gdloader.startPos = {pos = veh:getPosition(), rot = veh:getRotation()}
			--dump(gdloader.startPos)
		end
end
----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
local function loadScenario(scenarioPath, key)
  -- log('D', logTag, 'Load scenario - '..scenarioPath)
  local processedScenario = nil
  if scenarioPath then
    local scenarioData = jsonReadFile(scenarioPath)

    if scenarioData then
      -- jsonReadFile for valid scenarios returns a table with 1 entry
      if type(scenarioData) == 'table' and #scenarioData == 1 then
        processedScenario = processScenarioData(key, scenarioData[1], scenarioPath)
      end
    else
      log('E', logTag, 'Could not find scenario '..scenarioPath)
    end
  end

  return processedScenario
end
------------------------------------------------------------------
--derby change-----------------------------------------------
local function scenarioStart()
	--print('startDerby2')
	
	derbyLoad()
	local path = '/levels/derby/scenarios/gdcommon'
	if not string.find(path, ".json") then
		path = path..".json"
	end
	if not FS:fileExists(path) then
		log('E', logTag, path .." does not exist")
		return
	end
	local newScenario = loadScenario(path)
	scenario_scenariosLoader.start(newScenario)
end

------------------------------------------------------------------------------
------------------------------------------------------------------------------
--We don't need the rest of the scenariosLoader file.

M.scenarioStart = scenarioStart
return M