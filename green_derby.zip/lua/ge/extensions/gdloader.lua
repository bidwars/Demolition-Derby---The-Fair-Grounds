local M = {}
M.vehIn = {}
M.driveTrain = 0
M.stopTicks = {}
M.mode = 'disabled'
M.Arena = 3
M.vehicleClass = 3
M.includeMods = 1
M.vehicleConfig = 3
M.vehiclePick = 1
M.vehicleCountEntered = 4
M.startPos = {}
local maxStopTicks = 60  -- should be 60
local dropPos = nil
local lastPosition = {}
local lookback = 'forward'
local currentcam = nil
local helper = require('scenario/scenariohelper')
local driverList = {"The Big Buffoon","Mayhem Mike","Gentle Bud","Sir NoMercy","Rawhide Billie","Cushion Charlie","Mr. Gumby","Ms. Gumby","Montster","Collissione Carbonara","Motor Man Jackson","Erwin the Eliminator","Softcore James","Morning Hollywood","Crashtest Tommy","Hurricane Houston"}
local playerID
local gdState = 'stop'
local driverOut = {}
local newScenario = nil

local function getArena(arena)
	local show
	local levelPath, levelName, _ = path.split( getMissionFilename() )
	--print(getMissionFilename())
	local level = string.sub(levelPath, 8)
	if string.find(level, "derby") then
		show = 1
		M.Arena = tonumber(arena) or 3
		print("Arena "..M.Arena)
	else
		show = 0
		M.Arena = 0
	end
	return show
end
local function selection(opponents, classes, mods, vehicles, states)
	print("Opponents "..opponents)
	print("Class "..classes)
	print("Mods "..mods)
	print("State "..states)
	print("Vehicle List "..vehicles)
	M.vehicleCountEntered = tonumber(opponents) or 4
	M.vehicleClass = tonumber(classes) or 3
	M.includeMods = tonumber(mods) or 1
	M.vehicleConfig = tonumber(states) or 3
	M.vehiclePick = tonumber(vehicles) or 1
end
local function setPlayer()
	local player = be:getObjectByID(playerID)
	if player then
		be:enterVehicle(0, player.obj)
		commands.setCameraPlayer()	
	end
end
local function onVehicleDestroyed(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		--print('unloaded vehicle')
		helper.queueLuaCommand(veh, 'extensions.unload("gdai")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdcallback")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdmain")')
	else
		log('D', 'Delete Vehicle', "Error unloading extensions")
	end
end
local function reset(state)
	if state ~= 1 then return end
	M.mode = 'disabled'
	
	--core_vehicles.removeAllExceptCurrent()
	M.vehIn = {}
	M.driveTrain = 0
	M.stopTicks = {}
	dropPos = nil
	lastPosition = {}
	lookback = 'forward'
	currentcam = nil
	driverOut = {}
	gdState = 'stop'

	--[[if M.Arena ~= 0 then
			local objName = nil
			local obj = nil
			local unload = false
			objName = "dirttrackwp"	
			obj = scenetree[objName]
			if obj then
				unload = true
			else
				objName = "fig8concretewp"
				obj = scenetree[objName]
				if obj then
					unload = true
				end		
			end
			if unload == true then 
				obj:unload()
				obj:delete()
	
				be:reloadCollision()
				log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
			end
		end--]]
end
local function onWorldReadyState(state)
	--reset(state)
end
local function onScenarioRestarted()
	reset(1)
end
local function getDriver(vid)
	local numOut = #driverOut
	local driver = {}
		for _,driverName in ipairs(driverList) do
			if NumOut then
				for _,nameOut in ipairs(driverOut) do
					if nameOut ~= driverName then
						table.insert(driver, driverName) 
					end
				end
			else
				table.insert(driver, driverName)
			end
		end
	driverOut[vid] = driver[tableChooseRandomKey(driver)] 
	return driverOut[vid]
end
local function fail(result)
	--print("fail")
	scenario_scenarios.finish({failed = result})
end
local function success(result)
	--print("success")
	scenario_scenarios.finish(result)
end
local function onRaceResult()
	if gdState == 'running' or gdState == 'custom' then
		local vehIn = #M.vehIn
		local raceEnd = false
		local place 
		if M.mode == 'race' then
			for k,vid in ipairs(M.vehIn) do
				--local scenario = scenario_scenarios.getScenario()
				--local lap = scenario_gdrace.pathData[vid].lapCount
				--if lap > scenario.lapCount then
				--	raceEnd = true
				--	place = scenario_gdrace.racePlace
					--scenario_derby_airace.lapWrite()  --need a new function to write the lap times.
				--end
			end
		end
		if vehIn == 1 or raceEnd == true then
			for k,vid in ipairs(M.vehIn) do	
				local result = nil
				if vid == playerID then
					result = {msg = 'You Won!'}
					if M.mode == 'race' then
						result = {msg = '1st Place! ' .. place[1].driver..' / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' ' }
					end
					success(result)
				else
					local winner
					if M.mode == 'race' then
						winner = place[1].driver
					else 
						winner = getDriver(vid)
					end
					result = 'The driver '..winner..' has won.'
					fail(result)
				end	
			end
			if gdState == 'custom' then 
				onScenarioRestarted()
			end
		end
	end
end
local function adjustCamera()
	local cam = core_camera.getActiveCamName(0)
	
	if cam == 'observer' or cam == 'orbit' then
	elseif cam == 'onboard.driver' or 'onboard.hood' then
		gdcallback.driveTrain()
		local drive = M.driveTrain
		if drive and type(drive) == 'table' then
			if drive.gear > 0 then
				if lookback == 'back' or currentcam ~= cam then
					core_camera.lookBack(0)						
					lookback = 'forward' 
				end
			elseif drive.gear < 0 then
				if lookback == 'forward' or currentcam ~= cam then
					core_camera.lookBack(0)
					lookback = 'back'
				end
			end
		end
		if currentcam ~= cam then
			currentcam = cam
		end
	end
end
local function adjustSettings()
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do	
		local vObj = scenetree.findObject(vName)
		if vObj then			
			vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
			vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
			vObj:queueLuaCommand([[
			local maxEngineTemp = 0
			local maxCylinderTemp = 0
			local maxOilTemp = 140
			local engine = powertrain.getDevice("mainEngine")
			if engine then
				local cwt = engine.thermals.cylinderWallTemperature
				local ebt = engine.thermals.engineBlockTemperature
				local rd = engine.thermals.radiatorDamage
				local ebm = engine.jbeamData.engineBlockMaterial
				local ot = engine.thermals.oilTemperature
				if rd == 0 then
					if ot > maxOilTemp then
						engine.thermals.oilTemperature = maxOilTemp
					end
					if ebm == "iron" then 
						maxEngineTemp = 1000
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 1100
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					else
						maxEngineTemp = 600
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 620
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					end
				end
			end
			]])
		end
	end
end
local function freezeAll(state)
	for k, vid in pairs(M.vehIn) do
		local bo = be:getObjectByID(vid)
		if bo then
			helper.queueLuaCommand(bo, 'controller.setFreeze('..tostring(state) ..')')
		end
    end
end
local function removeRecord(t,id)
	local i = nil
	for k,v in ipairs(t) do
		if v == id then
			i = k
		end
	end
	table.remove(t, i)
end
local function addStopTicks(dt)
	for k, vid in ipairs(M.vehIn) do	
		local veh = be:getObjectByID(vid)
		if veh then
			local pos = veh:getPosition()	
			if not M.stopTicks[vid] then M.stopTicks[vid] = 0 end 
			local stopTicks = M.stopTicks[vid] 
			if stopTicks ~= nil then
				if not dropPos then
					dropPos = pos.z
				end
				if lastPosition[vid] == nil then lastPosition[vid] = pos end
				local distance =  math.abs((pos - lastPosition[vid]):len())
				if pos.z < dropPos - 2 and M.Arena == 1 then
					stopTicks = maxStopTicks + 1
				elseif distance > 0.4 then
					--vehicles still moving
					lastPosition[vid] = pos
					stopTicks = 0			
				else
					--Add one stop tick to the vehicles stop ticks
					stopTicks = stopTicks + dt 
				end
				--If they reach the max stop ticks then they are out
				if stopTicks > maxStopTicks  then	
					if gdState == 'custom' then
						guihooks.trigger('Message', {ttl = 3, msg = 'Player Out', icon = 'directions_bus'})
					else
						local out = getDriver(vid)
						if vid == playerID then 
							local msg = 'You have been called out!'
							helper.flashUiMessage(msg, 4)
						else
							local msg = out .. ' has been called out!'
							helper.flashUiMessage(msg, 4)
						end
					end
					removeRecord(M.vehIn, vid)
					helper.queueLuaCommand(veh, 'controller.setFreeze('..tostring(1) ..')')
				end
				M.stopTicks[vid] = stopTicks			
			end
		end
	end
end
local function onCountdownEnded()
	if gdState == 'start' or gdState == 'custom' then
		for _,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				--helper.queueLuaCommandByName(vName, 'gdai.setState({mode = "'..mode..'", debugMode = "speeds"})')
				if veh then
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
				end
			end
		end
		freezeAll(0)
	end
	if gdState == 'start' then
		gdState = 'running'
	end
end
local function onScenarioChange()
	local scenario = scenario_scenarios.getScenario()
	if not scenario then return end
	--print(scenario.state)
	--print(gdState)
	if scenario.state == 'pre-start' or scenario.state =='pre-running' then
		if gdState == 'stop' then
			if scenario.scenarioName == 'gdcommon' then 
				gdState = 'pre-start'
			end
		end
		if gdState == 'pre-start' then
			gdState = 'pre-running'
			scenario_gdclasses.modelName()
			scenario_gdvehicles.partsConfig(1)
		end
	end
	if scenario.state == 'running'and gdState == 'pre-running'  then	
		if M.Arena < 7 then 
			M.mode = 'derby' 
		else
			M.mode = 'race'
		end
		scenario_gdrace.createRoads()	
		gdState = 'start'
		extensions.hook('onScenarioChange', scenario)
		return
	end
	if scenario.state == 'post' then
		reset(1)
	end
	if scenario.state == 'restart' then
		reset(1)
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					local mode = 'stop'
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				end
			end
		end
	end
end
local function onPhysicsUnpaused()
	if gdState == 'paused' or gdState == 'cpaused' then
		M.vehIn = {}
		playerID = be:getPlayerVehicleID(0)
		for i = 0, be:getObjectCount() do
			local veh = be:getObject(i)
			if veh then
				table.insert(M.vehIn, veh:getID())
				helper.queueLuaCommand(veh, 'extensions.load("gdmain")')
			end
		end
		setPlayer()
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
				end
			end
		end			
		if gdState == 'paused' then
			gdState = 'running'
		else
			
			gdState = 'custom' 
		end
	end
end
local function onPhysicsPaused()
	if gdState == 'running' or gdState == 'custom' then
		if gdState == 'running' then
			gdState = 'paused'
		else
			gdState = 'cpaused'
		end
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					local mode = 'stop'
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				end
			end
		end
	end
end
local function loadExtensions(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		helper.queueLuaCommand(veh, 'extensions.load("gdmain")')
	else
		log('D', 'scenario', "Error Finding Vehicle")
	end
end
local function setVehicles(vid)
	table.insert(M.vehIn, vid)
	local vehIn = #M.vehIn
	if vehIn == 1 then		
		playerID = vid
	end
end
local function onVehicleSpawned(vid)
	loadExtensions(vid)
	if gdState ~= 'stop' and gdState ~= 'custom' then		
		setVehicles(vid)
		setPlayer()
		--freezeAll(1)
	end
end
local function updateGFX(dtReal) 
	if gdState == 'running' or gdState == 'custom' then
		if M.mode == 'race' then
			--guihooks.trigger('ShowApps', true)
			scenario_gdrace.update(playerID)
		end
		adjustCamera()
		adjustSettings()
		addStopTicks(dtReal)
		onRaceResult()	
	end
end

local function Start()
	M.vehIn = {}
	local vehIn = be:getObjectCount()
	playerID = be:getPlayerVehicleID(0)
	for i = 0, vehIn do
		local veh = be:getObject(i)
		if veh then
			table.insert(M.vehIn, veh:getID())
		end
	end
	if vehIn > 1 then
		setPlayer()
		guihooks.trigger('Message', {ttl = 3, msg = 'Get Ready', icon = 'directions_bus'})
		guihooks.trigger('Message', {ttl = 3, msg = 'Set', icon = 'directions_bus'})
		guihooks.trigger('Message', {ttl = 3, msg = 'Go!', icon = 'directions_bus'})
		
		M.mode = 'derby'
		gdState = 'custom'
		onCountdownEnded()
	end
end

M.getDriver = getDriver
M.selection = selection
M.getArena = getArena
M.onVehicleDestroyed = onVehicleDestroyed
M.onWorldReadyState = onWorldReadyState
M.onCountdownEnded = onCountdownEnded
M.onScenarioChange = onScenarioChange
M.onPhysicsPaused = onPhysicsPaused
M.onVehicleSpawned = onVehicleSpawned
M.updateGFX = updateGFX
M.Start = Start
M.onPhysicsUnpaused = onPhysicsUnpaused
M.onPhysicsPaused = onPhysicsPaused
M.onScenarioRestarted = onScenarioRestarted

return M