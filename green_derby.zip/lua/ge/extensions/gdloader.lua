local M = {}
M.vehIn = {}

M.stopTicks = {}
M.mode = 'disabled'
M.options = {}
M.startPos = {}
local maxStopTicks = 50  -- should be 60
local dropPos = nil
local lastPosition = {}
local helper = require('scenario/scenariohelper')
local driverList = {"The Big Buffoon","Mayhem Mike","Gentle Bud","Sir NoMercy","Rawhide Billie","Cushion Charlie","Mr. Gumby","Ms. Gumby","Monster","Collision Carbonara","Motor Man Jackson","Erwin the Eliminator","Softcore James","Morning Hollywood","Crash Test Tommy","Hurricane Houston"}
local playerID
local gdState = 'stop'
local driverOut = {}
local currentHeat = 0
--M.oppHeats = 0
local vehHeat = 0
M.vehHeat = 0
local totalHeats = 0
M.driveTrain = 0
local nextHeat = 0
local message = {}
local function selection(response)
	M.options = response --M.optionsDefault
	if M.options then 
		for k,v in pairs(M.options) do
			if k == "opponents" then
				v = tonumber(string.match(M.options.opponents, "%d+"))
			end
			M.options[k] = v
		end
	end
	dump(M.options)
end
local function setPlayer()
	local player = be:getObjectByID(playerID)
	if player then
		be:enterVehicle(0, player.obj)
		commands.setCameraPlayer()	
	end
end
local function onVehicleDestroyed(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		--print('unloaded vehicle')
		helper.queueLuaCommand(veh, 'extensions.unload("gdai")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdcallback")')
		helper.queueLuaCommand(veh, 'extensions.unload("gdmain")')
	else
		log('D', 'Delete Vehicle', "Error unloading extensions")
	end
end
local function freezeAll(state)
	for k, vid in pairs(M.vehIn) do
		local bo = be:getObjectByID(vid)
		if bo then
			helper.queueLuaCommand(bo, 'controller.setFreeze('..tostring(state) ..')')
		end
    end
end
local function reset(state)
	--if state ~= 1 then return end
	print('reset'..state)
	M.mode = 'disabled'
	--local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for k, vid in pairs(M.vehIn) do
		local bo = be:getObjectByID(vid)
		if bo then
			local mode = 'stop'
			helper.queueLuaCommand(bo, 'gdai.setState({mode = "'..mode..'"})')
			if state == 2 then
					
				vehHeat = vehHeat + 1 
				--local savePath = string.format('vehicles/heats'..tostring(saveVeh)..'.json')
				bo:queueLuaCommand([[
					local vehHeat = ]]..vehHeat..[[
					print("heats"..vehHeat)
					beamstate.save("vehicles/heats"..vehHeat..".json")
					]])		
			end
		end
	end
	M.vehIn = {}
	M.driveTrain = 0
	M.stopTicks = {}
	dropPos = nil
	lastPosition = {}
	driverOut = {}
	
	if reset == 1 then
		vehHeat = 0
		currentHeat = 0
		totalHeats = 0
		nextHeat = 0
		gdState = 'stop'
	else 
		gdState = 'pre-running'
	end
	
end
local function onScenarioRestarted()
	reset(1)
end
local function getDriver(vid)
	local numOut = #driverOut
	local driver = {}
		for _,driverName in ipairs(driverList) do
			if NumOut then
				for _,nameOut in ipairs(driverOut) do
					if nameOut ~= driverName then
						table.insert(driver, driverName) 
					end
				end
			else
				table.insert(driver, driverName)
			end
		end
	driverOut[vid] = driver[tableChooseRandomKey(driver)] 
	return driverOut[vid]
end
local function fail(result)
	--print("fail")
	scenario_scenarios.finish({failed = result})
end
local function success(result)
	--print("success")
	scenario_scenarios.finish(result)
end

local function onRaceResult()
	if gdState == 'running' or gdState == 'custom' then
		local vehIn = #M.vehIn
		local raceEnd = false
		local place 
		if M.mode == 'race' then
			for k,vid in ipairs(M.vehIn) do
				local scenario = scenario_scenarios.getScenario()
				local lap = scenario_gdrace.pathData[vid].lap
				if lap == scenario.lapCount then
					raceEnd = true
					--scenario_derby_airace.lapWrite()  --need a new function to write the lap times.
				end
			end
			place = scenario_gdrace.racePlace
		end
		
		if vehIn == 1 or raceEnd == true then
			for k,vid in ipairs(M.vehIn) do	
				local result = nil
				if vid == playerID then
					result = {msg = 'You Won!'}
					if M.mode == 'race' then
						result = {msg = '1st Place! ' .. place[1].driver..' / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' ' }
					end
					success(result)
				else
					local winner
					if M.mode == 'race' then
						winner = place[1].driver
					else 
						winner = getDriver(vid)
					end
					result = 'The driver '..winner..' has won.'
					fail(result)
				end	
			end
			if gdState == 'custom' then 
				onScenarioRestarted()
			end
		end
	end
end
local function removeRecord(t,id)
	local i = nil
	for k,v in ipairs(t) do
		if v == id then
			i = k
		end
	end
	table.remove(t, i)
end
local function addStopTicks(dt)
	for k, vid in ipairs(M.vehIn) do	
		local veh = be:getObjectByID(vid)
		if veh then
			local pos = veh:getPosition()	
			if not M.stopTicks[vid] then M.stopTicks[vid] = 0 end 
			local stopTicks = M.stopTicks[vid] 
			if stopTicks ~= nil then
				if not dropPos then
					dropPos = pos.z
				end
				if lastPosition[vid] == nil then lastPosition[vid] = pos end
				local distance =  math.abs((pos - lastPosition[vid]):len())
				if pos.z < dropPos - 2 and M.options.arena.name == 'Free Fall' then
					stopTicks = maxStopTicks + 1
				elseif distance > 0.4 then
					--vehicles still moving
					lastPosition[vid] = pos
					stopTicks = 0			
				else
					--Add one stop tick to the vehicles stop ticks
					stopTicks = stopTicks + dt 
				end
				--If they reach the max stop ticks then they are out
				if stopTicks > maxStopTicks  then	
					if gdState == 'custom' then
						guihooks.trigger('Message', {ttl = 3, msg = 'Player Out', icon = 'directions_bus'})
					else
						local out = getDriver(vid)
						if vid == playerID then 
							local msg = 'You have been called out!'
							helper.flashUiMessage(msg, 4)
						else
							local msg = out .. ' has been called out!'
							helper.flashUiMessage(msg, 4)
						end
					end
					removeRecord(M.vehIn, vid)
					helper.queueLuaCommand(veh, 'controller.setFreeze('..tostring(1) ..')')
				end
				M.stopTicks[vid] = stopTicks			
			end
		end
	end
end
local function onCountdownEnded()
	print('CountdownEnded')
	--if gdState == 'start' or gdState == 'custom' then
		dump(M.vehIn)
		for _,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				--helper.queueLuaCommandByName(vName, 'gdai.setState({mode = "'..mode..'", debugMode = "speeds"})')
				if veh then
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
				end
			end
		end
		freezeAll(0)
	--end
	if gdState ~= 'custom' then
		gdState = 'running'
	end
end
local function startScenario()
	local group = M.options.arena.type
		if group == 'Derby' then 
			M.mode = 'derby' 
		else
			M.mode = 'race'
			local uiMods = ui_apps.getList()
			local layouts = ui_apps.getLayouts()
			local appFound = false
			if layouts['scenario'] == nil then
				log('D', 'logTag', 'layout not existing', layout)
					return
			end
			for k,v in pairs(layouts['scenario']) do
				if v.directive == 'derbyPlace' then
					appFound = true
				end
			end
			if appFound == false then
				for k,v in pairs(uiMods) do
					if v.directive == 'derbyPlace' then
						table.insert(layouts.scenario, uiMods[k])
						ui_apps.saveLayouts(layouts)
					end
				end
			end		
		end
		
		scenario_gdrace.setScenario()
		freezeAll(1)
		gdState = 'start'
		extensions.hook('onScenarioChange', scenario)
end
local function onScenarioChange()
	local scenario = scenario_scenarios.getScenario()
	if not scenario then return end
	print(scenario.state)
	print(gdState)
	if scenario.state == 'pre-start' or scenario.state =='pre-running' then
		if gdState == 'stop' then
			if scenario.scenarioName == 'gdcommon' then 
				gdState = 'pre-running'
			end
		end
	end
	if scenario.state == 'running'and gdState == 'pre-running' then
		startScenario()
		return
	end
	if scenario.state == 'post' then
		reset(1)
	end
	if scenario.state == 'restart' then
		reset(1)
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					local mode = 'stop'
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				end
			end
		end
	end
end
local function onPhysicsUnpaused()
	if gdState == 'paused' or gdState == 'cpaused' then
		M.vehIn = {}
		playerID = be:getPlayerVehicleID(0)
		for i = 0, be:getObjectCount() do
			local veh = be:getObject(i)
			if veh then
				table.insert(M.vehIn, veh:getID())
				helper.queueLuaCommand(veh, 'extensions.load("gdmain")')
			end
		end
		setPlayer()
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..M.mode..'"})')
				end
			end
		end			
		if gdState == 'paused' then
			gdState = 'running'
		else
			
			gdState = 'custom' 
		end
	end
end
local function onPhysicsPaused()
	if gdState == 'running' or gdState == 'custom' then
		if gdState == 'running' then
			gdState = 'paused'
		else
			gdState = 'cpaused'
		end
		for k,vid in ipairs(M.vehIn) do
			if vid ~= playerID then
				local veh = be:getObjectByID(vid)
				if veh then
					local mode = 'stop'
					helper.queueLuaCommand(veh, 'gdai.setState({mode = "'..mode..'"})')
				end
			end
		end
	end
end
local function loadExtensions(vid)
	local veh = be:getObjectByID(vid)
	if veh then
		helper.queueLuaCommand(veh, 'extensions.load("gdmain")')
	else
		log('D', 'scenario', "Error Finding Vehicle")
	end
end
local function setVehicles(vid)
	table.insert(M.vehIn, vid)
	local vehIn = #M.vehIn
	if vehIn == 1 then		
		playerID = vid
	end
end
local function onVehicleSpawned(vid)
	loadExtensions(vid)
	if gdState ~= 'stop' and gdState ~= 'custom' then
		setVehicles(vid)
		setPlayer()
	end
end
local function restartHeat()
	local vehIn = #M.vehIn
	local opponents = M.options.opponents + 1
	--print(vehIn)
	--print(opponents)
	if vehIn == opponents then
		if vehHeat > 0 and currentHeat == totalHeats and totalHeats > 0 then
			print('loading saved vehicles')
			for k,vid in ipairs(M.vehIn) do	
				scenario_gdvehicles.loadHeat(vid, vehHeat)
				vehHeat = vehHeat - 1
			end
		end
		nextHeat = 0
		onCountdownEnded()
	end
end
local function checkHeats()
	local heats = gdloader.options.heats
	if heats == true then
		local opponents = M.options.opponents + 1 
		if opponents < 7 then
			totalHeats = 2
		elseif opponents >= 7 then
			totalHeats = 3	
		end
		local oppHeats = opponents / totalHeats	
		local vehIn = #M.vehIn	
		if vehIn <= oppHeats and currentHeat < totalHeats then
			print(oppHeats)
			print(currentHeat)
			print(totalHeats)
			
			currentHeat = currentHeat + 1
			if currentHeat == totalHeats then
				print('heatsdone')
				local msg = 'Heat ' ..currentHeat .. ' complete'
				helper.flashUiMessage(msg, 7)	
				local msg = 'Championship Round!'
				helper.flashUiMessage(msg, 7)	
				reset(2)
				M.vehHeat = vehHeat 
			else
				print('next heat')
				local msg = 'Heat ' ..currentHeat .. ' complete'
				helper.flashUiMessage(msg, 7)	
				reset(2)
			end 
			nextHeat = 1
		end
	end
end
local msgTimer = 0
local function updateGFX(dt)
	if nextHeat == 1 then
		if msgTimer > 7 then
			nextHeat = 2
			msgTimer = 0
			onScenarioChange()
		else
			msgTimer = msgTimer + dt
		end
	else 
		if nextHeat == 2 and gdState == 'start' then
			--msgTimer = msgTimer + dt
			--if msgTimer == 1 then
			--	helper.flashUiMessage('Get Ready', 7)
			--elseif msgTimer == 8 then
			--	helper.flashUiMessage('Get Set', 7)
			--elseif msgTimer == 15 then
			--	helper.flashUiMessage('GO!', 7)
		--	elseif msgTimer > 15 then
			--	msgTimer = 0
				restartHeat()
			--end
		else
			if gdState == 'running' or gdState == 'custom' then
				if M.mode == 'race' then
					scenario_gdrace.update(playerID)
				end
				scenario_gdsettings.update()
				addStopTicks(dt)
				onRaceResult()
				checkHeats()
			end
		end
	end
end
local function Start()
	M.vehIn = {}
	local vehIn = be:getObjectCount()
	playerID = be:getPlayerVehicleID(0)
	for i = 0, vehIn do
		local veh = be:getObject(i)
		if veh then
			table.insert(M.vehIn, veh:getID())
		end
	end
	if vehIn > 1 then
		setPlayer()
		M.mode = 'derby'
		gdState = 'custom'
		onCountdownEnded()
	end
end
M.getDriver = getDriver
M.selection = selection
M.onVehicleDestroyed = onVehicleDestroyed
M.onCountdownEnded = onCountdownEnded
M.onScenarioChange = onScenarioChange
M.onPhysicsPaused = onPhysicsPaused
M.onVehicleSpawned = onVehicleSpawned
M.updateGFX = updateGFX
M.Start = Start
M.onPhysicsUnpaused = onPhysicsUnpaused
M.onPhysicsPaused = onPhysicsPaused
M.onScenarioRestarted = onScenarioRestarted
return M