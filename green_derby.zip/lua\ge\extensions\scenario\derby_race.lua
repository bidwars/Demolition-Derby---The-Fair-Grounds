-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}


M.racePlace = {}
local Arena = 0
local user = "Hawk"

local function updatePlace()
	local place = M.racePlace
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _,vName in pairs(sVehicles) do
		local vd = scenario_derby_vehicles.pathData[vName]
			
		local count = 1
		--print(vName)
		--print("lcount "..vd.lapCount.." ccount"..vd.cpCount.." Dist"..vd.sDist.." end")
		local vehicleData = scenario_derby_vehicles.pathData
		for name, d in pairs(vehicleData) do
			if name ~= vName then
				if vd.lapCount < d.lapCount then
					count = count + 1
				end
				if vd.lapCount == d.lapCount then
					if vd.cpCount < d.cpCount then
						count = count + 1
					end
					if vd.cpCount == d.cpCount then
						if vd.sDist > d.sDist then
							count = count + 1
						end
					end		
				end
			end
		end	
		--print(count)
		place[count] = {}
		local driver = scenario_derby_vehicles.driver[vName ]
		if vName ~= user then
			place[count] = {vName = vName, driver = driver, lap = vd.lapCount}
		else
			place[count] = {vName = vName, driver = vName, lap = vd.lapCount}
		end
	end
	if not place[3] then
		place[3] = {vName = "none", driver = "---", lap = "0"}
	end
	M.racePlace = place
	--dump(place[1])
	--dump(place[2])
	--dump(place[3])
	
	
	
	guihooks.trigger('DerbyPlaceChange', { one = place[1].driver.. " "..place[1].lap, two = place[2].driver.. " "..place[2].lap, three = place[3].driver} )
end
local function checkPoints()
	local scenario = scenario_scenarios.getScenario()
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _, vName in pairs(sVehicles) do
	local pathData = scenario_derby_vehicles.pathData[vName]
	local aiRadFac = (scenario.radiusMultiplierAI or 1)
	local cpPoint = pathData.cpCount
	Arena = scenario_derby_main.Arena
	if Arena == 8 then
		aiRadFac = 13
	end
	local lap = pathData.lapCount 
	--dump(scenario.nodes)
	for wp,node in pairs(scenario.nodes) do
		local bestwp = string.sub(wp, -1)
		bestwp = tonumber(bestwp)
		--print(bestwp)
		--print("cppoint "..cpPoint)
		--print("lap "..lap)
		if bestwp == cpPoint then
			local vpos = vec3(map.objects[map.objectNames[vName]].pos)
			local npos = vec3(node.pos)
			local wpdist = npos:distance(vpos)
			--print(wpdist)
			if wpdist < aiRadFac then
				cpPoint = cpPoint + 1
				if cpPoint == 6 then
					cpPoint = 1 
					lap = lap + 1
				end
			end
			pathData.cpCount = cpPoint
			pathData.sDist = wpdist
			pathData.lapCount = lap
			break
		end
	end	
	end
end
local function getRoads()
	local roadCount = 1
	local t = string.format('levels/derby/racedata/lap'..Arena..'.json')
	local bestTime = readFile(t)
	if Arena == 7 then
		scenario_derby_airace.bestTime = 14.10  --oval
	else
		scenario_derby_airace.bestTime = 16.65 --concrete fig 8
	end
	if bestTime and bestTime < scenario_derby_airace.bestTime then
		local l = string.format('levels/derby/racedata/time'..Arena..'.json')
		local lapData = readJsonFile(l)
		if lapData then
			print(bestTime)
			--dump(lapData)
			bestTime = tonumber(bestTime)
			scenario_derby_airace.bestTime = bestTime
			scenario_derby_airace.mapPath[roadCount] = {road = {}}
			for _,ld in ipairs(lapData) do
				scenario_derby_airace.mapPath[roadCount].road[ld.node] = {
				node = ld.node, 
				pos = vec3(ld.posx, ld.posy, ld.posz), 
				radius = ld.radius, 
				links = ld.links, 
				segTags = {}
				}
			end
		end
	else
		local decalRoads = scenetree.findClassObjects('DecalRoad')
		local trackName = nil
		if Arena == 7 then 
			trackName = "dirttrack"
		elseif Arena == 8 then
			trackName = "fig8concrete"
		end
		--dump(decalRoads)
		for _, decalRoadName in pairs(decalRoads) do
			if decalRoadName == trackName then
				local o = scenetree.findObject(decalRoadName)
				--dump(o)
				local segCount = o:getNodeCount() -1
				--print(segCount)
				if segCount > 0 then
					local nextLink = nil
					if tonumber(decalRoadName) == nil then
						scenario_derby_airace.mapPath[roadCount] = {road = {}}
						for i = 1, segCount do
							if i == segCount then
								nextLink = 1
							else
								nextLink = i + 1
							end
								scenario_derby_airace.mapPath[roadCount].road[i] = {
								node = i, 
								pos = vec3(o:getNodePosition(i)), 
								radius = o:getNodeWidth(i), 
								links = nextLink, 
								segTags = {}
								}
						end
					end
				end
			end
		end
	end
end
local function createRoads(scenario)
	Arena = scenario_derby_main.Arena
	scenario.lapCount = scenario_derby_main.lapsEntered
	--local scenario = scenarios.getScenario()
	local objName = nil
	if Arena == 7 then
		 objName = "dirttrackwp"
	elseif Arena == 8 then
		 objName = "fig8concretewp"
	end
	local filename = "levels/derby/prefabs/waypoints/"..objName..".prefab"
	local prefabObj = spawnPrefab(objName, filename, '0 0 0', '0 0 1', '1 1 1')
	log('D', 'scenarios.spawnPrefab', 'loading prefab '..objName);
	local ScenarioObjectsGroup = scenetree.findObject("ScenarioObjectsGroup")
	ScenarioObjectsGroup:addObject(prefabObj.obj)
        
	--update static collision with new prefabs
	be:reloadCollision()
	 -- we are figuring out the waypoints and build the node graph with the positions of the level
	 --  complete the node graph with the spawned waypoints
	local waypointsTable = scenetree.findClassObjects('BeamNGWaypoint')
	--log('D', 'scenario', "found " .. #waypointsTable .. " waypoints")
	scenario.nodes = {}
	local aiRadFac = (scenario.radiusMultiplierAI or 1)
	local trackName = nil
	if Arena == 7 then
		trackName = "dirttrack"
	elseif Arena == 8 then
		trackName = "fig8concrete"
		aiRadFac = 5 
	end
	--dump(waypointsTable)
	for k, nodeName in pairs(waypointsTable) do
		if string.startswith( nodeName, trackName ) then
			table.insert(scenario.lapConfig, nodeName)
			log('D', 'scenario', tostring(k) .. ' = ' .. tostring(nodeName))
			local o = scenetree.findObject(nodeName)
			if o then
				if scenario.nodes[nodeName] == nil then
					local rota = nil
					if o:getField('directionalWaypoint',0) == '1' then
						rota = quat(o:getRotation())*vec3(1,0,0)
					end
					scenario.nodes[nodeName] = {
					pos = vec3(o:getPosition()),
					radius = o:getScale():len() * aiRadFac,
					rot = rota
					}
				end
			else
				log('E', 'scenario', 'waypoint not found: ' .. tostring(nodeName))
			end
		end
	end	
	getRoads()
end
local function onScenarioRestarted()
	M.racePlace = {}
end
M.onScenarioRestarted = onScenarioRestarted
M.updatePlace = updatePlace
M.getRoads = getRoads
M.checkPoints = checkPoints
M.createRoads = createRoads

return M