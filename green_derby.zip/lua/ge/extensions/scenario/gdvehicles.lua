-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
--local removePartsFile = {} --Table of parts to remove
local startData = {}
M.vehInSaved = {}
local driverList = {
		name = {"The Big Buffoon","Mayhem Mike","Gentle Bud","Sir NoMercy","Rawhide Billie","Cushion Charlie","Mr. Gumby","Ms. Gumby","Monster","Collision Carbonara","Motor Man Jackson","Erwin the Eliminator","Softcore James","Morning Hollywood","Crash Test Tommy","Hurricane Houston","MrBeast","PewDiePie","Jacksepticeye","Markiplier","DanTDM","TheWillyrex","rezendeevil","VanossGaming","JuegaGerman","Fernanfloo","ElRubiusOMG","The Game Theorists","LazarBeam","GameGrumps","H2ODelirious","CaptainSparklez","AngryJoeShow","CinnamonToastKen","Daithi De Nogla"},
		number = {"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36"}
		}
local helper = require('scenario/scenariohelper')

local function addDriverInfo(renew)
	local driverIDs = {}
	local driverNumbers = {}
	local driverNames = {}
	local vehIn = gdloader.vehIn
	--Compare old vehicle list with M.vehIn list to see what change
	for _,v2 in ipairs(M.vehInSaved) do
		for _,v in ipairs (vehIn) do
			if v2.vid == v.vid and v2.vid ~= 0 then
				driverIDs[v2.vid] = v2.vid
				if v2.driverName ~= nil or v2.driverNumber ~= 0 then
					driverNumbers[v2.driverNumber] = v2.driverNumber
					driverNames[v2.driverName] = v2.driverName
				end
			end
		end
	end
	local dNu
	local dNa
	local dL = driverList
	local function getRandomName()
		dNa = dL.name[tableChooseRandomKey(dL.name)]
		for k,name in pairs(dL.name) do
			if name == dNa then
				dNu = dL.number[k]
				table.remove(dL.name,k)
				table.remove(dL.number,k)
			end
		end
	end
	for _,v in pairs(driverNames) do
		for k,name in pairs(dL.name) do
			if v == name then
				table.remove(dL.name,k)
				table.remove(dL.number,k)
			end
		end
	end		
	local playerName
	--Get Steam player name 
	if Steam and Steam.isWorking and Steam.accountLoggedIn then
		playerName = Steam.playerName
		--print("steam username: " .. Steam.playerName)
	end
	--fill in the M.vehIn table with the random playerName and Number.
	local playerID = gdloader.setPlayer(renew)
	for k,v in ipairs(vehIn) do
		if not v.driverName then
			if v.vid == playerID then
				if not playerName then
					getRandomName()
				else 
					dNa = nil
					dNu = "00"
				end
			else
				getRandomName()
			end
		end
		gdloader.vehIn[k] = {vid = v.vid, driverName = dNa or v.driverName or playerName, driverNumber = dNu or v.driverNumber, model = v.model, pcs=v.pcs}	
	end
	M.vehInSaved = gdloader.vehIn
	scenario_gdletters.setSignText()
	dump(gdloader.vehIn)
end
local function getPosRot(i)
	local arena = gdloader.options.arena.name
	if not startData[arena] then
		local map = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
		local fn = string.format('levels/'..map..'/prefabs/StartPos.json')
		local file = {}
		if FS:fileExists(fn) then
			startData = readJsonFile(fn)
		else
			startData = {}
		end
	end
	local data = startData[arena]
		if not data then 
			if i == 1 then 
			local pos = gdloader.startPos.pos
			local rot = gdloader.startPos.rot
				return  pos, rot 
			else
				local rot = gdloader.startPos.rot--quat(0, 0, 0, 0)
				local dir = vec3(0, -1, 0)
				local pos = vec3(0,0,0)
				
				local playerVehicleID = be:getPlayerVehicleID(0)
				for k, v in pairs(map.objects) do
					if k == playerVehicleID then
						dir = v.dirVec:normalized()
						--rot = quatFromDir(dir)
					end
				end
				local k = i - 1
				local playerVehicle = be:getObject(k)
				local offset = vec3(-dir.y, dir.x, 0)
				pos = vec3(playerVehicle:getPosition()) + offset * 5
				return pos , rot
			end
		end	
		local pos = {}
		local rot = {}
		for j,t in pairs(data) do
			j = tonumber(j)
			if j == i then
				pos = t.pos
				rot = t.rot
				rot = AngAxisF(rot.x, rot.y, rot.z, (rot.w * 3.1459) / 180.0 ):toQuatF()
				return pos, rot
			end
		end
end
local function loadExtensions(renew)
	local vCount = be:getObjectCount() - 1
	for i = 0, vCount do
		local veh = be:getObject(i)
		if veh then
			local vid
			vid = veh:getID()
			if vid then
				local k = i + 1
				if renew == 1 then
					local pos, rot = getPosRot(k)
					veh:setPositionRotation(pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, rot.w)
				end
				if gdloader.vehIn[k] then
					gdloader.vehIn[k].vid = vid
				else
			
					local model = veh:getField('JBeam','0')
					local pcs = veh:getField('partConfig', '0')--jsonEncode(myObj.partConfig:c_str())
					-- readd the vehicles to the vehIn list if they have been called out.
					gdloader.vehIn[k] = {vid = vid, driverNumber = 0, driverName = nil, model = model, pcs = pcs}
					log('D', 'scenario_gdloader', 'vehicle was not in vehIn Table ')
				end
				helper.queueLuaCommand(veh, 'extensions.load("gdmain")')
			else
				log('D', 'scenario_gdloader', 'loadExtensions vehicleid error')
			end
			
		else
			log('D', 'scenario_gdloader', 'loadExtensions vehicle error')
		end
	end
	M.vehInSaved = gdloader.vehIn
	addDriverInfo(renew)
end
local function getConfig(veh)
	local vehHeat = gdloader.vehHeat
	local model
	local pcs
	if vehHeat  and vehHeat > 0 then
		local filename =  "vehicles/heats"..veh.."parts.pc"
		local save = jsonReadFile(filename)
		if not save then
			log("E", "save", "unable to get heats file")
			return
		end
		model = save.model
		pcs = save.pcs --fileparts
		table.insert(gdloader.vehIn, {vid = 0, driverNumber = save.driverNumber, driverName = save.driverName, model = model, pcs = pcs})
	else 
		model, pcs = scenario_gdclasses.loadClass()
		table.insert(gdloader.vehIn, {vid = 0, driverNumber = 0, driverName = nil, model = model, pcs = pcs})
	end
	return model, pcs
end
-------------------------------------------------------------------------------------
--CREATES THE VEHICLES FOR THE SCENARIO  
-------------------------------------------------------------------------------------
local function createVehicles()	
	local count =  gdloader.options.opponents + 1
	local vehHeat = gdloader.vehHeat
	if vehHeat and vehHeat > 0 then
		count = vehHeat
	end
	
	gdloader.vehIn = {}
	--createPlayerVehicle()
	
	for i=1,count do
		--model is the vehicle type, and pcs is the parts Configuration
		local model, pcs = getConfig(i)
		--local color = string.format("%0.2f %0.2f %0.2f %0.2f", vehicle.color.x, vehicle.color.y, vehicle.color.z, vehicle.color.w)
		local options = {config = pcs}--, pos = position}
		core_vehicles.spawnNewVehicle(model, options)
	end
	loadExtensions(1)
end
local function loadHeat(vid, k)
	local veh = be:getObjectByID(vid)
	if veh then
		print("loading beams")
		--veh:queueLuaCommand('gdbeams.setVehPos("vehicles/heats'..k..'.json")')
		veh:queueLuaCommand('gdbeams.load("vehicles/heats'..k..'.json")')
	end
	local playerID = gdloader.setPlayer()
end
local function onScenarioRestarted()
	M.vehInSaved = {}
end

M.onScenarioRestarted = onScenarioRestarted
M.loadExtensions = loadExtensions
M.loadHeat = loadHeat
M.loadPosition = loadPosition
M.createVehicles = createVehicles
M.getPosRot = getPosRot

return M