-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

local vehCount = 0 
local racePlace = {}
local Arena = 0


local function updatePlace()
	local place = {}
	local sVehicles = scenario_derby_vehicles.sVehicles
	local vehicleCountEntered = scenario_derby_main.vehicleCountEntered
	local numVehicles = vehicleCountEntered + 1
	vehCount = vehCount + 1
	if numVehicles == vehCount then
		for k,vName in pairs(sVehicles) do
			local vd = scenario_derby_vehicles.pathData[vName]
			
			local count = 1
			--print(vName)
			--print("lcount "..vd.lapCount.." ccount"..vd.cpCount.." Dist"..vd.sDist.." end")
			local vehicleData = scenario_derby_vehicles.pathData
			for name, d in pairs(vehicleData) do
				if name ~= vName then
					if vd.lapCount < d.lapCount then
					count = count + 1
					--print("lcount + 1")
					else 
						if vd.lapCount <= d.lapCount then
							if vd.cpCount < d.cpCount then
							count = count + 1
							--print("ccount + 1") 
							else
								if vd.cpCount <= d.cpCount then
									if vd.sDist > d.sDist then
										count = count + 1
										--print("sdist + 1") 
									end		
								end	
							end
						end
					end
				end	
			end
			--print(count)
			place[count] = vName	
		end
		if racePlace[1] ~= place[1] or racePlace[2] ~= place[2] or racePlace[3] ~= place[3] then
			racePlace[1] = place[1]
			racePlace[2] = place[2]
			racePlace[3] = place[3]
			guihooks.trigger('DerbyPlaceChange', { one = place[1], two = place[2], three = place[3]} )
			--dump(place
		end 
		place = {}	
		vehCount = 0	
		end
end
local function checkPoints(vName, scenario, v3position)
	local aiRadFac = (scenario.radiusMultiplierAI or 1)
	local cpPoint = scenario_derby_vehicles.pathData[vName].cpCount
	Arena = scenario_derby_main.Arena
	if Arena == 5 then
		aiRadFac = 5
	end
	local lap = scenario_derby_vehicles.pathData[vName].lapCount 
	if cpPoint == 0 then
		cpPoint = 1
	else
		scenario_derby_vehicles.pathData[vName].dtCount = 1
	end
	if lap == 0 then
		lap = 1
	end
	--dump(scenario.nodes)
	for wp,node in pairs(scenario.nodes) do
		local bestwp = string.sub(wp, -1)
		bestwp = tonumber(bestwp)
		--print(bestwp)
		if bestwp == cpPoint then
		--print(cpPoint)
			local wpdist = node.pos:distance(v3position)
			--print(wpdist)
			if wpdist < aiRadFac then
				if scenario_derby_vehicles.pathData[vName].dtCount == 1 then
					cpPoint = cpPoint + 1
					if cpPoint == 6 then
						cpPoint = 1 
						lap = lap + 1
					end
					--local trackNameWP
					--if Arena == 4 then
						--trackNameWP = "dirttrackwp"
					--elseif Arena == 5 then
						--trackNameWP = "fig8concretewp"
					--end
					--local w = trackNameWP.."_"..cpPoint
					--wpdist = scenario.nodes[w].pos:distance(v3position)
				end
			end
			scenario_derby_vehicles.pathData[vName].cpCount = cpPoint
			scenario_derby_vehicles.pathData[vName].sDist = wpdist
			scenario_derby_vehicles.pathData[vName].lapCount = lap
			
			break
		end
	end	
	updatePlace()
end
local function getRoads()
	local roadCount = 1
	local decalRoads = scenetree.findClassObjects('DecalRoad')
	local trackName = nil
	--local trackName2 = nil
	if Arena == 4 then 
		trackName = "dirttrack"
		--trackName2 = "dirttrack2"
	elseif Arena == 5 then
		trackName = "fig8concrete"
		--trackName2 = "fig8concrete2"
	end
	--dump(decalRoads)
	for _, decalRoadName in pairs(decalRoads) do
		if decalRoadName == trackName then
			--TorqueScript.eval([[
			--]]..decalRoadName..[[.driveability = 1;]])
		--roadCount = roadCount + 1 
	
		local o = scenetree.findObject(decalRoadName)
		
		--dump(o)
		--if o and o.drivability > 0 then
			local segCount = o:getNodeCount() -1
			--print(segCount)
			if segCount > 0 then
				--local drivability = o.drivability
			
				local nextLink = nil
				if tonumber(decalRoadName) == nil then
					scenario_derby_airace.mapPath[roadCount] = {road = {}}
					for i = 1, segCount do
						if i == segCount then
							nextLink = 1
						else
							nextLink = i + 1
						end
							scenario_derby_airace.mapPath[roadCount].road[i] = {
							node = i, 
							pos = vec3(o:getNodePosition(i)), 
							radius = o:getNodeWidth(i), 
							links = nextLink, 
							segTags = {}
							}
					 end
				end
			end
			end
		--end
	end
end
local function createRoads(scenario, lapsEntered)
	Arena = scenario_derby_main.Arena
	scenario.lapCount = lapsEntered
	--local scenario = scenarios.getScenario()
	local objName = nil
	if Arena == 4 then
		 objName = "dirttrackwp"
	elseif Arena == 5 then
		 objName = "fig8concretewp"
	end
	local p = createObject('Prefab')
		p.filename = "levels/derby/prefabs/waypoints/"..objName..".prefab"
		p.loadMode = 1 --'Manual'
		p.canSave  = true
		p.canSaveDynamicFields = true
		p:registerObject(objName)
		log('D', 'scenarios.spawnPrefab', 'loading prefab '..objName);
		p:load();
		scenetree.ScenarioObjectsGroup:addObject(p.obj)
        
	--update static collision with new prefabs
	be:reloadCollision()
	 -- we are figuring out the waypoints and build the node graph with the positions of the level
	 --  complete the node graph with the spawned waypoints
	local waypointsTable = scenetree.findClassObjects('BeamNGWaypoint')
	--log('D', 'scenario', "found " .. #waypointsTable .. " waypoints")
	scenario.nodes = {}
	local aiRadFac = (scenario.radiusMultiplierAI or 1)
	local trackName = nil
	if Arena == 4 then
		trackName = "dirttrack"
	elseif Arena == 5 then
		trackName = "fig8concrete"
		aiRadFac = 5 
	end
	--dump(waypointsTable)
	for k, nodeName in pairs(waypointsTable) do
		if string.startswith( nodeName, trackName ) then
			table.insert(scenario.lapConfig, nodeName)
			log('D', 'scenario', tostring(k) .. ' = ' .. tostring(nodeName))
			local o = scenetree.findObject(nodeName)
			if o then
				if scenario.nodes[nodeName] == nil then
					local rota = nil
					if o:getField('directionalWaypoint',0) == '1' then
						rota = quat(o:getRotation())*vec3(1,0,0)
					end
					scenario.nodes[nodeName] = {
					pos = vec3(o:getPosition()),
					radius = o:getScale():len() * aiRadFac,
					rot = rota
					}
				end
			else
				log('E', 'scenario', 'waypoint not found: ' .. tostring(nodeName))
			end
		end
	end	
	getRoads()
end


M.getRoads = getRoads
M.checkPoints = checkPoints
M.createRoads = createRoads

return M