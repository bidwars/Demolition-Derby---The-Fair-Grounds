---------------
----------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

math.randomseed(os.time())  --This is used for Random Math.
local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
require('mathlib')
local maxspeed = 4
local vdata = {}
local tdata = {}
local data = {}
local Arena = 0
M.mapPath = {}
local helper = require('scenario/scenariohelper')
local saveData ={}
M.elec = {}
local pathData = {}
local bestTime = math.huge
local bestLapData = {}
local user = "Hawk"
local newPath = 1
local abs, floor, min, max, stringformat, tableconcat = math.abs, math.floor, math.min, math.max, string.format, table.concat

local function seeks(target)
	local tpos = data.target
	if target then
		tpos = target
	end
	local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos,nil,vdata.pos,vdata.dirVec, vdata.vel)
	return dirDiff, dirTarget
end
local function predict(vName)
	local vel = map.objects[map.objectNames[vName]].vel
	local lookahead = vdata.pos + vel
	return lookahead
end 
local function encodefile(v)
	local vtype = type(v)
	
	-- Handle strings
	if vtype == 'string' then
		return stringformat('%s', v)
	end
	
	-- Handle numbers and booleans
	if vtype == 'number' then
		if v == v + 1 then -- test for inf
		if n == math.huge then
			return '"inf"'
		elseif n == -math.huge then
			return '"-inf"'
		end
		else
		return tostring(v)
		end
	end
	
	-- Handle tables
  if vtype == 'table' then
    if next(v) ~= 1 then
      local tmp = {}
      local tmpidx = 1
      for kk, vv in pairs(v) do
        tmp[tmpidx] = stringformat('%q:%s', kk, encodefile(vv))
        tmpidx = tmpidx + 1
      end
      return stringformat('%s', tableconcat(tmp, ''))
    else
      local vcount = #v
      local tmp = table.new(vcount, 0)
      for i = 1, vcount do
        tmp[i] = encodefile(v[i])
      end
      return stringformat('%s', tableconcat(tmp, ''))
    end
  end
  
  if vtype == 'boolean' then return tostring(v) end

  return "null"

end
local function writeFile(filename,obj)
	local f = io.open(filename, "w")
	if f then
		local content
		content = encodefile(obj)
		
		f:write(content)
		f:close()
		return true
	end
	return false
end
local function lapInfo()
	local p = newPath
	local save = string.format('levels/derby/racedata/road'..p..'.txt')
	local file = {}
	
	for v,t in pairs(M.mapPath[p].road)do
		file[v] = 'node = "'..t.pos.x..' '..t.pos.y..' '..t.pos.z..' '..t.radius..'";\r'
	end
	writeFile(save,file)
end
local function endme()
	for v,td in pairs(saveData) do
		local save3 = string.format('levels/derby/racedata/best'..v..'.csv')
		serializeJsonToFile(save3, td, true)
	end
end
local function separate()
	local sum = nil
	local count = 0 
	local desiredseparation = 5 
	dump(tdata)
	for id,v in pairs(tdata) do
		local d = vdata.pos:distance(v.pos)
		if d > 0 and d < desiredseparation then
		 local diff = (vdata.pos - tdata[id].pos):normalized()
		 diff = diff / d
		 sum = sum + diff
		 count = count + 1
		end
	end
	if count > 0 then
		sum = sum / count
		sum = sum * maxspeed
		local steer = sum - vdata.vel
		return steer
	end

end
local function gasbrake(dirTarget)
	local max = 1
	local adjust = 0.01
	local lowadjust = 0.03
	local vel = vdata.vel:length()
	local steer = nil
	local vehicleClass = scenario_derby_main.vehicleClass

	if data.target ~= nil then
	if vel > 4 and dirTarget > .96  then 
		 data.throttle = data.throttle + adjust
		 data.brake = 0	
	elseif vel > 16 and dirTarget < .92 and dirTarget > .5 then
		data.throttle = data.throttle - lowadjust
		data.brake = 0
	elseif dirTarget > -0.3 then
		data.throttle = lowadjust * 10
		data.brake = 0
	elseif  dirTarget < -0.3  then
		steer = 1.55
		data.brake = data.brake + adjust
		data.throttle = 0
	end
	end
	if data.throttle >= max then
		data.throttle = max
	elseif data.throttle < adjust then
		data.throttle = 0 
	end
	if data.brake >= max then
		data.brake = max
	elseif data.brake < adjust then
		data.brake = 0
	end
	if vehicleClass == 3  then
		if data.throttle > 0.3 then
			data.throttle = data.throttle / 1.2
		end
	end
	--print(vel)
	--print(dirTarget)
	--print(data.throttle)
	return data.throttle, data.brake
end
local function collisions(vName)
	local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions

	if aiCollisions ~= nil then
			--dump (aiCollisions)
			for k,v in pairs (aiCollisions) do
				local tobj = scenetree.findObjectById(k)
				local pos = tobj:getPosition()
				local posv3 = vec3(pos)
				
				return true, posv3
			end
	else 
		return false
	end
end
local function applyBehaviors(vName)
	if not vdata.pos or not data.target then return end
	local steer, dirTarget = seeks()
	local brake = data.brake 
	local throttle = data.throttle 
	scenario_derby_wheels.electrics(vName)
	local elec = M.elec
	--dump(elec)
	
	--if dirTarget < 0 then
	--	data.lCount = 3
	--else
	local obj = scenetree.findObject(vName)
	local pos = obj:getPosition()
	local stopTicks = scenario_derby_main.stopTicks[vName]
	--print(stopTicks .. vName)
	local collision, colpos 
	--print(data.sDist)
	if stopTicks > 50 and data.sDist == 0 then  --vehicle is not moving find out why
		data.startPos = vec3(pos)
		collision, colpos = collisions(vName)  --check for collisions with other ai
		if collision == true then
			data.sDist = 1  --collision with car
		else
			data.sDist = 2  --collision with wall or something else
		end
	end

	if data.sDist > 0 then
		local currentPos = vec3(obj:getPosition())
		local movement = (data.startPos - currentPos):length()
		--print(movement.. vName)
		--print(data.sDist)
		if movement > 10  then
			data.sDist = 0
		else
			
			if data.sDist == 1 then
				local coldir = nil  	
				steer, coldir = seeks(colpos)	
				if coldir > 0 then
					--data.cCount = 2
					throttle = .5
					brake = 0 
				else		
					--data.cCount = 1
					brake = .5
					throttle = 0
				end
			else
				if data.brake > 0  then
					--data.cCount = 2
					throttle = .5
					brake = 0 
				else 
					--data.cCount = 1
					brake = .5
					throttle = 0
				end
			end
		end	
	end
		local vel = vdata.vel
		local brake = data.brake or 0.00
		local throttle = data.throttle or 0.00
		local dist = data.target:distance(pos)
		--print(data.cCount)
		if data.cCount >= 12 then
			throttle = data.cCount - 5
			--throttle = scenario_derby_vehicles.adjustBrakeThrottle(data.throttle, vel, 1)
			brake = 0 
		elseif data.cCount >= 11 then
			brake = data.cCount - 4
			--brake = scenario_derby_vehicles.adjustBrakeThrottle(data.brake, vel, 1)
			throttle = 0
		elseif data.cCount == 10 then
			if vel:length() < 1 then
				throttle = 0.2
			end
			brake = 0	
		end
		
		local timeData = scenario_derby_vehicles.timeData[vName]
		local playerpos = ""..pos.x.." "..pos.y.." "..pos.z..""
		local targetpos = "" ..data.target.x.. " " ..data.target.y.."" 
		
		--Time Data
		local curTime = scenario.timer      --  current  time in scenario curTime
		local timeDiff = timeData.timeDiff   
		--local pointNew = data.dtCount  --dtCount is the next node
		local lastTime = timeData.lastTime
		local lapTime = timeData.lapTime
		local i = timeData.index
		
		--Path Data
		local cpCount = pathData.cpCount  --current checkpoint
		local lapCount = pathData.lapCount  --current lap
		local cpLast = pathData.cpLast   --previous checkpoint
		local lapLast = pathData.lapLast --previous lap

		local bestLap = false
		if cpLast ~= cpCount then    
			cpLast = cpCount
			lastTime = scenario.timer
			if lapLast ~= lapCount then
				lapLast = lapCount
				if lapTime < bestTime  then
					print("besttime".. bestTime)
					print("laptime".. lapTime)
					bestTime = lapTime
					local p = pathData.line
					if p == 1 then
						p = 2
					else
						p = 1
					end
					--local t = 1
					local num = #saveData[vName]
					for id,q in pairs(saveData[vName]) do
						--if q.Index == 1 then bestLapData = {} end
						--bestLapData[q.Index] = {Index = q.Index, Pos = q.pPos,Point = q.Pointcp,ethrottle = q.eThrottle,ebrake = q.eBrake,steer = q.eSteer}
						--dump(bestLapData)
						local radius = 0
						if q.eThrottle > 0.00 then
							radius = 12 + q.eThrottle
						elseif q.eBrake > 0.00 then
							radius = 11 + q.eBrake
						else	
							radius = 10
						end
					
						if id == 1 then
							M.mapPath[p] = {road = {}}
						end
						local link = id
						if link == num then
							link = 1
						else
							link = link + 1
						end
					
						M.mapPath[p].road[id] = {
							node = id, 
							pos = vec3(q.pPos), 
							radius = radius, 
							links = link, 
							segTags = {}
							}
						--t = t + 1
					end
					newPath = p
					lapInfo()
				end
				i = 1
				lapTime = 0
			end
			lapTime = timeDiff + lapTime
			timeDiff = 0.00
		else
			if lastTime then
				timeDiff = curTime - lastTime
			else
				timeDiff = 0.00
			end
			if i == 1 then
				saveData[vName] = {}
			end
			saveData[vName][i] = { 
				Index = i,
				Name = vName,
				LapTime = lapTime,
				TimeDiff = timeDiff,
				pPos = playerpos,
				Pointcp = cpPoint,
				Vel = vel:length(),
				TargetDir = dirTarget,
				eThrottle = elec.throttle or 0,
				Throttle = throttle,
				eBrake = elec.brake or 0,
				Brake = brake,
				eSteer = elec.steering or 0,
				Steer = steer,
				Tick = stopTicks,
				tPos = targetpos,
				tDis = dist
				}
			i = i + 1
		end
		data.throttle = throttle
		data.brake = brake
		timeData.lastTime =  lastTime
		timeData.lapTime = lapTime
		pathData.cpLast = cpLast
		pathData.lapLast = lapLast
		timeData.index = i 
		timeData.timeDiff = timeDiff
		
	if vName ~= user then
		scenario_derby_vehicles.driveCar(vName,-steer,throttle,brake,0)--------------------------------------------------------------------------------	
	end
	--end
end
local function debug(test)
if data.target ~= nil then
   debugDrawer:drawSphere(data.target:toPoint3F(), data.cCount, ColorF(1,0,0,0.3))
  end
 if test ~= nil then
   -- debugDrawer:drawSphere(test:toPoint3F(), 4, ColorF(1,0,0,0.3))
end
end
local function path(vName)
	
		--local predictLoc = predict(vName)	
		local bestNode = {}
		local largeDis = math.huge
		--local a = nil
		--local b = nil
		--local saveA = nil
		--local saveB = nil
		--local saveLine = nil
		if pathData.line ~= newPath then
			pathData.line = newPath
			data.lCount = 1
		end
				
		 local p = pathData.line
		 local mapData = M.mapPath[p]
		 
		if data.lCount > 1 and data.target then
			--local obj = scenetree.findObject(vName)
			--local pos = obj:getPosition()
			local dis = data.target:distance(vdata.pos)
			--if data.lCount == 3 then
			--	d = 1
			--	data.lCount = 2
			--end
			--print(d)
			local node = mapData.road[data.dtCount]
			if not node then return end
			--dump(node)
			debug()
			if dis < data.cCount then 
				--dump(mapData)
				
				data.dtCount = node.links
				data.target = node.pos
				data.cCount = node.radius
			end
		else
			if not mapData then return end
			for _,nodeList in ipairs(mapData.road) do
				if nodeList.node < 100 then
					local targetVec = (nodeList.pos - vdata.pos):normalized()
					local dirTarget = vdata.dirVec:dot(targetVec)
					if dirTarget > 0 then
						local dis = nodeList.pos:distance(vdata.pos)
						if dis < largeDis then
							bestNode = nodeList
							largeDis = dis
						end
					end
				end
			end
			
			data.target = bestNode.pos
			data.dtCount = bestNode.node
			data.cCount = bestNode.radius
			data.lCount = data.lCount + 1
			--print(vName ..' ' .. data.dtCount ..  ' ' ..data.target.. ' ' .. data.cCount)
			--print(data.targetObj.node)
			 --[[
			a = vec3(raceLine.pos)
			--print(a)	
			local link = raceLine.links
			b = vec3(mapData.road[link].pos)
			--print(b)
			local normalPoint, distance = scenario_derby_util.normalPoint(a,b,predictLoc)
			
			if distance < largeDis then
				--if raceLine.node < data.targetOut + 2 then
				largeDis = distance
				--print(distance)
				--print(normalPoint)
				normal = normalPoint
				saveA = a
				saveB = b
				saveLine =  raceLine

				--if raceLine.links == 1 then 
				--	data.targetOut = 1 
				--else
				--	data.targetOut = raceLine.node
				--end
				--end
			end
			--end
		end
			
				--debugDrawer:drawSphere(normal:toPoint3F(), .5, ColorF(1,0,0,1))
			
			local pathseg = (saveB - saveA):normalized()
			--local radius = saveLine.radius
			local radius = saveLine.radius   --saveLine.radius / 2
			pathseg = pathseg * radius		
			data.target = normal + pathseg
			data.dtCount = saveLine.node
			--debugDrawer:drawSphere(data.target:toPoint3F(), .5, ColorF(1,0,0,0.3))
			--print(saveLine.links)
			--print(saveLine.node)
			--data.targetObj.node = saveLine.links
			--debug(predictLoc)
			--]]
		end
end
local function initial(vName)
 	--map.objects returns objId, isactive, pos, vel, dirVec, dirVecUp, damage, objectCollisions
		vdata = map.objects[map.objectNames[vName]]
		tdata = map.objects 
		data = scenario_derby_vehicles.vehicleData[vName]
		pathData = scenario_derby_vehicles.pathData[vName]
		if not M.mapPath[1] then scenario_derby_race.getRoads() return end
end

local function update(vName,sc)
		scenario = sc
		Arena = scenario_derby_main.Arena 
		--Update Data
		initial(vName)
		if not vdata then return end
		if not tdata then return end
		path(vName)
		
		
		applyBehaviors(vName)
end
local function onScenarioRestarted()
	M.mapPath = {}
end

M.update = update
M.endme = endme
M.onScenarioRestarted = onScenarioRestarted
M.onRaceWaypointReached = onRaceWaypointReached
M.onRaceLap =  onRaceLap 
return M