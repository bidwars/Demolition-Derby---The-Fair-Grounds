﻿-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
math.randomseed(os.time())  --This is used for Random Math.
require('mathlib')

-------------------------------------------------------------------------------------
--Find Normal Point of line segment to a point
-------------------------------------------------------------------------------------
local function normalPoint(a, b, p) 
	local seg_a = a
	local seg_b = b
	local point = p
	local closest = nil
	local seg_v = seg_b - seg_a 
	local pt_v = point - seg_a
	if seg_v:length() <= 0 then return end
	local seg_v_unit = seg_v / seg_v:length()
	local proj = pt_v:dot(seg_v_unit)
	if proj <= 0 then
		closest = seg_a
	elseif proj >= seg_v:length() then
		closest = seg_b
	else
		local proj_v = seg_v_unit * proj
		closest = proj_v + seg_a
	end
	return closest, point:distance(closest)
end
-------------------------------------------------------------------------------------
--CIRCLE INTERSECTION
-------------------------------------------------------------------------------------
local function circleLineIntersection( Ax, Ay, Bx, By, Cx, Cy, R )
	-- compute the euclidean distance between A and B
	local LAB = math.sqrt( (Bx-Ax)*(Bx-Ax)+(By-Ay)*(By-Ay) )

	-- compute the direction vector D from A to B
	local Dx = (Bx-Ax)/LAB
	local Dy = (By-Ay)/LAB

	-- Now the line equation is x = Dx*t + Ax, y = Dy*t + Ay with 0 <= t <= 1.

	-- compute the value t of the closest point to the circle center (Cx, Cy)
	local t = ( Dx*(Cx-Ax) + Dy*(Cy-Ay) )
	
	-- This is the projection of C on the line from A to B.

	-- compute the coordinates of the point E on line and closest to C
	local Ex = t*Dx+Ax
	local Ey = t*Dy+Ay

	-- compute the euclidean distance from E to C
	local LEC = math.sqrt( (Ex-Cx)*(Ex-Cx)+(Ey-Cy)*(Ey-Cy) )

	-- test if the line intersects the circle
	if ( LEC < R ) then
		-- compute distance from t to circle intersection point
		local dt = math.sqrt( R*R - LEC*LEC )
	
		-- compute first intersection point
		local Fx = (t-dt)*Dx + Ax
		local Fy = (t-dt)*Dy + Ay
	
		-- compute second intersection point
		local Gx = (t+dt)*Dx + Ax
		local Gy = (t+dt)*Dy + Ay
		
		return "secant", Fx, Fy, Gx, Gy
		
	-- else test if the line is tangent to circle
	elseif ( LEC == R ) then
		-- tangent point to circle is E
		return "tangent", Ex, Ey
	else
		-- line doesn't touch circle
		return "none"
	end
end
-------------------------------------------------------------------------------------
--RECTANCE LINE INTERSECT  --https://love2d.org/wiki/General_math
-------------------------------------------------------------------------------------
local function findIntersect(l1p1x,l1p1y, l1p2x,l1p2y, l2p1x,l2p1y, l2p2x,l2p2y, seg1, seg2)
	local a1,b1,a2,b2 = l1p2y-l1p1y, l1p1x-l1p2x, l2p2y-l2p1y, l2p1x-l2p2x
	local c1,c2 = a1*l1p1x+b1*l1p1y, a2*l2p1x+b2*l2p1y
	local delta,x,y = a1*b2 - a2*b1
	if delta==0 then return false, "The lines are parallel." end
	x,y = (b2*c1-b1*c2)/delta, (a1*c2-a2*c1)/delta
	if seg1 or seg2 then
		local min,max = math.min, math.max
		if seg1 and not (min(l1p1x,l1p2x) <= x and x <= max(l1p1x,l1p2x) and min(l1p1y,l1p2y) <= y and y <= max(l1p1y,l1p2y)) or
		   seg2 and not (min(l2p1x,l2p2x) <= x and x <= max(l2p1x,l2p2x) and min(l2p1y,l2p2y) <= y and y <= max(l2p1y,l2p2y)) then
			return false, "The lines don't intersect."
		end
	end
	return x,y
end


local function findRandomPoint()
	local wpNum1 = scenario_derby_main.wp1
	local wpNum2 = scenario_derby_main.wp2
	local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
	local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
	
	local pos = {}
	local offset = 10
	if wp2.x > wp1.x then
		wp2.x = wp2.x - offset
		wp1.x = wp1.x + offset
	else
		wp2.x = wp2.x + offset
		wp1.x = wp1.x - offset
	end
	if wp2.y > wp1.y then
		wp2.y = wp2.y - offset
		wp1.y = wp1.y + offset
	else 
		wp2.y = wp2.y + offset
		wp1.y = wp1.y - offset
	end

	pos.x = math.random(wp2.x, wp1.x)
	pos.y = math.random(wp1.y, wp2.y)
	pos.z = wp1.z
	local randomPoint = vec3(pos.x, pos.y, pos.z)
	return randomPoint
end
local function vec2Diff(tpos, tvel, vpos, vposdir, vvel)
	local dirVec = vposdir
	local tposVec = nil
	if not tvel then
		tposVec = tpos 
	else
		tposVec = tpos + tvel
	end
	
	local vposVec = vpos 
	local targetVec = (tposVec - vposVec):normalized()
	--if dirTarget is negitive then the target is behind
	local dirTarget = dirVec:dot(targetVec)
	local dirDiff = math.asin(dirVec.x * targetVec.y - dirVec.y * targetVec.x)
	return dirDiff, dirTarget, dirVec
end

M.findRandomPoint = findRandomPoint
M.findIntersect = findIntersect
M.vec2Diff = vec2Diff
M.normalPoint = normalPoint
return M