-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local startvehicleConfig = 0
local startvehicleClass = 0 
local startArena = 0 
local user = "Hawk"
local removePartsFile = {} --Table of parts to remove
local helper = require('scenario/scenariohelper')
local startData = {}
M.vehicleData = {}
M.pathData = {}
M.timeData = {}
M.sVehicles = {}
M.sVehiclesID = {}
M.driver = {}

local function spawnaVehicle(jbeam, configuration, pos, rot, color, color2, color3, vName)
  local veh = createObject("BeamNGVehicle")
  local name = vName

  
    --weldParts(name)
  local spawnDatablock = String("default_vehicle")
  if not veh then
    log('E', logTag, 'Failed to create vehicle')
    return
  end

  local dataBlock = scenetree.findObject(spawnDatablock:c_str())
  if not datablock then
    veh.dataBlock = dataBlock
  else
    log('E', logTag, 'Failed to find dataBlock')
    return
  end

  veh:registerObject(name)
  
  veh.JBeam = jbeam
  veh.partConfig = configuration

	
  if color then
    veh.color = color:asLinear4F()
  end

  if color2 then
    veh.colorPalette0 = color2:asLinear4F()
  end

  if color3 then
    veh.colorPalette1 = color3:asLinear4F()
  end

  veh.licenseText = M.driver[name]
  --rot = rot * quat(0,0,1,0) -- rotate 180 degrees
	
  veh:spawnObjectWithPosRot(pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, rot.w)
  
  local missionGroup = scenetree.MissionGroup
  if not missionGroup then
    log('E', logTag, 'MissionGroup does not exist')
    return
  end
  missionGroup:addObject(veh.obj)
  
  veh:autoplace()
  
  
end

-- opt: {config, color, pos}
-- config: key
-- color can be a key from the colors list or an rgb string with spaces as seperators i.e "5 5 5"
-- pos should be a string with xyz coordinates as string with spaces as seperators i.e "5 5 5"
local function spawnaNewVehicle (key, opt, vName)
  local firstVehicle = (be:getObjectCount() == 0)
  local options = opt

  if type(options.color) == 'string' then
    options.color = stringToTable(options.color, '%s')
  end
  if type(options.color2) == 'string' then
    options.color2 = stringToTable(options.color2, '%s')
  end
  if type(options.color3) == 'string' then
    options.color3 = stringToTable(options.color3, '%s')
  end

  if type(options.color) == 'table' and #options.color == 4 then
    options.color = ColorF(options.color[1], options.color[2], options.color[3], options.color[4])
  else
    options.color = nil
  end
  if type(options.color2) == 'table' and #options.color2 == 4 then
    options.color2 = ColorF(options.color2[1], options.color2[2], options.color2[3], options.color2[4])
  else
    options.color2 = nil
  end
  if type(options.color3) == 'table' and #options.color3 == 4 then
    options.color3 = ColorF(options.color3[1], options.color3[2], options.color3[3], options.color3[4])
  else
    options.color3 = nil
  end

  local rot = quat(1, 0, 0, 0)
  local dir = vec3(0, -1, 0)

  if getCamera() and getCamera():isSubClassOf('BeamNGVehicle') then
    local playerVehicleID = be:getPlayerVehicleID(0)
    for k, v in pairs(map.objects) do
      if k == playerVehicleID then
        dir = v.dirVec:normalized()
        rot = quatFromDir(dir)
      end
    end
    if options.pos then
      spawnVehicle(key, options.config, options.pos, rot, options.color, options.color2, options.color3, vName)
    else
      local playerVehicle = be:getPlayerVehicle(0)
      local offset = vec3(-dir.y, dir.x, 0)
      local pos = vec3(playerVehicle:getPosition()) + offset*5
      spawnVehicle(key, options.config, pos, rot, options.color, options.color2, options.color3,vName)
    end
  else
    local camera = commands.getCamera(commands.getGame())
    local freecam = vec3(0, 0, 0)
    if camera then freecam = camera:getPosition(); rot = camera:getRotation() end
    spawnVehicle(key, options.config, freecam, quat(rot.x, rot.y, rot.z, rot.w), options.color, options.color2, options.color3, vName)
  end

  if firstVehicle then
    local player = 0
    be:enterNextVehicle(player, 0) -- enter any vehicle
  end
  commands.setGameCamera()

  if opt.licenseText then
    local vehicle = be:getPlayerVehicle(0)
    vehicle:setDynDataFieldbyName("licenseText", 0, opt.licenseText)
  end
end
-------------------------------------------------------------------------------------
--TORQUE SCRIPT TO SET THE PARTS Config
-------------------------------------------------------------------------------------
local function getPosRot(i)
	local Arena = scenario_derby_main.Arena
	local position = {}
	local rotation = {}
	local data = {}
		if Arena == 1 then
			data = startData.freefall
		elseif Arena == 2 then 
			data = startData.concrete 
		elseif Arena == 3 then
			 data = startData.grass
		elseif Arena == 4 then
			data = startData.vground
		elseif Arena == 5 then
			data = startData.ovalderby
		elseif Arena == 6 then
			data = startData.mudpit
		elseif Arena == 7 then
			data = startData.ovalrace
		elseif Arena == 8 then
			data = startData.fig8concrete
		end	

		for j,t in pairs(data) do
			j = tonumber(j)
			if j == i then
				position = t.pos
				rotation = t.rot
				return position, rotation
			end
		end
		
end
-------------------------------------------------------------------------------------
--DELETE VEHICLES 
-------------------------------------------------------------------------------------
local function deleteVehicles(vName)
		local vObj = scenetree.findObject(vName)
		if vObj then
			--dump(obj)
			vObj:delete()
			--Update static collision with new prefabs
			be:reloadCollision()
		end
end
local function TScript(driver,JBeam,pcs, i)
	
	local position, rotation = getPosRot(i)
	local o = scenetree.findObject(driver)
	if o then
		print("delete vehicle")
		core_vehicles.removeCurrent()
	--spawnNewVehicle(JBeam, opt)
	--spawnVehicle(JBeam, pcs, position , rotation, driver)
	end
		local vehicleTS = [[
			new BeamNGVehicle(]]..driver..[[) {
			JBeam = "]]..JBeam..[[";
			partConfig = "]]..pcs..[[";
			renderDistance = "500";
			renderFade = "0.1";
			isAIControlled = "0";
			dataBlock = "default_vehicle";
			position = "]]..position.x..' '..position.y..' '..position.z..[[";
			rotation = "1 0 0 0";
			scale = "1 1 1";
			canSave = "1";
			canSaveDynamicFields = "1";
			};
			]]
			TorqueScript.eval(vehicleTS)
			TorqueScript.eval([[
			]]..driver..[[.rotation = "]]..rotation.x..' '..rotation.y..' '..rotation.z..' '..rotation.w..[[";]])
end
-------------------------------------------------------------------------------------
--SETS THE PARTS FOR EACH vehicle
-------------------------------------------------------------------------------------
local function partsConfig(firstLoad)
	local vehicleConfig = scenario_derby_main.vehicleConfig
	local vehicleClass = scenario_derby_main.vehicleClass
	local vehiclePick = scenario_derby_main.vehiclePick
	local Arena = scenario_derby_main.Arena
	if firstLoad == true then
		startvehicleConfig = vehicleConfig
		startvehicleClass = vehicleClass
		startArena = Arena
		local k = string.format('levels/derby/prefabs/startPos.json')
		startData = readJsonFile(k)
	end
	local includeMods = scenario_derby_main.includeMods
	local path = string.format('levels/derby/configs/removeParts.pc')
	removePartsFile = scenario_derby_classes.readPartsFile(path)
	local JBeam, pcs = scenario_derby_classes.loadClass(removePartsFile)
	--dump(pcs)	
	if firstLoad == true then 
		TScript(user,JBeam,pcs, 1)
	else
		if startvehicleConfig ~= vehicleConfig or startvehicleClass ~= vehicleClass or includeMods > 1 or vehiclePick > 1 or startArena ~= Arena then	
			TScript(user,JBeam,pcs, 1)
		end
	end	
end
-------------------------------------------------------------------------------------
--CREATES THE AI VEHICLES FOR THE SCENARIO  
-------------------------------------------------------------------------------------
local function createVehicles()			
	local vehicleCountEntered = scenario_derby_main.vehicleCountEntered		
	--local driver = {"ai1","ai2","ai3","ai4","ai5","ai6","ai7","ai8","ai9","ai10","ai11","ai12","ai13","ai14","ai15","ai16"}
	M.driver = {["ai1"]="The Big Buffoon",["ai2"]="Mayhem Mike",["ai3"]="Gentle Bud",["ai4"]="Sir NoMercy",["ai5"]="Rawhide Billie",["ai6"]="Cushion Charlie",["ai7"]="Mr. Gumby",["ai8"]="Ms. Gumby",["ai9"]="Montster",["ai10"]="Collissione Carbonara",["ai11"]="Motor Man Jackson",["ai12"]="Erwin the Eliminator",["ai13"]="Softcore James",["ai14"]="Morning Hollywood",["ai15"]="Crashtest Tommy",["ai16"]="Hurricane Houston"}
	partsConfig(false)
	
	for i=1,vehicleCountEntered do
		--JBeam is the vehicle type, and pcs is the parts Configuration
		
		local k = i + 1
		local JBeam, pcs = scenario_derby_classes.loadClass(removePartsFile)
		TScript("ai"..tostring(i),JBeam,pcs, k)
	end
end
-------------------------------------------------------------------------------------
--FUNCTION TO FREEZE AND UNFREEZE VEHICLES BEFORE THE START
-------------------------------------------------------------------------------------
local function freezeAll(state, vName)
	local vObj = scenetree.findObject(vName)
	if vObj then
		vObj:queueLuaCommand('controller.mainController.setFreeze('..tostring(state) ..')')
	end
end

local function setupVehicles()

	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
	log('D', 'scenario', "found " .. #sVehicles .. " vehicles") 
	M.sVehicles = sVehicles
	for k,vName in ipairs(sVehicles) do
	M.vehicleData[vName] = {
			targetSet = false, 
			targetTemp = nil,
			target = nil,  --Target vehicle name
			targetObj = nil,
			dirTarget = nil,
			dirDiff = nil,
			backup = false,
			forward = true,
			lasthit = false,
			throttle = 0,
			brake = 0,
			line = nil,
			hitTarget = false,
			startPos = nil,
			sDist = 0,  --Start Distance
			tDist = 0,  --Target Distance
			collision = false,
			dtCount = 0,
			lCount = 0,
			cCount = 0,
			hitID = 0,
			wheelspeed = nil,
			dir = nil,
				}	
	M.pathData[vName] = {
				line = 1,  --USED IN derby_airace for path
				nodeCount = nil,--USED IN derby_airace for the number of nodes
				dist = nil,  --USED IN derby_airace for distance to node
				lapCount = 1,  --USED IN derby_race for places
				cpCount = 1, --USED IN derby_race for places and Checkpoints
				cpLastPos = 0, --USED IN derby_airace for lastCPPOsition 
				dtCount = 0, --USED IN derby_race for Checkpoints
				sDist = 0,  -- USED IN derby_race for places
				}
	M.timeData[vName] = {
				lastTime =  0.00,
				cpTime = 0.00,
				lapTime = 0.00,
				index = 1,
				timeDiff = 0.00,
				cpCount = 0
				}
		scenario_derby_main.stopTicks[vName] = 1
		helper.trackVehicle(vName, vName)  --Track the Vehicle
	
		if vName ~= user then
			table.insert(scenario_derby_main.vehIn, vName)
			helper.setAiMode(vName, 'manual')  --Needed to setup the AI to Auto Shifting
			local vObj = scenetree.findObject(vName)
			if vObj then
				vObj:queueLuaCommand('controller.mainController.setGearboxMode("arcade")')
				local start = vObj:getPosition()	
				M.vehicleData[vName].startPos = vec3(start)
				--vObj:queueLuaCommand('obj:requestReset(RESET_PHYSICS)')  
				--vObj:resetBrokenFlexMesh()  --Repair Vehicles
			end
		end
		freezeAll(0,vName)
	end
end
local function findClone()
	local clone = 0
	local vList = scenetree.findClassObjects('BeamNGVehicle')
		--dump(vList)
	for _,cName in pairs(vList) do
		local i,j = string.find(cName, "clone")
		if i ~= nil then
			clone = 1
		end
	end
	return clone
end
local function nameClone()
	local player = be:getPlayerVehicleID(0)
	local vList = scenetree.findClassObjects('BeamNGVehicle')
	--print(player)
	--dump(vList)
	local i = 1
	for _,vName in ipairs(vList) do	
		local o = scenetree.findObject(vName)
		if o then
			local id = o:getID()
			if id == player then
				o.name = user
			else
				o.name = "ai"..i
				i = i + 1
			end
		end
	end
	local newlist = scenetree.findClassObjects('BeamNGVehicle')
	--dump(newlist)
end
-------------------------------------------------------------------------------------
--LOAD vehicles
-------------------------------------------------------------------------------------
--{id:6, name:"Mud Pit"},
	--{id:5, name:"Concrete Figure 8"},
	--{id:4, name:"Oval Dirt Track"},
	--{id:3, name:"Grass"},
	--{id:2, name:"Concrete"},
	--{id:1, name:"Free Fall"}

-------------------------------------------------------------------------------------
--GETS THE AI MOVING 
-------------------------------------------------------------------------------------
local function driveCar(vName,steering,throttle,brake,parkingbrake)
	--print("drive Car"..vName)
	if not steering then return end
	local vObj = scenetree.findObject(vName)
	if vObj then
		vObj:queueLuaCommand('input.event("steering", '..steering..', 1)')
		vObj:queueLuaCommand('input.event("throttle", '..throttle..', 2)')
		vObj:queueLuaCommand('input.event("brake", '..brake..', 2)')
		vObj:queueLuaCommand('input.event("parkingbrake", '..parkingbrake..', 2)')
	end
end
local function adjustBT(dirDiff,throttle, brake, dirTarget)
	if dirTarget > 0 then
		throttle = throttle + .04	 
	end
end
local function adjustBrakeThrottle(value, vel, dirTarget)
	--print(wheelSlip)
	--print(value)
	local speed  = vel:length()
	--local maxSlip = 14
	--local Arena = scenario_derby_main.Arena
	--if Arena == 3 or Arena == 6 then
	--	maxSlip = 11
	--end
	if speed > 2 and value > 0 then
		if dirTarget < 0.5 and dirTarget > -0.5 then
			if dirTarget < 0.2 and dirTarget > -0.2  then
				value = value - 0.01
			else 
				value = value - 0.005
			end
			value = value - 0.001	
			--print("lower")
		end
	end
	
	if dirTarget > .65 or dirTarget < -.65 then
		if dirTarget > .75 or dirTarget < -.75 then
			if dirTarget > .87 or dirTarget <  -.87 then
				value = value + .01
			else 
				value = value + .005	
			end
		else 
			value = value + 0.001
		end
	else 
		if speed < 2 then
			value = value + 0.01
		end
	end


	if value > 1 then
		value = 1
	elseif value < 0.00 then
		value = 0.00
	end
	return value
end
local function resetTarget(id)
	local veh = be:getObjectByID(id)
	M.vehicleData[veh.name].target = nil
end
local function onScenarioRestarted()
M.vehicleData = {}
M.pathData = {}
M.timeData = {}
M.sVehicles = {}
M.sVehiclesID = {}
M.driver = {}
end
M.resetTarget = resetTarget
M.onScenarioRestarted = onScenarioRestarted
M.partsConfig = partsConfig
M.createVehicles = createVehicles
M.loadVehicles = loadVehicles
M.freezeAll = freezeAll
M.weldParts = weldParts
M.deleteVehicles = deleteVehicles
M.driveCar = driveCar
M.findClone = findClone
M.nameClone = nameClone
M.setupVehicles = setupVehicles
M.adjustBrakeThrottle = adjustBrakeThrottle
M.adjustBT = adjustBT
return M