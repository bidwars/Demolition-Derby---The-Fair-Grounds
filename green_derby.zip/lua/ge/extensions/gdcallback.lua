-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
M.vehIn = {}
local settings = {}
local function driveTrainCallback(data)
	gdloader.driveTrain = data
end
local function driveTrain()
	if be:getPlayerVehicle(0) then
		local vehicle = scenetree.findObjectById(be:getPlayerVehicle(0):getID())
		local command = "obj:queueGameEngineLua(string.format('gdcallback.driveTrainCallback(%s)',serialize({gear = drivetrain.gear})))"
		if vehicle then
			vehicle:queueLuaCommand(command)
		end
	end
end
local function request(vid)
	M.vehIn = gdloader.vehIn
	local vehicle = scenetree.findObjectById(vid)
	if vehicle then
		vehicle:queueLuaCommand('gdcallback.vehInCallBack(' .. serialize(M.vehIn) .. ')')
	end
end
local function getData()
	local data = {}
	data['map'] = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
	data['model'], data['config2'] = scenario_gdclasses.modelName()
	return data
end
local function getParts()
	local data = {}
	data['parts'] = scenario_gdclasses.getParts()
	return data
end
local function saveObject(key,value)
	local fn = string.format('saveMenu.json')
	local file = {}
	if FS:fileExists(fn) then
		file = readJsonFile(fn)
	end
	--print('savekey'..key..'to file')
	file[key] = value
	--dump(file)
	if key then
		serializeJsonToFile(fn, file, true)
	end
	
end
local function saveTable(file)
	local fn = string.format('saveMenu.json')
	--local file = {}
	--if FS:fileExists(fn) then
		--file = readJsonFile(fn)
	--end
		--if fd then
			--file = fd
			
		--end
	if file then
			--for k,v in pairs(data) do
				--file[key] = v
				--print('savekey'..k..'to file')
			--end
			serializeJsonToFile(fn, file, true)
			gdloader.selection(file)
	end
	--end
	
end
local function loadObject()

		local fn = string.format('saveMenu.json')
		if FS:fileExists(fn) then
			local file = readJsonFile(fn)
			if file then
				--print('file')
				--dump(file)
				settings = file
				return settings
			else
				return nil
			end
		end

end
local function removeItem(key)
	local fn = string.format('saveMenu.json')
	if FS:fileExists(fn) then
		local file = readJsonFile(fn)
		if file then
			file[key] = {}
		end
		serializeJsonToFile(fn, file, true)
	end
end
local function clearAll()
	local fn = string.format('saveMenu.json')
	local file = {}
	serializeJsonToFile(fn, file, true)
end

M.getData = getData
M.saveTable = saveTable
M.clearAll = clearAll
M.saveObject = saveObject
M.loadObject = loadObject
M.removeItem = removeItem
M.getParts = getParts
M.driveTrain = driveTrain
M.driveTrainCallback = driveTrainCallback
M.request = request
return M
