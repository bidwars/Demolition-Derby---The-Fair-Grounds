﻿-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local user = "Hawk"

require('mathlib')
local function debug(aiDirVec, targetAiMidPos, targetLength, dt)
	--if test2 ~= nil then
	--	debugDrawer:drawSphere(test2:toPoint3F(), 4, ColorF(1,0,0,0.3))
	--end
	--local debugDrawer = obj.debugDrawProxy
	local vel = map.objects[map.objectNames[vName]].vel
	local tpos = map.objects[map.objectNames[target]].pos
	local pos = map.objects[map.objectNames[vName]].pos
	if tpos ~= nil and targetAiMidPos ~= nil then
		--debugDrawer:drawSphere(test:toPoint3F(), 1.5, ColorF(1,0,0,0.3))
	local speed = vel:length()
	if speed < 3 then
		speed = 2 
	else 
		speed = 1 
	end

	local tspeed = vel:length()
	
	local futurePos = pos + (vel):normalized() * speed
	local futureTarget = tpos +  ((vel:normalized()) * tspeed)
	local futurePos2 = pos + vel * speed
	--debugDrawer:drawSphere(futurePos:toPoint3F(), 0.5, ColorF(1,0,0,0.3))
	--debugDrawer:drawSphere(futureTarget:toPoint3F(), 0.5, ColorF(0,1,0,1))
	debugDrawer:drawSphere(futurePos2:toPoint3F(), 0.5, ColorF(1,1,0,1))
    --debugDrawer:drawSphere((aiDirVec*targetLength + futureTarget):toPoint3F(), 0.5, ColorF(0,1,0,1))
   -- debugDrawer:drawSphere(targetAiMidPos:toPoint3F(), 0.3, ColorF(1,0,0,0.3))
	end
end

local function drive()
	local vInList = scenario_derby_main.vehIn
	for _,vName in pairs(vInList) do	
		local vData = scenario_derby_vehicles.vehicleData[vName]
		local dirDiff = vData.dirDiff
		local vel = map.objects[map.objectNames[vName]].vel
		local pos = map.objects[map.objectNames[vName]].pos
		if vData.collision == false then
			if vData.backup == true  then
				vData.brake = scenario_derby_vehicles.adjustBrakeThrottle(vData.brake,vel, vData.dirTarget)
				vData.throttle = 0
			else
				vData.throttle = scenario_derby_vehicles.adjustBrakeThrottle(vData.throttle,vel, vData.dirTarget)
				vData.brake = 0 
			end
		end
		scenario_derby_vehicles.driveCar(vName,-dirDiff,vData.throttle,vData.brake,0)
	end
end
-------------------------------------------------------------------------------------
--RESET TARGET 
-------------------------------------------------------------------------------------
local function reset(vData)
	vData.targetSet = false
	vData.target = nil
end
-------------------------------------------------------------------------------------
--SETS THE COUNT FOR HOW LONG WE GO FORWARD OR BACKWARDS
-------------------------------------------------------------------------------------
local function counts()
	local vInList = scenario_derby_main.vehIn
	for _,vName in pairs(vInList) do
		local vData = scenario_derby_vehicles.vehicleData[vName]
		local pos = map.objects[map.objectNames[vName]].pos
		local tpos = nil
		if vData.target == "point" or vData.target == "line" then
			tpos = vData.targetObj
		else
			tpos = map.objects[map.objectNames[vData.target]].pos
		end
		local stopTicks = scenario_derby_main.stopTicks[vName]
		--print(lCount .."lCount " ..dtCount .. "dtCount")
		if vData.collision == false then	
			if stopTicks > 100 then
				vData.lasthit = true
			end				
			if vData.lasthit == true then
				if vData.lCount == 1 then 
					if vData.backup == false then
						vData.backup = true
					else 
						vData.backup = false
					end
				end
				local hDist = vec3(pos):distance(vec3(tpos))
				if vData.lCount > 150 or hDist > 15 then
					if vData.hitTarget == true then
						reset(vData)
						vData.hitTarget = false
						vData.cCount = 0
					end
					vData.lasthit = false
					vData.lCount = 0
					vData.dtCount = 0
				else
					vData.lCount = vData.lCount + 1
				end
			else
				if vData.target == "point" then
					local pDist = vec3(pos):distance(vec3(tpos))
					if pDist < 14 then
						vData.dtCount = 0 
						vData.lCount = 0
						reset(vData)
					end
				end
				if vData.dtCount < 400 then	
					vData.dtCount = vData.dtCount + 1 
					if vData.dirTarget < 0 then
						vData.backup = true
					else
						vData.backup = false	
					end
				else
					vData.dtCount = 0
					vData.lCount = 0
					reset(vData)
				end
			end
		else
			local lDist = vec3(pos):distance(vec3(tpos))
			if lDist < 20 then
				reset(vData)
				vData.collision = false 
				vData.brake = 0 
				vData.throttle = 0 
			else
				if stopTicks > 100 and stopTicks < 401 then
					if stopTicks == 101 or stopTicks == 400 then
						vData.lasthit = true
						vData.collision = false
					end
				else
					if vData.dirTarget < -0.4 then
						vData.backup = true
						vData.throttle = 0
						vData.brake = 0.7
						if lDist > 10 then
							vData.brake = 0.3	
						end
					else 
						vData.backup = false
						vData.brake = 0
						vData.throttle = 0.8 
						if lDist > 10 then
							vData.throttle = 0.3
						end
					end
				end
			end
		end
	end
end
-------------------------------------------------------------------------------------
--GETS DIRECTION AND DISTANCE OF THE TARGET
-------------------------------------------------------------------------------------
local function aiPursuit()
	local vInList = scenario_derby_main.vehIn
	for _,vName in pairs(vInList) do	
		local dir = map.objects[map.objectNames[vName]].dirVec
		local pos = map.objects[map.objectNames[vName]].pos
		local vel = map.objects[map.objectNames[vName]].vel
		local vData = scenario_derby_vehicles.vehicleData[vName]
		local tpos = nil
		local tvel = vec3(0,0,0)
		if vData.target == "point" or vData.target == "line" then
			tpos = vData.targetObj
		else
			tpos = map.objects[map.objectNames[vData.target]].pos
			tvel = map.objects[map.objectNames[vData.target]].vel	
		end
		--debugDrawer:drawSphere(tpos:toPoint3F(), 0.5, ColorF(1,1,0,1))
		local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos, tvel, pos, dir, vel)
		--local curVel = tvel:length()
		--local targetLength = math.max(curVel * 0.6, 8)
		--local halfRemainder = targetLength * 0.5
		--local vec = pos - tpos
		--local vecLen = vec:length()
		--local targetAiMidPos =  tpos + vec * math.min(halfRemainder,vecLen) / vecLen
		-- local targetVec = (tpos - vpos):normalized()
		 --local aiDirVec = dir
		vData.dirDiff = dirDiff
		vData.dirTarget = dirTarget
	end
end
local function lookahead(vel,pos)
	
	local ahead = vel:length()	
	if ahead < 1 then
		vel = vel * 2
	else 
		vel = vel * 1.4
	end
	local ahead = pos + vel
	return ahead
end
-------------------------------------------------------------------------------------
--CHECKS FOR COLLISIONS WITH WALLS
-------------------------------------------------------------------------------------
local function checkWalls()
	local wpNum1 = scenario_derby_main.wp1
	local wpNum2 = scenario_derby_main.wp2
	local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
	local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
	local Arena = scenario_derby_main.Arena
	
	
	local vInList = scenario_derby_main.vehIn
	for _,vName in pairs(vInList) do
		local vData = scenario_derby_vehicles.vehicleData[vName]
		local pos = map.objects[map.objectNames[vName]].pos
		local vel = map.objects[map.objectNames[vName]].vel
		local ahead = lookahead(vel,pos)
		local dx = nil
		local dy = nil
		local dz = nil
		local lineIntersect = nil
		dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp1.x, wp2.y,true,true)
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp1.x, wp1.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = scenario_derby_util.findIntersect(pos.x, pos.y, ahead.x,ahead.y, wp2.x, wp2.y, wp1.x, wp2.y,true,true)
		end

		if dx ~= false then
			dz = pos.z
			lineIntersect = vec3(dx, dy, dz)
			vData.collision = true
			local point = nil
			if Arena == 1 then
				point = vData.startPos
			else
				local xpos = (wp1.x + wp2.x) / 2
				local ypos = (wp1.y + wp2.y) / 2
				local zpos = wp1.z
				point = vec3(xpos, ypos, zpos)
			end
			vData.targetObj = point
			vData.target = "line"
			vData.targetSet = true
		else
			local circleOffset
			local targetTemp = nil
			if Arena == 1 then
				local cr = 7.5
				local cx = 157.99
				local cy = -198.1715
				local z = 58.55
				local circle = vec3(cx,cy, z)
				local offset = vec3(0,0,0)	
				local seg_b = vel
				local seg_a = pos

				if seg_b:length() < 1 then
					seg_b = seg_b * 1
				else 
					seg_b = seg_b * 1.3
				end
				seg_b = seg_a + seg_b

				local closest, dist_c = scenario_derby_util.normalPoint(seg_a, seg_b, circle)
				if dist_c > cr then
					if vData.target ~= "point" and vData.target ~= "line" then
						vData.targetObj = nil
				end
				elseif dist_c <= 0 then
			
				else
					local dx = pos.x - circle.x
					local dy = pos.y - circle.y
					local l = math.sqrt(dx * dx + dy * dy)
					local k = (cr * 2) / l
					offset.x = circle.x - dy * k
					offset.y = circle.y + dx * k
					offset.z = circle.z
					print(dist_c)
					--offset = dist_v /dist_c * (cr - dist_c)
					--local t = offset + circle
					--debugDrawer:drawSphere(offset:toPoint3F(), 0.5, ColorF(1,1,1,1))
					vData.targetObj = offset
					vData.target = "point"
				end
			end
		end
	end
end

local function checkCollisions()
	
	local vInList = scenario_derby_main.vehIn
	for _,vName in pairs(vInList) do
		local vData = scenario_derby_vehicles.vehicleData[vName]
		local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions
			local targetID = nil
			if vData.target == "point" or vData.target == "line" then		
			else
				local to = scenetree.findObject(vData.target)
				if to.obj and to.obj:getID() then
					targetID = to.obj:getID()
				end
			end
			if aiCollisions ~= nil then
				--dump (aiCollisions)
				for k,_ in pairs (aiCollisions) do
				--if targetID then print(k.." "..targetID) end
				if k == targetID then		
					vData.hitTarget = true
				end			 
				if not scenario_derby_vehicles.sVehiclesID[k] then
				--print(k)
				else
					vData.lasthit = true
				end 
			end	
		end
	end
end
-------------------------------------------------------------------------------------
--RETURNS A TARGET FOR THE AI  *vNotToTarget - set AI to not target itself
-------------------------------------------------------------------------------------
local function findTarget()
	local vInList = scenario_derby_main.vehIn
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _,vNotToTarget in pairs(vInList) do
		local vMap = map.objects[map.objectNames[vNotToTarget]]
		local vData = scenario_derby_vehicles.vehicleData[vNotToTarget]
		local targetList = {}
		local cCount = vData.cCount
		if cCount < 1 then
			local point = scenario_derby_util.findRandomPoint()
			local tDist = vec3(vMap.pos):distance(vec3(point))
			if tDist > 20 then
				vData.targetObj = point
				vData.target = "point"
				vData.cCount = cCount + 1
			else
				if sVehicles[user] then
					vData.target = user 
				else 
					for _, vList in pairs(sVehicles) do
						if vList ~= vNotToTarget then
							table.insert(targetList, vList)
						end	
						local rt = tableChooseRandomKey(targetList)
						vData.target = targetList[rt]						
					end
				end	
			end
		else
			local lastbest = {}
			local bestTargetVec = 0
			for _, vList in pairs(sVehicles) do
				if vList ~= vNotToTarget then
					local tpos = map.objects[map.objectNames[vList]].pos
					local targetVec = (vec3(tpos) - vec3(vMap.pos)):normalized()
					local dirVec = vMap.dirVec
					local i = math.abs(dirVec:dot(targetVec))			
					if i >= bestTargetVec then
						lastbest[vList] = i					
						bestTargetVec = i
					end
				end
			end
			for vList,i in pairs(lastbest) do
				if i == bestTargetVec then  
					table.insert(targetList, vList)
				end
			end
			local rt = tableChooseRandomKey(targetList)
			vData.target = targetList[rt]
		end
	end
end	
-------------------------------------------------------------------------------------
--AI CODE
-------------------------------------------------------------------------------------
local function update()	
	findTarget()
	checkCollisions()
	checkWalls()
	aiPursuit()
	counts()
	drive()
end	
	--	if brake > 0 then
		--	pos.y = pos.y - brake
		--	debugDrawer:drawSphere(pos:toPoint3F(), 0.5, ColorF(1,1,1,1))
		--else
		--	pos.y = pos.y + throttle
		--	debugDrawer:drawSphere(pos:toPoint3F(), 0.5, ColorF(1,1,0,1))
	--	end
		--print(collision)
		--print("collision")
		--print(backup)
		--print("backup")
		--print(hitTarget)
		--print("hitTarget") 
		--print(lasthit) 
		--print("lasthit")
		--print(brake .. " " .. throttle)
		--print(dirTarget.. "dirTarget ".. dirDiff .. "dirDiff ")
		--guihooks.trigger('DerbyPlaceChange', { one = dirTarget, two = throttle, three = brake} )	
		--local vObj = scenetree.findObject(vName)
		--if collision == true then 
		--	vObj:queueLuaCommand('input.event("throttle", '..throttle..', 2)')
		--	vObj:queueLuaCommand('input.event("brake", '..brake..', 2)')
		--end
		--if vObj then
		--	vObj:queueLuaCommand('input.event("steering", '..-dirDiff..', 1)')
		--end
		--print("throttle".. throttle.. "brake ".. brake.. " " .. vName .. " " ..target.."")
		--local wheelSlip = scenario_derby_wheels.slipHigh()
M.update = update

return M