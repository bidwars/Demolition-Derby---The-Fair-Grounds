local M = {}
	M.vehIn = {}

local function vehInRequest()
	obj:queueGameEngineLua("gdcallback.request("..tostring(objectId)..')')
end
local function vehInCallBack(vehIn)
	M.vehIn = vehIn
end

M.vehInRequest = vehInRequest
M.vehInCallBack = vehInCallBack
return M