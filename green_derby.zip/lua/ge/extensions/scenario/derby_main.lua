-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
local helper = require('scenario/scenariohelper')

--Vehicle Info
local lastPosition = {} --Last position of the vehicle
local maxStopTicks = 700 --was 700 --About 60 seconds --Max number of times the onPreRender(dt) loops before the vehicle is counted out

local user = "Hawk"

--Delay Start
local countDown = false -- Used with delayStart to have a timer for when to resume
local delayStart = false  --Used Delay the Start of the scenario until everything has loaded
local loadDone = false --Used to Start the scenario when loading is done
local trackType = nil  -- derby or race

--Modules
M.wp1 = 0
M.wp2 = 0
M.lapsEntered = 10 --Default number of laps for racing
M.vehicleCountEntered = 0
M.vehicleClass = 0
M.includeMods = 0
M.vehicleConfig = 0	
M.Arena = 0	
M.vehiclePick = 0
M.stopTicks = {}
M.vehIn = {}
require('mathlib')

-------------------------------------------------------------------------------------
--GET A LIST OF WAYPOINTS ON THE MAP
-------------------------------------------------------------------------------------
local function findWP()  
local wpNum1 = 1  --Default Grass
local wpNum2 = 2
local Arena = M.Arena
	if Arena == 2 then --Concrete
		wpNum1 = 3
		wpNum2 = 4
	elseif Arena == 1 then -- Free Fall
		wpNum1 = 5
		wpNum2 = 6
	elseif Arena == 7 then  --Oval Track
		wpNum1 = 7
		wpNum2 = 8
	elseif Arena == 8 then --Concrete Figture 8
		wpNum1 = 3
		wpNum2 = 4
	elseif Arena == 4 then -- Varied Ground
		wpNum1 = 9
		wpNum2 = 10
	elseif Arena == 5 then --Oval Dirt Derby
		wpNum1 = 11
		wpNum2 = 12
	elseif Arena == 6 then --Mud Pit 
		wpNum1 = 13
		wpNum2 = 14
	end
	M.wp1 = wpNum1 
	M.wp2 = wpNum2 
end
-------------------------------------------------------------------------------------
--GET THE NUMBER OF AI VEHICLES, ARENA SELECTED, AND STATE FROM THE demo_derby.js FILE
-------------------------------------------------------------------------------------
local function Selection(enteredCount,class,mods,vList,state,arena)
	print("Vehicle Count "..enteredCount)
	print("Class "..class)
	print("Mods "..mods)
	print("State "..state)
	print("Arena "..arena)
	if vList == nil then vList = 1 end
	print("Vehicle List "..vList)
	M.vehicleCountEntered = tonumber(enteredCount)
	M.vehicleClass = tonumber(class)
	M.includeMods = tonumber(mods)
	M.vehicleConfig = tonumber(state)	
	M.Arena = tonumber(arena)
	if M.Arena < 7 then 
		trackType = 'derby'
	else 
		trackType = 'race'
	end
	M.vehiclePick = tonumber(vList)
	scenario_derby_classes.modelName()
	--dump(derby_classes.dataList)
	return scenario_derby_classes.dataList
end
local function lapSelection(enteredLaps)
	--print("laps "..enteredLaps)
	M.lapsEntered = tonumber(enteredLaps)
end
local function setPlayer()
	local player = scenetree.findObject(user)
	if player then
		be:enterVehicle(0, player.obj)
		commands.setCameraPlayer()	
		scenario.focusSlot = player.obj:getID()
		scenario_derby_vehicles.freezeAll(1,user)
	end
end
-------------------------------------------------------------------------------------
--SCENARIO START
-------------------------------------------------------------------------------------
local function onScenarioChange(sc)
	scenario = sc
	if not scenario then return end
	if scenario.state == 'pre-start' and delayStart == false then
		--Set the default partsconfig
		Selection(4,3,1,1,3,3)
		scenario_derby_vehicles.partsConfig(true)
	end
	if scenario.state == 'running' and delayStart == false then			
		scenario_derby_vehicles.createVehicles()
		if trackType == 'race' then
			scenario_derby_race.createRoads(scenario)
			scenario_waypoints.initialise(scenario)
		else
			scenario.lapCount = 1
		end
		
		findWP()
		extensions.hook("onRaceInit")
		setPlayer()
		delayStart = true
	end
end
local function setStart()
	scenario_derby_vehicles.setupVehicles()
	loadDone = true
end
 ------------------------------------------------------------------------------------
 --WHEN THE SENARIO COUNTDOWN TIMER REACHES GO!
 ------------------------------------------------------------------------------------
local function onCountdownEnded()
	setStart()
	countDown = true
end
local function fail(result)
	print("fail")
	scenario_scenarios.finish({failed = result})
end
local function success(result)
	print("success")
	scenario_scenarios.finish(result)
end
local function onPhysicsPaused()
	loadDone = false
end
local function onPhysicsUnpaused()
	local clone = scenario_derby_vehicles.findClone()
	if clone == 1 then
		scenario_derby_vehicles.nameClone()
		setPlayer()
		setStart()
	end	
	if countDown == true then
		loadDone = true
	end
end
local function removeRecord(t,vName)
	local i = nil
	for k,v in ipairs(t) do
		if v == vName then
			i = k
		end
	end
	table.remove(t, i)
end
local function addStopTicks()
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _, vName in ipairs(sVehicles) do	
		local vObj = scenetree.findObject(vName)
		if vObj then
			local pos = vObj:getPosition()
			vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
			vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
			local stopTicks = M.stopTicks[vName] 
			if stopTicks ~= nil then
				local wp1 = scenetree.findObject('wp_' ..M.wp1):getPosition()
				if lastPosition[vName] == nil then lastPosition[vName] = pos end
				local distance =  math.abs((pos - lastPosition[vName]):len())
				if pos.z < wp1.z - 2 then
					stopTicks = maxStopTicks
				elseif distance > 0.4 then
					--vehicles still moving
					lastPosition[vName] = pos
					stopTicks = 0			
				else
					--Add one stop tick to the vehicles stop ticks
					stopTicks = stopTicks + 1 
				end
				--If they reach the max stop ticks then they are out
				if stopTicks > maxStopTicks  then	
					local driverName
					if vName ~= user then
						driverName = scenario_derby_vehicles.driver[vName]
					else
						driverName = user
					end
					local msg = driverName .. ' has been called out!'
					helper.flashUiMessage(msg, 3)
					removeRecord(M.vehIn,vName)
					removeRecord(scenario_derby_vehicles.sVehicles, vName)
					scenario_derby_vehicles.freezeAll(1,vName)
				end
				M.stopTicks[vName] = stopTicks			
			end
		end
	end
end
--check if Scenario is finished display message
local function onRaceResult()
	local sVehicles = scenario_derby_vehicles.sVehicles
	local vehIn = #sVehicles
	for _,vName in ipairs(sVehicles) do
		local lap = scenario_derby_vehicles.pathData[vName].lapCount
		if lap > scenario.lapCount or vehIn == 1 then		
			loadDone = false
			if trackType == 'race' then
				scenario_derby_airace.lapWrite()
			else
				scenario_derby_aiderby.update('stop')
			end
			
			local place = scenario_derby_race.racePlace
			local result = nil
			if vName == user then
				result = {msg = 'You Won!'}
				if trackType == 'race' then
					result = {msg = '1st Place! ' .. place[1].driver..' / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' ' }
				end
				success(result)
			else
				local driverName = scenario_derby_vehicles.driver[vName]
				result = 'The driver '..driverName..' has won.'
				fail(result)
			end	
		end
	end
end
---------------------------------------------------------------------------------------
--MAIN SCENARIO TIMER LOOP 
-------------------------------------------------------------------------------------------
local function onPreRender(dt)
	if loadDone == false then return end
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _,vName in ipairs(sVehicles) do
		local vMap = map.objects[map.objectNames[vName]]
		if not vMap then return end
	end
	addStopTicks()
	--Get the ai moving 
	
	if trackType == 'race' then
		guihooks.trigger('ShowApps', true)
		scenario_derby_airace.update(scenario)
		scenario_derby_race.checkPoints()
		scenario_derby_race.updatePlace()
	else
		scenario_derby_aiderby.update()
	end	
	onRaceResult()	
end
-------------------------------------------------------------------------------------
--TRIGGERED ANYTIME THE SENARIO IS RESTARTED
-------------------------------------------------------------------------------------
local function onScenarioRestarted()
	setPlayer()
	  
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
		for k, vName in pairs(sVehicles) do	
			if vName ~= user then
				log('D', 'scenario', "Deleting Vehicle "..vName)
				scenario_derby_vehicles.deleteVehicles(vName)
			else
				scenario_derby_vehicles.partsConfig(true)
			end
		end
			
	M.stopTicks = {}
	M.vehIn = {}	
	delayStart = false
	loadDone = false
	M.stopTicks = {} 
	M.vehIn = {}
	lastPosition = {}
	
	local countDown = false -- Used with delayStart to have a timer for when to resume
	local objName = nil
	local obj = nil
	local unload = false
	objName = "dirttrackwp"	
	obj = scenetree[objName]
	if obj then
		unload = true
	else	
		objName = "fig8concretewp"
		obj = scenetree[objName]
		if obj then
			unload = true
		end		
	end
	if unload == true then 
		obj:unload()
		obj:delete()
	
		be:reloadCollision()
		log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
	end
	
end
M.Selection = Selection
M.lapSelection = lapSelection
M.onRaceTick = onRaceTick
M.onScenarioChange = onScenarioChange
M.onCountdownEnded = onCountdownEnded
M.onRaceResult = onRaceResult
M.onPhysicsPaused = onPhysicsPaused
M.onPhysicsUnpaused = onPhysicsUnpaused
M.onPreRender = onPreRender
M.onScenarioRestarted = onScenarioRestarted
--M.wheelDataCallback = wheelDataCallback


return M