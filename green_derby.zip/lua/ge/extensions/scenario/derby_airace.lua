---------------
----------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
local helper = require('scenario/scenariohelper')
local raceMarker = require("scenario/race_marker")
require('mathlib')
local vdata = {}
--local data = {}
local Arena = 0
M.mapPath = {}
local saveData ={}
M.elec = {}
local pathData = {}
M.bestTime = math.huge
local newbestTime = false
local user = "Hawk"
local newPath = 1
local writethrottle = {}
local writebrake = {}
local startTimer = {}
local abs, floor, min, max, stringformat, tableconcat = math.abs, math.floor, math.min, math.max, string.format, table.concat

local function seeks(vName)
	local data = scenario_derby_vehicles.vehicleData[vName]
	local tpos = data.target 
	--local pos = vdata.pos + vdata.vel
	local dirDiff, dirTarget = scenario_derby_util.vec2Diff(tpos,nil,vdata.pos,vdata.dirVec, vdata.vel)
	return dirDiff, dirTarget
end
local function encodefile(v)
	local vtype = type(v)
	
	-- Handle strings
	if vtype == 'string' then
		return stringformat('%s', v)
	end
	
	-- Handle numbers and booleans
	if vtype == 'number' then
		if v == v + 1 then -- test for inf
		if n == math.huge then
			return '"inf"'
		elseif n == -math.huge then
			return '"-inf"'
		end
		else
		return tostring(v)
		end
	end
	
	-- Handle tables
  if vtype == 'table' then
    if next(v) ~= 1 then
      local tmp = {}
      local tmpidx = 1
      for kk, vv in pairs(v) do
        tmp[tmpidx] = stringformat('%q:%s', kk, encodefile(vv))
        tmpidx = tmpidx + 1
      end
      return stringformat('%s', tableconcat(tmp, ''))
    else
      local vcount = #v
      local tmp = table.new(vcount, 0)
      for i = 1, vcount do
        tmp[i] = encodefile(v[i])
      end
      return stringformat('%s', tableconcat(tmp, ''))
    end
  end
  
  if vtype == 'boolean' then return tostring(v) end

  return "null"

end
local function writeFile(filename,obj)
	local f = io.open(filename, "w")
	if f then
		local content
		content = encodefile(obj)
		
		f:write(content)
		f:close()
		return true
	end
	return false
end
local function lapInfo()
	local p = newPath
	local save = string.format('levels/derby/racedata/road'..p..'.txt')
	local file = {}
	
	for v,t in pairs(M.mapPath[p].road)do
	
		file[v] = 'node = "'..t.posx..' '..t.posy..' '..t.posz..' '..t.radius..'";\r'
	end
	writeFile(save,file)
end
local function lapWrite()
	if newbestTime == true then
		local p = newPath
		local bestTime = M.bestTime
		local t = string.format('levels/derby/racedata/lap'..Arena..'.json')
		local l = string.format('levels/derby/racedata/time'..Arena..'.json')
		serializeJsonToFile(t, bestTime)
		serializeJsonToFile(l, M.mapPath[p].road, true)
	end
end
local function separate(steer)
	local tdata = map.objects
	local pos = vec3(vdata.pos)
	local sum = nil
	local count = 0 
	local radius = 4
	local maxspeed = 1
	local closest = math.huge
	local cv = nil
	
	for id,v in pairs(tdata) do
		--local nt = scenetree.findObjectById(id)
		--if nt ~= vName then
		local tpos = vec3(v.pos)
		local d = pos:distance(tpos)
			--print(steer)
		local tv = (pos - tpos):normalized()
		local dirTarget = vdata.dirVec:dot(tv)
		--print(dirTarget)
		--print(d)
		if dirTarget < .50 then
			if d > 1 and d < radius then
				closest = d
				cv = id
			end
		--end
		end
	end
	if cv then
		
		local tobj = scenetree.findObjectById(cv)
		local t = tobj.name
		--print(tobj.name)
		local tdatai = map.objects[map.objectNames[t]]
		local right = vdata.dirVec:cross(vdata.dirVecUp)
		local targetVec = (pos - tdatai.pos):normalized()
		local rightorleft = right:dot(targetVec)
		--print(rightorleft)
		if rightorleft < 0 then
			--print("onright")
			steer = steer +.20 
		else
			--print("onleft")
			steer = steer -.20
		end
			
	
	end
	
return steer
end
local function collisions(vName)
	local aiCollisions = map.objects[map.objectNames[vName]].objectCollisions

	if aiCollisions ~= nil then
			--dump (aiCollisions)
			for k,v in pairs (aiCollisions) do
				local tobj = scenetree.findObjectById(k)
				local pos = tobj:getPosition()
				local posv3 = vec3(pos)
				
				return true, posv3
			end
	else 
		return false
	end
end
local function applyBehaviors(vName)
	local data = scenario_derby_vehicles.vehicleData[vName]
	local steer, dirTarget = seeks(vName)
	--if vName == user then
	steer = separate(steer)
	--end
	local brake = 0 --data.brake 
	local throttle = 0 --data.throttle
	local timeData = scenario_derby_vehicles.timeData[vName]
	--dump(elec)
	local stopTicks = scenario_derby_main.stopTicks[vName]
	local vel = vdata.vel:length()
	local pbrake = 0
	local collision = scenario_derby_vehicles.vehicleData[vName].collision
	local sDist = scenario_derby_vehicles.vehicleData[vName].sDist
	local psteer = math.abs(steer)
	
	if stopTicks > 50 or collision == true then
		local newt = data.throttle
		local newb = data.brake 
		if collision == false or stopTicks == 110 then
			sDist = vdata.pos
			if newt > 0  then	
				brake = 0.4
				throttle = 0
			elseif newb > 0 then 
				throttle = 0.4
				brake = 0
			end
			collision = true
		else 
			
			local crashDis = vdata.pos:distance(sDist)
			--if vName == user then
			--print(crashDis.." Distance")	
			--end
			
			if crashDis > 2 then
				brake = 0 
				throttle = 0
				steer = 0
				pbrake = 1
				collision = false
			else
				brake = newb 
				throttle = newt
				steer = 0
			end
			
		end
	else
		pbrake = 0 
		local maxt = 1
		local maxb = 1
		local maxv = 8
		if Arena == 7 then
			maxv = 13
		end
		local dist = pathData.dist
		local distP = data.tDist / dist
		local steerAngle = psteer / 1.55
		local lastTime = timeData.lastTime
		if data.cCount > 12 then
			--if vel >= 5 then 
				--throttle = data.cCount - 12
				--throttle = maxt / distP
				--throttle = throttle  - (throttle * steerAngle)
				--if throttle < 0 then 
				--	throttle = 0 
				--end
				
			--end 
			brake = 0 
		elseif data.cCount >= 11 then
			if vel > 3 then
				brake = data.cCount - 11
			end
			throttle = 0
		else
			
			--if vel < maxv then
				--throttle = (maxt - steerAngle) * .20
			--end
				--throttle = throttle * steerAngle
			--end
			--throttle = 0
			--brake = 0 
			
		end
			if vel < maxv  then
				local lap = pathData.lapCount
				local cpCount = pathData.cpCount
				if lap <= 1 and cpCount < 4 and Arena == 7 then
					throttle = 0.2
				else
					throttle = maxt - steerAngle
					if psteer > .22 then	
						throttle = throttle * (maxt - (vel / maxv))
						if psteer > 1 and vel > 3 then
							throttle = 0
							if psteer > 1.3 then
								brake = 0.2
							end
						end
					
					end
					--throttle = throttle * distP
				end
			else 
				if psteer < .1 then
					throttle = maxt - steerAngle
				end
			end	
		
	end	
	if throttle > 1 then 
		throttle = 1
	else
		if throttle < 0 then
			throttle = 0
			end
	end
	if brake > 1 then 
		brake = 1 
	else
		if brake < 0 then
			brake = 0
		end
	end
		--if vName == user then
			--local tex = vdata.pos + vec3(0, 0, 2)
			--local tex2 = vdata.pos + vec3(0, 0, 3)
			--local tex3 = vdata.pos + vec3(0, 0, 4)
			--debugDrawer:drawText(tex:toPoint3F(), String(vel), ColorF(0,0,0,1))
			--debugDrawer:drawText(tex2:toPoint3F(), String(psteer), ColorF(0,0,1,1))
			--debugDrawer:drawText(tex3:toPoint3F(), String(throttle), ColorF(0,1,1,1))
		--end
		if vName ~= user then
			scenario_derby_vehicles.driveCar(vName,-steer,throttle or 0,brake or 0,pbrake)--------------------------------------------------------------------------------	
		end
		scenario_derby_vehicles.vehicleData[vName].collision = collision
		scenario_derby_vehicles.vehicleData[vName].brake = brake
		scenario_derby_vehicles.vehicleData[vName].throttle = throttle
		scenario_derby_vehicles.vehicleData[vName].sDist = sDist 
		
		
end
local function trackTime(vName, steer)	
	scenario_derby_wheels.electrics(vName)
	local elec = M.elec
	local data = scenario_derby_vehicles.vehicleData[vName]
	local brake = data.brake 
	local throttle = data.throttle
	local vel = vdata.vel
	local pos = vdata.pos
	local dist = data.target:distance(pos)
	local timeData = scenario_derby_vehicles.timeData[vName]
	local playerpos = ""..pos.x.." "..pos.y.." "..pos.z..""
	local targetpos = "" ..data.target.x.. " " ..data.target.y.."" 
		
		--Time Data
		
		local timeDiff = timeData.timeDiff   
		local lastTime = timeData.lastTime
		local lapTime = timeData.lapTime
		local i = timeData.index
		
		--Path Data
		local nodeCount = pathData.nodeCount  --current checkpoint
		local cpLastPos = pathData.cpLastPos   --previous checkpoint
		
		if vName == user then
		--	print(data.dtCount.." ".. data.throttle.. " " ..data.cCount)		
			--print(i.. " " .. playerpos)
		end
		
		if data.dtCount == 1 then
			if lastTime == 0 then
				lastTime = scenario.timer  -- start timer
			end
			if startTimer[vName] == false then
				--print("Timer Start")
				startTimer[vName] = true
			end
		end
		if data.dtCount == nodeCount  then
			if startTimer[vName] == true then
				--print("Time End of Lap")
				local curTime = scenario.timer      --  current  time in scenario curTime
				lapTime = curTime - lastTime  -- add time
				lastTime = curTime
				--print(lapTime)
			end
			
			--fastest lap
			if lastTime > 0 and startTimer[vName] == true and lapTime > 10 and lapTime < M.bestTime  then
				M.bestTime = lapTime
				newbestTime = true
				print("New Best Lap Time".. M.bestTime.. " " ..vName.." ")
				local p = pathData.line
				p = p + 1
				local num = #saveData[vName]
				for id,q in ipairs(saveData[vName]) do
					local radius = 0
					
					if q.eThrottle > 0.00 then
						radius = 12 + q.eThrottle
					elseif q.eBrake > 0.00 then
						radius = 11 + q.eBrake
					else	
						radius = 10
					end
					if id == 1 then
						M.mapPath[p] = {road = {}}
						radius = 12.2
					end
					local link = id
					if link == num then
						link = 1
					else
						link = link + 1
					end
						
					M.mapPath[p].road[id] = {
						node = id, 
						pos = q.pPos,
						posx = q.pPos.x, 
						posy = q.pPos.y, 
						posz = q.pPos.z,
						radius = radius, 
						links = link, 
						segTags = {}
						}
				end
				--dump(M.mapPath[p].road)
				newPath = p
				lapInfo()
			end
			lapTime = 0
			startTimer[vName] = false
			i = 1
			if pathData.line ~= newPath then
				pathData.line = newPath
				scenario_derby_vehicles.vehicleData[vName].lCount = 0
			end
		end	
		
		if i == 1 then
			saveData[vName] = {}
			cpLastPos = vdata.pos  --save the current pos
		end
		local dist = vdata.pos:distance(cpLastPos)
		if dist > 1 or i == 1  then
			cpLastPos = vdata.pos
			--local wdt = false
			--local wdb = false
			--if elec.throttle and elec.throttle > 0 then
			--	writethrottle[vName] = elec.throttle
			--else
			--	if writethrottle[vName] and writethrottle[vName] > 0 then
			--		wdt = true
			--	end
			--end
			--if elec.brake and elec.brake > 0 then
			--	writebrake[vName] = elec.brake
			--else 
			--	if writebrake[vName] and writebrake[vName] > 0 then
			--		wdb = true
			--	end
		--	end
		--	if wdb == true or wdt == true then
			saveData[vName][i] = { 
				Index = i,
				Name = vName,
				--LapTime = lapTime,
				pPos = pos,
				--Pointcp = cpPoint,
				--Vel = vel:length(),
				--TargetDir = dirTarget,
				eThrottle = elec.throttle or 0,
				--Throttle = throttle,
				eBrake = elec.brake or 0
				--Brake = brake,
				--eSteer = elec.steering or 0,
				--Steer = steer,
				--Tick = stopTicks,
				--tPos = targetpos,
				--tDis = dist
					}
			i = i + 1 
			--end
		end
		
		timeData.lastTime =  lastTime
		timeData.lapTime = lapTime
		pathData.cpLastPos = cpLastPos
		timeData.index = i 
		--timeData.timeDiff = timeDiff	
end
local function debug(test, vName, radius)
	local data = scenario_derby_vehicles.vehicleData[vName]
	if data.target ~= nil then
		
		if data.cCount > 12 then
			debugDrawer:drawSphere(data.target:toPoint3F(), radius, ColorF(0,0,1,0.3))
		elseif data.cCount > 11 then
			debugDrawer:drawSphere(data.target:toPoint3F(), radius, ColorF(0,1,0,0.3))
		else
			debugDrawer:drawSphere(data.target:toPoint3F(), radius, ColorF(1,0,0,0.3))
		end
	end
	if test ~= nil then
		debugDrawer:drawSphere(test:toPoint3F(), 1, ColorF(1,0,0,0.3))
	end
end
local function followPath(vName)
	local data = scenario_derby_vehicles.vehicleData[vName]
	local p = pathData.line
	local mapData = M.mapPath[p]
	local dist = vec3(data.target):distance(vdata.pos)
	local node = mapData.road[data.dtCount]
	if not node then return end
	--dump(node)
	
	local r = data.cCount
	if Arena == 7 then 
		r = r * 1.5
	else
		r = r - 2
	end
	
	--if vName == user then debug(vec3(mapData.road[1].pos),vName, r) end
	
	if dist < r then 
		--dump(mapData)
		scenario_derby_vehicles.vehicleData[vName].dtCount = node.links
		scenario_derby_vehicles.vehicleData[vName].target = node.pos
		scenario_derby_vehicles.vehicleData[vName].cCount = node.radius
		scenario_derby_vehicles.vehicleData[vName].tDist = dist
	end
	pathData.dist = dist --we take the node distance and divide by the throttle amount
end
local function startPath(vName)
	local data = scenario_derby_vehicles.vehicleData[vName]
	local p = pathData.line
	local mapData = M.mapPath[p]
	local bestNode = {}
	local largeDis = math.huge
	local bestdTarget = 0
	if not mapData then return end
	pathData.nodeCount = table.maxn(mapData.road)
	--print(pathData.nodeCount)
	for _,nodeList in ipairs(mapData.road) do
		--if the node list is along the starting line and is a throttle node and it is the longest away from my position. 
				
		if nodeList.radius > 12.00 then  
		local pos = nodeList.pos
		local targetVec = (pos - vdata.pos):normalized()
			local dirTarget = vdata.dirVec:dot(targetVec)
			if dirTarget > -.1 then
				local dist = pos:distance(vdata.pos)
				if dist < largeDis then
					if dirTarget > bestdTarget then
						bestNode = nodeList
						largeDis = dist
						bestdTarget = dirTarget
						--print(nodeList.node.." "..dist.." "..dirTarget)
					end
				end
			end
		end
	end
			
	if bestNode.node then
		local pos = bestNode.pos
		local dist = pos:distance(vdata.pos)
		pathData.dist = dist
		scenario_derby_vehicles.vehicleData[vName].target = pos
		scenario_derby_vehicles.vehicleData[vName].dtCount = bestNode.node
		scenario_derby_vehicles.vehicleData[vName].cCount = bestNode.radius
		scenario_derby_vehicles.vehicleData[vName].lCount = 1
	end			
end
local function initial(vName)
 	--map.objects returns objId, isactive, pos, vel, dirVec, dirVecUp, damage, objectCollisions
		vdata = map.objects[map.objectNames[vName]] 
		--data = scenario_derby_vehicles.vehicleData[vName]
		pathData = scenario_derby_vehicles.pathData[vName]
		if not M.mapPath[1] then scenario_derby_race.getRoads() return end
end
local function update(sc)
	scenario = sc
	Arena = scenario_derby_main.Arena 
	
	--Update Data
	local sVehicles = scenario_derby_vehicles.sVehicles
	for _,vName in ipairs(sVehicles) do
		scenario_derby_race.checkPoints(vName,scenario)
		if vName == user then
			raceMarker.hide(true)
		end
		initial(vName)
			
		if not vdata then return print("novdata") end
		if scenario_derby_vehicles.vehicleData[vName].lCount == 0 then
			startPath(vName)
		else
			followPath(vName)
		end
		applyBehaviors(vName)
		trackTime(vName)	
	end
end
local function onScenarioRestarted()
	M.mapPath = {}	
	vdata = {}
	saveData ={}
	M.elec = {}
	M.bestTime = math.huge
	newbestTime = false
	newPath = 1
	writethrottle = {}
	writebrake = {}
	startTimer = {}
end

M.update = update
M.lapWrite = lapWrite
M.onScenarioRestarted = onScenarioRestarted 
return M