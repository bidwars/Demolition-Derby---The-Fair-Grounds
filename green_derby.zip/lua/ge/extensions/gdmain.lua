local M = {}
  gdloader = require("gdloader")
  gdcallback = require('gdcallback')
local function onPreRender(dtReal)
	gdloader.updateGFX(dtReal)
end
local function onVehicleSpawned(vehicleID)
	gdloader.onVehicleSpawned(vehicleID)
end
local function onPhysicsPaused()	
	gdloader.onPhysicsPaused()
end

M.onPhysicsPaused = onPhysicsPaused
M.onVehicleSpawned = onVehicleSpawned
M.onPreRender = onPreRender
return M