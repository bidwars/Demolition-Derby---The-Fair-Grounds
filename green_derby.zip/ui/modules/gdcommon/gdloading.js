angular.module('beamng.stuff', ['ngAnimate', 'toastr']);
angular.module('beamng.gameUI', ['ngAnimate', 'toastr']);
angular.module('beamng.garage', []);
angular.module('beamng.color', []);
angular.module('beamng.gamepadNav', []);
angular.module('beamng.controls', []);
angular.module('beamng.ui2Ports', []);

angular.module('BeamNG.ui', ['beamng.ui2Ports', 'beamng.core', 'beamng.components', 'beamng.data', 'ngMaterial', 'ngAnimate', 'ui.router', 'beamng.stuff', 'beamng.gameUI', 'beamng.apps', 'beamng.color', 'beamng.garage', 'pascalprecht.translate', 'beamng.gamepadNav', 'beamng.controls', 'fc.paging','ngSanitize','jkAngularRatingStars'])

.config(['$compileProvider','$log', '$logProvider', 'loggerProvider', '$stateProvider', '$urlRouterProvider', '$mdThemingProvider', '$translateProvider', 'AppDefaults', 'toastrConfig', '$provide',
  function($compileProvider, $log, $logProvider, loggerProvider, $stateProvider, $urlRouterProvider, $mdThemingProvider, $translateProvider, AppDefaults, toastrConfig, $provide) {

	$stateProvider
	console.log('state called ye')
	.state('gdloading', {
		url: '/gdcommon',
		//params: {
			//imagelist: {}
		//},
		templateUrl: 'modules/gdcommon/gdloading.html',
		controller: 'GDloadingController as loading',
		transitionAnimation: 'moduleBlendOnLeave',
	})
}
]);


angular.module('beamng.stuff')
//var app = angular.module('derbyApp', []);
.controller('GDloadingController', ['bngApi', 'logger', '$scope', 'ControlsUtils', 'Hints', 'Utils', 
	function GDloadingController(bngApi, logger, $scope, ControlsUtils, Hints, Utils) {

  var vm = this;

  vm.hintTranslationKey = Hints[Math.floor(Math.random() * Hints.length)];

  vm.simple = (beamng.buildtype !== 'RELEASE' && beamng.buildtype !== 'INTERNAL'); // hides the tips, hotkeys, etc

  vm.progress = { val: '-1', txt: 'loading ...' };

  $scope.$on('UpdateProgress', function (event, data) {
    window.requestAnimationFrame(function () {
      $scope.$apply(function () {
        if (data.txt !== '') {
          vm.progress = data;
        } else {
          vm.progress.val = data.val;
        }
      });
    });
    $scope.$digest();
  });

  bngApi.engineLua(`dirContent("game:/ui/modules/gdcommon/drive/")`, (data) => {
    var files = data.map((elem) => elem.slice('/ui/'.length + (elem.indexOf("game:")==0?'game:'.length:0)));
    var file = files[Utils.random(0, files.length -1, true)];
    $scope.$evalAsync(() => {
      vm.img = file;
      // give angualar a head start to finish running it's digest
      setTimeout(function () {
        // since background images don't fire a load event, we'll simulate one
        var a = new Image();
        a.onload = function () {
          // give the render a head start (ie. wait 2-3 frames)
          Utils.waitForCefAndAngular(() => {
            bngApi.engineLua('core_gamestate.loadingScreenActive()');
          });
        }
        a.src = file;
      });
    });
  });

  vm.helpActions = {};

  var actions = [
    'toggleMenues',
    'toggle_help',
    'reset_physics',
    'accelerate',
    'brake',
    'steer_left',
    'steer_right',
    'switch_camera_next',
    'center_camera'
  ].forEach((elem) => {
    vm.helpActions[elem] = ControlsUtils.findBindingForAction(elem);
  });


  // no infinite loading screen
  var timeout = setTimeout(() => bngApi.engineLua('core_gamestate.loadingScreenActive()'), 10000);

  $scope.$on('$destroy', function () {
    clearTimeout(timeout)
  });
}]);
angular.module('beamng.stuff')
.controller('AppCtrl', ['$document', '$log', 'logger', '$rootScope', '$scope', '$sce', '$compile', '$state', '$translate', '$window', 'AppDefaults', 'Aux', 'bngApi', 'ControlsUtils', 'Utils', 'Settings', 'toastr', '$timeout', 'gamepadNav', 'SimpleStateNav', 'SpatialNavigation', '$injector', '$location',
  function($document, $log, logger, $rootScope, $scope, $sce, $compile, $state, $translate, $window, AppDefaults, Aux, bngApi, ControlsUtils, Utils, Settings, toastr, $timeout, gamepadNav, SimpleStateNav, SpatialNavigation, $injector, $location) {
  var vm = this;
	var transitioningTo;
  
  $scope.$on('ChangeState', function (event, data, ifCurrent) {
    logger.AppCtrl.debug('received ForceStateChange w/', data, ifCurrent, $state.current.name, transitioningTo);
    params = data.params || {};
    state = (typeof data === 'string' ? data : data.state);
    help = (transitioningTo !== undefined && transitioningTo !== $state.current.name ? transitioningTo : $state.current.name);
    if (help === ifCurrent || ifCurrent === undefined || (Array.isArray(ifCurrent) && ifCurrent.indexOf(help) !== -1)) {
      logger.AppCtrl.log(`switching to state: ${state}`);
      stateTransitioning = $state.go(state, params, {reload: true});
    }
  });
 }]);