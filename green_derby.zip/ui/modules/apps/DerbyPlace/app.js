angular.module('beamng.apps')

/**
 * @ngdoc directive
 * @name beamng.apps:derbyPlace
 * @description 
**/
.directive('derbyPlace', function () {  
    return {
	template: 
		'<div ng-class="{\'bngApp\' : data}" style="width: 100%; height: 100%; font-size: 1.4em;" ' +		
				'layout="column" layout-align="center center">' +
        '<span ng-if="data">Place 1st {{ data.one }} <br> 2nd {{ data.two }} <br> 3rd {{ data.three }}</span>' +
      '</div>',
    replace: true,
    link: function (scope, element, attrs) {
      scope.data = null;
      scope.$on('DerbyPlaceChange', function (event, data) {
        if(data === null) return; 
        scope.$applyAsync(function () { 
          scope.data = data;
        });
      });

      scope.$on('ScenarioNotRunning', function () {
        scope.data = null;
      });
    }
  };
});