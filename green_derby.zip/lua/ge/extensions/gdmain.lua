local M = {}
  gdloader = require("gdloader")
  gdcallback = require('gdcallback')
local function onPreRender(dt)
	gdloader.updateGFX(dt)
end
local function onVehicleSpawned(vehicleID)
	gdloader.onVehicleSpawned(vehicleID)
end
local function onScenarioChange(sc)
	gdloader.onScenarioChange(sc)
end
local function onPhysicsPaused()
	gdloader.onPhysicsPaused()
end
local function onPhysicsUnpaused()
	gdloader.onPhysicsUnpaused()
end
local function onCountdownEnded()
	gdloader.onCountdownEnded()
end
local function onScenarioRestarted()
	gdloader.onScenarioRestarted()
end
local function onFreeroamLoaded()
	
end
local function onVehicleDestroyed(vid)
	gdloader.onVehicleDestroyed(vid)
end
local function loadgdscenario()
	extensions.load('scenario_gdscenariosLoader')
	scenario_gdscenariosLoader.scenarioStart()
end

M.loadgdscenario = loadgdscenario
M.onVehicleDestroyed = onVehicleDestroyed
M.onFreeroamLoaded = onFreeroamLoaded
M.onVehicleSpawned = onVehicleSpawned
M.onPreRender = onPreRender
M.onCountdownEnded = onCountdownEnded
M.onScenarioChange = onScenarioChange
M.onPhysicsPaused = onPhysicsPaused
M.onPhysicsUnpaused = onPhysicsUnpaused
M.onPhysicsPaused = onPhysicsPaused
M.onScenarioRestarted = onScenarioRestarted
return M