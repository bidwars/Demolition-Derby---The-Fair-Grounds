-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local customList = {} -- The full list of vehicles 
local helper = require('scenario/scenariohelper')
local vehicles = require('core/vehicles')
local modsFound = true
local includeMods = nil
local dataList = {} -- Filtered list of vehicles selected
-------------------------------------------------------------------------------------
--CREATES A TABLE WITH CUSTOM CONFIGS.  EXAMPLE MODEL_KEY = FULLSIZE  AND KEY = DERBY2MOD
-------------------------------------------------------------------------------------
local function writeCustom(i,cmodel_key,ckey)
	customList[i] = {model_key = cmodel_key,key = ckey}	
	i = i+1
	--print(cmodel_key.. " " .. ckey)
	return i
end
-------------------------------------------------------------------------------------
--CREATES A LIST OF ALL THE VEHICLES IN BEAMNG
-------------------------------------------------------------------------------------
local function customClass()	
	--get a table of all vehicles including mods 
	local configList = core_vehicles.getConfigList().configs
	 local modelsList = core_vehicles.getModelList().models
	--dump(configList)
	local i = 1

	for _,c in pairs(configList) do
		if modelsList == nil or modelsList[c.model_key] == nil then
                log("E", logTag, "Model Info  not found for model ='"..c.model_key .."'") 
        else
			local modelInfo = modelsList[c.model_key]
			if includeMods == 5 then --All Mods and Beamng Offical
				if modelInfo.Type == 'Truck' or  modelInfo.Type == 'Car' or modelInfo.Type == 'Bus' or modelInfo.Type == 'Automation' then
					i = writeCustom(i,c.model_key,c.key)
				end
			else
				if c.Source == "Mod" then
					local s = c.key
					if includeMods == 3 then  --F150 Mod
						if string.startswith( s, "derby" ) or string.startswith(s,"banger") or string.startswith(s,"duke") or string.startswith(s,"239a") then
							i = writeCustom(i,c.model_key,c.key)
						end
					elseif includeMods == 4 then --Peter Beamo Mod
						if string.startswith( s, "beamo" ) then
							i = writeCustom(i,c.model_key,c.key)
						end
					elseif includeMods == 2 and modelInfo.Type == 'Truck' or  modelInfo.Type == 'Car' or modelInfo.Type == 'Bus' or modelInfo.Type == 'Automation'then  --All Mods 
						i = writeCustom(i,c.model_key,c.key)
					end
				end	
			end
		end
	end
end
local function reset()
	dataList = {}
	customList = {}
end
-------------------------------------------------------------------------------------
--GET ONE MODEL_KEY AND KEY 
-------------------------------------------------------------------------------------
local function modelName()
	if modsFound == true then
		includeMods = gdloader.includeMods
	end
	local vehicleClass = gdloader.vehicleClass 
	local model_key = nil
	local key = nil
	local count = 1
	local customFilter = {} --The filtered list of vehicles 
	local saveType = {}
	reset()
	local type = {
			["heavy"] = {semi = 4},
			["truck"] = {pickup = 4, roamer = 4, van = 4 },
			["large"] = {barstow = 4, burnside = 4, fullsize = 4, moonhawk = 4},
			["medium"] = {legran = 4, pessima = 4, midsize = 4, sunburst = 4,  etki = 4},
			["compact"] = {coupe = 4, hatch = 4, pessima = 4, sunburst = 4, miramar = 4},
			["luxury"] = {etkc = 4, etk800 = 4, super = 3, sbr = 2},	
			["pigeon"] = {pigeon = 4},
			["randomv"] = {pigeon = 4, pickup = 4, roamer = 4, van = 4, barstow = 4, burnside = 4, fullsize = 4, moonhawk = 4, legran = 4, pessima = 4, midsize = 4, sunburst = 4, coupe = 4, hatch = 4, etki = 4, miramar = 4, etkc = 4, etk800 = 4, super = 3, sbr = 2}
			}
	if vehicleClass == 8 then --Random
		if includeMods > 1 then 
			saveType = "randomv"
		else 
			saveType = type.randomv
		end
	elseif vehicleClass == 7 then -- Pigeon
		if includeMods > 1 then 
			saveType = "pigeon"
		else 
			saveType = type.pigeon
		end
	elseif vehicleClass == 6 then -- Luxury Car
		if includeMods > 1 then
			saveType = "luxury"
		else
			saveType = type.luxury
		end
	elseif vehicleClass == 5 then --Compact Car
		if includeMods > 1 then
			saveType = "compact"
		else
			saveType = type.compact
		end
	elseif vehicleClass == 4 then --Medium Car
		if includeMods > 1 then
			saveType = "medium"
		else
			saveType = type.medium
		end
	elseif vehicleClass == 3 then --Large Car
		if includeMods > 1 then
			saveType = "large"
		else
			saveType = type.large
		end
	elseif vehicleClass == 2 then --Truck
		if includeMods > 1 then
			saveType = "truck"
		else
			saveType = type.truck
		end
	elseif vehicleClass == 1 then --Heavy
		if includeMods > 1 then
			saveType = "heavy"
		else
			saveType = type.heavy
		end
	end
	--dump(saveType)
	--print(saveType)
	if includeMods > 1 then --Include Custom Mods
		if customList[1] == nil then
			customClass()  --Creates the CustomList
		end
		for _,t in ipairs(customList) do
			--t.key is name of Mod (derby1,derby2,etc...)
			--t.model_key is name of Model (moonhawk, legran, etc.. )
			if vehicleClass == 8 then  -- 8 is Random
				customFilter[count] = {key = t.key, model_key = t.model_key, types = "None"}
				count = count + 1
			else
				-- cycle the type table to see the values are equal to the customList table.  
				for typeName,typeTable in pairs(type) do --typename is heavy,truck,large,medium,compact,luxury, and randomv
					if typeName ~= "randomv" then
						for typeValue,j in pairs(typeTable) do	
							if typeValue == t.model_key then
								--creates a List of vehicles with index,key,model_key,type   
								customFilter[count] = {key = t.key, model_key = t.model_key, types = typeName}
								count = count + 1
								break
							end
						end
					end
				end
			end				
		end
		count = 1
		if customFilter[1] ~= nill then
			for _,t in ipairs(customFilter) do
				if t.types == saveType or vehicleClass == 8 then
					if count == 1 then
						dataList[count] = {id = count, name = "Auto", type = "Model"}
					end
					count = count + 1	
					dataList[count] = {id = count, name = t.key, type = t.model_key}
				end
			end
		end
		if dataList[2] == nil then 
			includeMods = 1 
			modsFound = false
			modelName()
		end
	else
		count = 1 
		--if No Mods selected
		for modeln,qty in pairs(saveType) do
			for x=1, qty do
				if count == 1 then
					if modsFound == false  then
						dataList[1] = {id = 1, name = "No vehicles found for the selected options. Defaults Listed", type = "---"}
						modsFound = true
					else
						dataList[count] = {id = count, name = "Auto", type = "Model"}
					end
				end
				count = count + 1	
				dataList[count] = {id = count, name = modeln..'('..x..')', type = modeln }
			end
		end
	end
	return dataList
end
-------------------------------------------------------------------------------------
--CREATES A NEW PC FILE WITH PARTS WE NEED TO REMOVE SET TO NONE
-------------------------------------------------------------------------------------
local function deleteParts(data,model_key, partName)
	local partsfile = data
	for _,part in ipairs(partName) do
		local hubcap = string.sub(part, 1, 6)
		if hubcap == "hubcap" then
			partsfile.parts[part] = "none"
		elseif partsfile.parts[model_key..''..part] then
			partsfile.parts[model_key..''..part] = "none"
		end
	end
	return partsfile
end
local function readPartsFile(File)
	local parts = readJsonFile(File)
	if parts then
		return parts
	end
end
-------------------------------------------------------------------------------------
--CREATES THE VEHICLE CLASS PC FILE
-------------------------------------------------------------------------------------
local function loadClass(removePartsFile)
	local vehicleConfig = gdloader.vehicleConfig 
	local vehiclePick = gdloader.vehiclePick 
	local key = nil
	local model_key = nil
	if vehiclePick == 1 or vehiclePick == nil then  --Auto selected
		if dataList[2] ~= nil then
			local numRandom = tableChooseRandomKey(dataList)
			if numRandom == 1 then numRandom = 2 end
			key = dataList[numRandom].name
			model_key = dataList[numRandom].type
		else 
			helper.realTimeUiDisplay("Error Loading Vehicles")
			return
		end
		--print("Random".. key .. model_key)
	else
		key = dataList[vehiclePick].name
		model_key = dataList[vehiclePick].type
		gdloader.vehiclePick = 1 
		--print("Picked".. key .. model_key)
	end
	local saveConfig = nil
	local partConfig = nil
	if includeMods > 1 then -- Mods
			partConfig = string.format('vehicles/'..model_key..'/'..key..'.pc', model_key, key)  
			saveConfig = string.format('vehicles/'..vehicleConfig..'_vehicles/'..model_key..'/v1'..key..'.pc', model_key, key)
	else
		--local number = tonumber(string.match(model_key, "%d+"))
		local setup
		if vehicleConfig == 5 then
			setup = "stock"
		elseif vehicleConfig == 4 then 
			setup = "pro"
		else 
			setup = "basic"
		end
		partConfig = string.format('vehicles/'..model_key..'/'..setup..'_'..key..'.pc', model_key, key)
		saveConfig = string.format('vehicles/'..vehicleConfig..'_vehicles/'..model_key..'/'..setup..'_v1'..key..'.pc', model_key, key)
	end
	if vehicleConfig > 2 then --stock, pro, basic
		return model_key, partConfig
	else
		local partsData = readPartsFile(partConfig)
		
		if vehicleConfig <= 2 then --Stripped
			partsData = deleteParts(partsData,model_key,removePartsFile.stripped)
		end
		if vehicleConfig == 1 then --Low-End
			partsData = deleteParts(partsData,model_key,removePartsFile.lowend)
		end
		serializeJsonToFile(saveConfig, partsData, true)
		--print("loaded "..vName.." config"..JBeam.." "..model_key.."")
		return model_key, saveConfig
	end
end

M.readPartsFile = readPartsFile
M.loadClass = loadClass
M.onScenarioRestarted = onScenarioRestarted
M.modelName = modelName
return M