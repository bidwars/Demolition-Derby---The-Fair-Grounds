
var app = angular.module('derbyApp', []);
app.run(function() {
  console.log('Derby App Started');
});

app.factory('$localstorage', ['$window','bngApi', function($window,bngApi) {
  return {
	saveObject: function(key,value) {
		bngApi.engineLua('gdcallback.saveObject(' + bngApi.serializeToLua(key) + ',' + bngApi.serializeToLua(value) + ')');
	},
	saveTable: function(table) {
		bngApi.engineLua('gdcallback.saveTable(' + bngApi.serializeToLua(table) + ')');
	},
	loadObject: function(key, defaultValue,saved) {
		if(saved !== null){
			if (saved[key] !== undefined){
				//console.log('key not null');
				//console.log(saved[key]);
				return saved[key];
			}else{
			//console.log('null');
			//console.log(saved[key]);
			return defaultValue;
		}
		}else{
			//console.log('key null');
			return defaultValue;
		}
		
	},
	removeItem: function(key, menu){
		bngApi.engineLua('gdcallback.removeItem(' + bngApi.serializeToLua(key) + ',' + bngApi.serializeToLua(menu) + ')');
	},
	clearAll: function(){
		bngApi.engineLua('gdcallback.clearAll()');
	},
    set: function(key, value) {
      $window.localStorage[key] = value;
    },
    get: function(key, defaultValue) {
      return $window.localStorage[key] || defaultValue || false;
    },
    setObject: function(key, value) {
      $window.localStorage[key] = JSON.stringify(value);
    },
    getObject: function(key, defaultValue) {
      if($window.localStorage[key] != undefined){
          return JSON.parse($window.localStorage[key]);
      }else{
        return defaultValue;
      }
    },
    remove: function(key){
      $window.localStorage.removeItem(key);
    },
    clear: function(){
      $window.localStorage.clear();
    }
  }
}]);

app.factory('httpFactory', [
  '$http',
  '$q',
  function httpFactory($http, $q) {
    console.log('httpService Called');

    // interface
    var derbyService = {
      settings: {},
      getSettings: getSettings,
    };
    return derbyService;

    // implementation
    function getSettings(urls) {
      var def = $q.defer();
      var urlCalls = {};
      var key = 0;
      angular.forEach(urls, function(url) {
        urlCalls[key] = $http.get('derby/' + url + '.json');
        key++;
      });
      $q.all(urlCalls).then(function successCallback(settings) {
        derbyService.settings = settings;
        def.resolve(settings);
        //console.log('derbyService Worked', settings);
      }),
        function errorCallback() {
          def.reject('Failed to get settings');
          //console.log('derbyService notworking');
        };
      return def.promise;
    }
  },
]);
app.controller('derbyController', [
  '$q',
  '$http',
  'httpFactory',
  '$log',
  '$scope',
  'bngApi',
  '$localstorage',
  function derbyController($q, $http, httpFactory, $log, $scope, bngApi,$localstorage) {
    //console.log('derbyController Called');
	
    var vm = this;
	vm.urls = ['menus','tracks'];
    vm.menus = {};
    vm.tracks = {};
    vm.selected = {};
	vm.heading = {};
	var	saved = {};
	var getDesc = function () {
		bngApi.engineLua('gdcallback.getDesc()',function (desc) {
			$scope.$evalAsync(function () {
				vm.heading.name = "";
				vm.heading.desc = "";
				if (desc) {
					console.log(desc.name);
					vm.heading = desc;
				}else{
					vm.heading.name = "Demolition Derby - The Fair Grounds v10.0.6";
					vm.heading.desc = "Race'em or Wreck'em";
				}
			});
		});
	};
	var loadSaved = function () {
		bngApi.engineLua('gdcallback.loadObject()',function (save) {
			$scope.$evalAsync(function () {
				saved = save
			});
		});
	};
	
	vm.update = function (refresh) {
		if (refresh === 1){
			var parts = $localstorage.loadObject("parts","",saved)
			if (parts) {
				vm.selected.parts = parts
			}
		};
		
		if (refresh === 1){
			$localstorage.saveTable(vm.selected)//We need to update the classes lua file before the getData call.
			bngApi.engineLua('gdcallback.getData()',function (response) {
				$scope.$evalAsync(function () {	
					var config2 = response.config2;
					var model = response.model;
					vm.menus.main.config2.listob = config2[0].listob;
					vm.selected.config2 = config2[0].default;
				
					vm.menus.main.vehicles.listg = model;
					vm.selected.vehicles = vm.menus.main.vehicles.default;
				});
			});
		};
		$localstorage.saveTable(vm.selected)
    };
	 var getSettings = function() {
      httpFactory.getSettings(vm.urls).then(
        function(settings) {
			//$localstorage.clear();
			vm.menus = settings[0].data;
			var tracks = settings[1].data;
			vm.tracks = tracks.arenas['common'];	
			bngApi.engineLua('gdcallback.getData()',function (mapData) {
				$scope.$evalAsync(function () {
					var map = mapData.map
					//console.log(map);
					
					if (tracks.arenas[map]) {
						vm.tracks = tracks.arenas[map];
					}else{
						if (mapData.tracks !== undefined) {
							var customTracks = mapData.tracks.arenas[map];
							if (customTracks){
								vm.tracks = customTracks;
							}
						}
					};
					var lastmap = $localstorage.loadObject('map',map,saved);
					console.log(map);
					console.log(lastmap);
					if (lastmap !== map) {
						saved.arena = undefined;
					};
					vm.selected['map'] = map;
					//var model = $localstorage.loadObject('model', model,saved);
					//$localstorage.removeItem('vehicles');
					//set the selection from saved selections or load the default selection
					vm.urls.forEach(function (menu) {
						angular.forEach(vm[menu].main,function(value, key) {
							if (value.name === 'Arena') {
								vm.selected['laps'] = $localstorage.loadObject('laps',value.laps.default,saved);
							}
							vm.selected[key] = $localstorage.loadObject(key,value.default,saved);
						});
					});
					angular.forEach(vm.menus.settings,function(value, key) {
						var settings = $localstorage.loadObject(key,value.default,saved);
						switch (settings) {
							case 'false':
								vm.selected[key] = false;
								break;
							case 'true':
								vm.selected[key] = true;
								break;
							default:
								vm.selected[key] = settings;
						}
					});
					//console.log('selected', vm.selected);
					vm.update(1);
				});	
			});	
        },
        function() {
          //console.log('settings call failed.');
        }
      );
    };			
	getDesc();
	loadSaved();
	getSettings();
	
	vm.clear = function(menu){
		$localstorage.removeItem(menu,'parts')
		vm.selected.parts[menu] = {}
	};
   vm.section = function(index) {
      var acc = document.getElementsByClassName('accordion')
      acc[index].classList.toggle("active");
      acc[index].nextElementSibling.classList.toggle("show");
    };
    vm.tab = 1;
    vm.setTab = function(newTab) {
      vm.tab = newTab;
	  if (vm.tab === 3) {
		  bngApi.engineLua('gdcallback.getParts()',function (response) {
			$scope.$evalAsync(function () {
				var errors = response.parts[0].msg;	
				vm.menus.parts = {};				
			if (errors) {
				
				vm.menus.parts.partsGroup = errors;
			}else{
				var partsGroup = response.parts[0].partsGroup;
				var partsMap = response.parts[0].partsMap;
				var slotType = response.parts[0].slotType;
				vm.menus.parts.partsGroup = partsGroup;
				vm.menus.parts.partsMap = partsMap;
				vm.menus.parts.slotType = slotType;
			};
			});
		});
	  }
	  
    };
    vm.isSet = function(tabNum) {
      return vm.tab === tabNum;
    };
  },
]);
app.directive('derbyMainTab', function() {
  return {
    restrict: 'E',
    replace: true,
    templateUrl: 'derby/main.html',
  };
});
app.directive('derbySettingsTab', function() {
  return {
    restrict: 'E',
    replace: true,
    templateUrl: 'derby/settings.html',
    scope: {
      settings: '=',
    },
  };
});
app.directive('derbyPartsTab', function() {
  return {
    restrict: 'E',
    replace: true,
    templateUrl: 'derby/parts.html',
  };
});
app.directive('derbyOptionsGroup', function() {
  return {
    restrict: 'E',
    replace: true,
    template:
      '<select id="menu.name" ng-model="c.selected[key]" ng-change="c.update(menu.refresh)" ng-options="v.name group by v.type for v in menu.listg|orderBy: \'+name\' track by v.name"> </select>',
  };
});
app.directive('derbyOptionsOrderBy', function() {
  return {
    restrict: 'E',
    replace: true,
    template:
      '<select id="menu.name" ng-model="c.selected[key]" ng-change="c.update(menu.refresh)" ng-options="list for list in menu.listob| orderBy:list" > </select>',
  };
});
app.directive('derbyOptions', function() {
  return {
    restrict: 'E',
    replace: true,
    template:
      '<select id="menu.name" ng-model="c.selected[key]" ng-change="c.update(menu.refresh)" ng-options="list for list in menu.listng" > </select>',
  };
});
app.directive('derbyTooltip', function() {
  return {
    restrict: 'E',
    replace: true,
    template:
      '<span class="tooltip"> <img src="help.png"> <div class="tooltiptext"> <div ng-repeat="tips in menu.tooltip">{{tips}} </div> </div> </span>',
  };
});