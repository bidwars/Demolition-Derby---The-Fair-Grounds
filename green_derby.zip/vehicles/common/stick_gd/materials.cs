
singleton Material("stick_gd")
{
   mapTo = "stick_gd";
   diffuseMap[0] = "stick_gd.png";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
};
singleton Material("stickbreak_gd")
{
   mapTo = "stickbreak_gd";
   diffuseMap[0] = "stickbreak_gd.png";
   specularPower[0] = "15";
   useAnisotropic[0] = "1";
   castShadows = "1";
   translucent = "0";
   alphaTest = "0";
   alphaRef = "0";
};