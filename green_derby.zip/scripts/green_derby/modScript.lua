local M = {}
	     registerCoreModule('gdmain')
return M