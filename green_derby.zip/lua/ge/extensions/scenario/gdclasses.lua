-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local helper = require('scenario/scenariohelper')
local vehicles = require('core/vehicles')
local modsFound = true
local includeMods = nil
local dataList = {} -- Filtered list of vehicles selected
local dataList2 = {} --config2 filtered list
local dataGroup = {}
local dataParts = {}
local savedClass = nil
local type = {
			["Heavy Semis"] = {semi = 4},
			["Truck Pickups/Vans/SUVs"] = {pickup = 4, roamer = 3, van = 4},
			["Large Cars"] = {barstow = 4, burnside = 3, fullsize = 4, moonhawk = 4},
			["Mid-Sized Cars"] = {hopper = 3, legran = 4, pessima = 4, midsize = 4, sunburst = 3,  etki = 4},
			["Compact Cars"] = {autobello = 3, coupe = 4, hatch = 4, pessima = 4, sunburst = 3, miramar = 4, hopper = 3},
			["Luxury/Sports Cars"] = {etkc = 4, etk800 = 4, super = 3, sbr = 2},	
			["Pigeon/Piccolina"] = {pigeon = 4, autobello = 3},
			["Random"] = {autobello = 3,hopper = 3, pigeon = 4, pickup = 4, roamer = 3, van = 4, barstow = 4, burnside = 3, fullsize = 4, moonhawk = 4, legran = 4, pessima = 4, midsize = 4, sunburst = 3, coupe = 4, hatch = 4, etki = 4, miramar = 4, etkc = 4, etk800 = 4, super = 3, sbr = 2}
			}

-------------------------------------------------------------------------------------
--CREATES A LIST OF ALL THE VEHICLES IN BEAMNG
-------------------------------------------------------------------------------------
local function customClass()	
	--get a table of all vehicles including mods 
	local configList = core_vehicles.getConfigList().configs
	 local modelsList = core_vehicles.getModelList().models
	--dump(configList)
	local classes = gdloader.options.classes or 'Large Cars'
	local config2 = gdloader.options.config2 or 'Auto Select'
	
	--Filters the list of vehicles
	local function filterClass(cmodel_key,ckey,cconfig_type)
		local numConfig = 0
		--Checks if Classes (Large Car, Pigeon/Piccolina) are in the type table then checks if model is found and gets the number of pre setup vehicles.
		if type[classes][cmodel_key] then  
			numConfig = type[classes][cmodel_key]
		end	
		if numConfig > 0 or classes == 'Random' then-- Bypass if Random selected
			if cconfig_type or string.startswith( ckey, "gd_") then 
				for ct,_ in pairs(cconfig_type) do  --Config type table (stock, basic, exc)
					if not dataList[1] then
						if modsFound == true then
							table.insert(dataList, {name="Auto Select",type="Model",config2 = "All Config Groups"})
						else
							table.insert(dataList, {name="Auto Select",type="No Vehicles Found --Defaults Listed--",config2="All Config Groups"})
							modsFound = true
						end
					end
					if string.startswith( ckey, "gd_") then
						for i=1, numConfig do
							local key = string.sub(ckey, 4)
							table.insert(dataList, {name = key..'('..i..')'..' '..cmodel_key,type = cmodel_key, config2 = ct})
						end
					else
						table.insert(dataList, {name = ckey..' '..cmodel_key,type = cmodel_key, config2 = ct})
					end		
				end
			else
				if not dataList[1] then
					if modsFound == true then
						table.insert(dataList, {name="Auto Select",type="Model",config2 = "All Config Groups"})
					else
						table.insert(dataList, {name="Auto Select",type="No Vehicles Found --Defaults Listed--",config2="All Config Groups"})
						modsFound = true
					end
				end
				table.insert(dataList, {name = ckey..' '..cmodel_key,type = cmodel_key, config2 = 'unknown'})
			end
		end
	end
	
	for _,c in pairs(configList) do
		if modelsList == nil or modelsList[c.model_key] == nil then
                log("E", logTag, "Model Info  not found for model ='"..c.model_key .."'") 
        else
			local modelInfo = modelsList[c.model_key]
			if includeMods == 'All Mods and BeamNG - Official' then --All Mods and Beamng Offical
				if modelInfo.Type == 'Truck' or  modelInfo.Type == 'Car' or modelInfo.Type == 'Bus' or modelInfo.Type == 'Automation' then
					filterClass(c.model_key,c.key,c.aggregates['Config Type'])	
				end
			else
				if c.Source == 'Mod' then
					local s = c.key
					if includeMods == 'No Mods' then --Default No Mods
						if string.startswith( s, "gd_") then
							filterClass(c.model_key, c.key,c.aggregates['Config Type'])
								
						end
					elseif includeMods == 'RDP NoDakSmack' then -- Real Derby Project 
						if string.startswith( s, "RDP" ) then
							filterClass(c.model_key,c.key,c.aggregates['Config Type'])
						end
					elseif includeMods == 'F150 Mods' then  --F150 Mod
						if string.startswith( s, "derby" ) or string.startswith(s,"banger") or string.startswith(s,"duke") or string.startswith(s,"239a") then
							filterClass(c.model_key,c.key,c.aggregates['Config Type'])
						end
					elseif includeMods == 'Peter Derby Mods' then --Peter Beamo Mod
						if string.startswith( s, "beamo" ) then
							filterClass(c.model_key,c.key,c.aggregates['Config Type'])
						end
					elseif includeMods == 'All Mods' and modelInfo.Type == 'Truck' or  modelInfo.Type == 'Car' or modelInfo.Type == 'Bus' or modelInfo.Type == 'Automation'then  --All Mods 
						if not string.startswith(s, "gd_") then --Don't include No Mods vehicles
							filterClass(c.model_key,c.key,c.aggregates['Config Type'])
						end
					end
				end	
			end
		end
	end
end
local function reset()
	dataList = {}
	dataList2 = {}
	dataGroup = {}
end
-------------------------------------------------------------------------------------
--GET ONE MODEL_KEY AND KEY 
-------------------------------------------------------------------------------------
local function modelName()	
	if modsFound == true then
		includeMods = gdloader.options.mods or 'No Mods'
		print(gdloader.options.mods)
	end

	local model_key = nil
	local key = nil

	reset()
	
	customClass()
	if not dataList[2] and includeMods ~= 'No Mods' then
		modsFound = false
		includeMods = 'No Mods' 
		modelName()
	end
	local config2List = {} 
	local listob = {}
	local groups = {}
	
	for _,item in pairs(dataList) do
		config2List[item.config2] = item.config2
		if not groups[item.type] then
			groups[item.type] = {type = item.type}
		end
	end
	dataGroup = groups
	local default = nil
	for ct,_ in pairs(config2List) do  --Groups the list of config2 
		if includeMods == 'No Mods' then
			if string.startswith( ct, "GD Basic" ) then
				default = ct
			end
		else
			if string.startswith( ct, "All Config") then
				default = ct
			end
		end
		table.insert(listob,ct)
	end
	if not default then --default is set to All Configs
		default = listob[1]
	end
	table.insert(dataList2, {listob = listob,default = default})
	--dump(dataList)
	--dump(listob)
	--dump(dataList2)
	return dataList, dataList2, dataGroup
end
local function addDirs(f)
  local outfiles = {}
  local prevDir = ''
  for i = 1, #f do
    local dir = string.match(f[i], '^(.*/)[^/]*$')
    if dir ~= prevDir then
      prevDir = dir
      table.insert(outfiles, 'DIR:'..dir)
    end
    table.insert(outfiles, f[i])
  end
  return outfiles
end
local oldclasses = nil
local function getParts()
	local classes = gdloader.options.classes or 'Large Cars'
	local vehTypes = type[classes]
	if not dataParts[1] or oldclass ~= classes then
		oldclasses = classes
		local jfiles = FS:findFilesByRootPattern("vehicles/", "*.j*\t*.pc", -1, true, false)
		--local files = {}
		local filesJBEAM = {}
		--local filesPC = {}
		for _, f in ipairs(jfiles) do
			--if string.sub(f, -5) == '.json' then
			--table.insert(files, f)
			if string.sub(f, -6) == '.jbeam' then
				table.insert(filesJBEAM, f)
			--elseif string.sub(f, -3) == '.pc' then
			--table.insert(filesPC, f)
			end
		end
		--files = addDirs(files)
		filesJBEAM = addDirs(filesJBEAM)
		--filesPC = addDirs(filesPC)
		local paths = {}
		for _, path in ipairs(filesJBEAM) do
			if string.find(path, "RDP") then
				table.insert(paths,path)
			end
		end
		--dump(paths)
	
		local parts = {}
		if not paths[1] then 
			local errors = {}
			local msg = {}
			msg = {msg = "Real Derby Project mod was not found or installed"}
			table.insert(errors, {msg = msg})
			return errors
		end
		for _, fn in ipairs(paths) do
			if FS:fileExists(fn) then
				local readData = jsonReadFile(fn)
				if readData == nil then
				log('E', 'vehicles', 'unable to read info file, ignoring: '.. fn)
				readData = {}
				else
					for v,k in pairs(readData) do
						--if k.information.authors == 'BeamNG & NoDakSmack' then
							local s = k.slotType
							local model = string.match(s,'^(.-)%p')
							if model then
								if vehTypes[model] then
									table.insert(parts, {name =  k.information.name, part= v, model = model, slot =k.slotType, cost = k.information.value})
								end
							end
					--end
					end
				end
			else
				log('W', 'vehicles', 'unable to find info file: '.. fn)
			end
		end

		local temp = {}
		local partsGroup = {}
		local slotType = {}
		local slots = {}
		if not parts[1] then 
			local errors = {}
			local msg = {}
			msg = {msg = "No custom parts found for the selected vehicle class"}
			table.insert(errors, {msg = msg})
			return errors
		end
		for _,item in pairs(parts) do  --Group Models
			temp[item.model] = item.model	
		end
		for model,_ in pairs(temp) do
			table.insert(partsGroup, model)
		end
	
		 
		for _,v in pairs(parts) do --Group Slots
				slots[v.slot] = v.model
		end
		for slot,model in pairs(slots) do
			table.insert(slotType,{slot=slot,model=model})
		end
	
		local index = {}
		local partsMap = {}
		for _,model in ipairs(temp) do
			for slot, slotModel in pairs(slotType) do
				if slotModel == model then
					if not partsMap[model] then
						partsMap[model] = {}
					end
					if not index[model] then
						index[model] = 1 
					end
					local i = index[model]
					partsMap[model][i] = {
							 name = slot
							}
					index[model] = index[model] + 1
				end
			end
		end
	
	
	--dump(partsMap)
	--dump(partsGroup)
	
		table.insert(dataParts , {partsGroup = partsGroup, slotType = slotType, partsMap = parts})
	end
	return dataParts
end
-------------------------------------------------------------------------------------
--CREATES A NEW PC FILE WITH PARTS WE NEED TO REMOVE SET TO NONE
-------------------------------------------------------------------------------------
local function deleteParts(data,model_key, partName)
	local partsfile = data
	--dump(partsfile)
	--print(model_key)
	--print('key')
	for _,part in ipairs(partName) do
		local hubcap = string.sub(part, 1, 6)
		if hubcap == "hubcap" then
			partsfile.parts[part] = "none"
		elseif partsfile.parts[model_key..''..part] then
			partsfile.parts[model_key..''..part] = "none"
		end
	end
	return partsfile
end
local function addParts(data, part)
	local partsfile = data
		--dump(part)
	
	--dump(partsfile)
	for k,v in pairs(part) do
		--if v.name =  then
			--print(v.name)
			if partsfile.parts then
				--i, j = string.find(v.part, v.model)
				--local pname = string.sub(v.part, j)
				partsfile.parts[k] = v
				--dump(partsfile)
			end
		--end
	end
	return partsfile
end
local function readPartsFile(File)
	local parts = readJsonFile(File)
	if parts then
		return parts
	end
end
-------------------------------------------------------------------------------------
--CREATES THE VEHICLE CLASS PC FILE
-------------------------------------------------------------------------------------
local function loadClass()
	local config = gdloader.options.config
	local vehiclePick = gdloader.options.vehicles.name or 'Auto Select'
	local config2 = gdloader.options.config2
	local parts = gdloader.options.parts
	local key = nil
	local model_key = nil
	if not dataList[2] then helper.realTimeUiDisplay("Error Loading Vehicles") return end
	if vehiclePick == 'Auto Select' then  --Auto selected
		local filterList = {}
		if config2 ~= 'All Config Groups' then
			for _,v in pairs(dataList) do
				if v.config2 == config2 then
					table.insert(filterList, v)
				end
			end
			if not filterList[1] then
				filterList = dataList
			end
		else
			filterList = dataList
		end
		
		local numRandom = tableChooseRandomKey(filterList)
		if numRandom == 1 then numRandom = 2 end
		model_key = filterList[numRandom].type
		local name = filterList[numRandom].name:gsub(model_key, "")
		key =  name
		--print("Random".. key .. model_key)
	else
		local num = #dataList
		for i=1, num do
			if dataList[i].name == vehiclePick then
				model_key = dataList[i].type
				local name = dataList[i].name:gsub(model_key, "")
				key = name		
			end
		end
		gdloader.options.vehicles = {name='Auto Select', type='Model'}
		--print("Picked".. key .. model_key)
	end
	local saveConfig = nil
	local partConfig = nil
		
	--if includeMods ~= 'No Mods' then -- Mods
			partConfig = string.format('vehicles/'..model_key..'/'..key..'.pc', model_key, key)  
			saveConfig = string.format('vehicles/'..config..'_vehicles/'..model_key..'/v1'..key..'.pc', model_key, key)
	--else
		--local number = tonumber(string.match(model_key, "%d+"))
		--local setup
		--if string.startswith( key, "RDP" ) then
			--setup = ""
		--else
			--if config == 'Stock Config' then
			--	setup = "stock_"
			--elseif config == 'Pro-Derby Config' then 
			--	setup = "pro_"
			--else 
			--	setup = "basic_"
			--end
		--end
	--	partConfig = string.format('vehicles/'..model_key..'/'..setup..''..key..'.pc', model_key, key)
	--	saveConfig = string.format('vehicles/'..config..'_vehicles/'..model_key..'/'..setup..'_v1'..key..'.pc', model_key, key)
	--end
	local partsUpdate = false
	local partsData = readPartsFile(partConfig)
	if not partsData then
		log('D', 'GDClasses', "Error finding Parts File "..key.." "..model_key)
	else
		if parts then
		
			for k,v in pairs(parts) do
				if k == model_key then
					--print(k)
					--if parts[model_key] then
						partsData = addParts(partsData,v)
						partsUpdate = true
					--end
				end
			end	
		end
		local fn = string.format('levels/derby/configs/removeParts.pc')
		local removePartsFile = scenario_gdclasses.readPartsFile(fn)
		if config == 'Normal Config' then
			if config2 == 'Pro-Derby Config' or config2 == 'Basic-Derby Config' then
				partsData = deleteParts(partsData,model_key,removePartsFile.pro)
				partsUpdate = true
			end
		else
			if config == 'Stripped Config' then 
				partsData = deleteParts(partsData,model_key,removePartsFile.stripped)
				partsUpdate = true
			end
			if config == 'Low-End Config' then 
				partsData = deleteParts(partsData,model_key,removePartsFile.lowend)
				partsUpdate = true
			end
		end
	end
	if partsUpdate == true then
		serializeJsonToFile(saveConfig, partsData, true)
		return model_key, saveConfig
	else
		return model_key, partConfig
	end
end

M.getParts = getParts
M.readPartsFile = readPartsFile
M.loadClass = loadClass
M.onScenarioRestarted = onScenarioRestarted
M.modelName = modelName
return M