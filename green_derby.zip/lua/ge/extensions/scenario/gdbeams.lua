-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local files
local filesJBEAM
local filesPC

local function addDirs(f)
  local outfiles = {}
  local prevDir = ''
  for i = 1, #f do
    local dir = string.match(f[i], '^(.*/)[^/]*$')
    if dir ~= prevDir then
      prevDir = dir
      table.insert(outfiles, 'DIR:'..dir)
    end
    table.insert(outfiles, f[i])
  end
  return outfiles
end
local function _getFiles()
  local jfiles = FS:findFilesByRootPattern("/vehicles/", "info*.json\t*.jbeam*\t*.pc", -1, true, false)
  files = {}
  filesJBEAM = {}
  filesPC = {}
 -- print("yayaya")
  for _, filename in ipairs(jfiles) do
    local f = string.lower(filename)
    if string.sub(f, -5) == '.json' then
      table.insert(files, filename)
    elseif string.sub(f, -6) == '.jbeam' then
      table.insert(filesJBEAM, filename)
    elseif string.sub(f, -3) == '.pc' then
      table.insert(filesPC, filename)
    end
  end
  files = addDirs(files)
  filesJBEAM = addDirs(filesJBEAM)
  filesPC = addDirs(filesPC)
  dump(filesJBEAM)
end
local function getModelFiles()

	local modelFiles = {}
	-- name of a file or directory can have alphanumerics, hyphens and underscores.
	local modelRegex  = "vehicles/([%w|_|%-|%s]+)/$"

	if files == nil or filesJBEAM == nil then
		_getFiles()
	end
	-- Get the models. They are the directories one level under vehicles folder
	for _, path in ipairs(files) do
		if string.sub(path, 1, 4) == "DIR:" then
			local model = string.match(path, modelRegex)
			if model then
				table.insert(modelFiles, path)
			end
		end
	end
  
	-- fix bad vehicle mods without info.json :(
	for _, path in ipairs(filesJBEAM) do
		if string.sub(path, 1, 4) == "DIR:" then
			local model = string.match(path, modelRegex)
			if model and model ~= "common" and not tableContainsCaseInsensitive(modelFiles, model) then
				table.insert(modelFiles, path)
				--log("E", "vehicles", "Vehicle '" .. model .. "' missing info.json")
			end
		end
	end
	--local filename = "vehicles/filenames.json"
	--jsonWriteFile(filename, modelFiles, true)

	--dump(modelFiles)
	
end
local function moveNodes(vehHeat,vid)
	if files == nil or filesJBEAM == nil then
		_getFiles()
	end
	
	local nodeFile = jsonReadFile("vehicles/heats"..vehHeat..".json")	

	print('moveNodes')
	if not nodeFile then print('nofile') return end
	local modelPaths = {}--------------------------------------------------------------figure this out
	for _,path in ipairs(filesJBEAM) do
		if string.match(path, "vehicles/"..nodeFile.model.."/([%w|_|%-|%s]+)") then  --Search for %w any alphanumerics and %- dashes % spaces 1 or more instances.
			table.insert(modelPaths, path)
		end
	end
	local partGroup = {}
	for _,node in pairs(nodeFile.nodes) do  -- partOrigin
		for _,path in pairs(modelPaths) do
			
			if node[2] and path then
				local part = string.match(path, "[%w|_|%-|%s]+/[%w|_|%-|%s]+/([%w|_|%-|%s]+)")
					if not string.find(path, "/vehicles/"..nodeFile.model.."/"..nodeFile.model..".jbeam") then
					
					if string.find(node[2], part) then  -- finds the file partOrigin
							print("found path"..path)
							--print("original "..node[2])
							
							local partOrigin = node[2]
							if not partGroup[partOrigin] then
								partGroup[partOrigin] = {}
							end
							local d = {
								path = path,
								name = node[3],
								pos = node[1]
								}
							table.insert(partGroup[partOrigin], d)
						--	else
								
						--	end
						--end
					end
				end
			end
		end
	end
	
	for group,partList in pairs(partGroup) do   --part group is a table with path, damaged part, damage pos, node name
		local partFile = jsonReadFile(partList[1].path)
		for _,data in pairs(partList) do  -- go through each part and open the part file
			
			--dump(partFile)
			for listidx,list in pairs(partFile) do  -- in the part file find the node that we need to edit the pos and then resave the part file
				for part,subPart in pairs(list) do
					--print(part)
					if part == 'nodes' then
						for i,node in pairs(subPart) do
							if node[1] == data.name then 
								--print(data.name)
								--dump(data.pos)
								--dump(node)
								local pos = vec3(data.pos)
								if node[5] then
									partFile[listidx][part][i].node={
											data.name,
											pos.x,
											pos.y,
											pos.z,
											node[5]
											}
								else
									partFile[listidx][part][i].node={
											data.name,
											pos.x,
											pos.y,
											pos.z
											}
								end
								--dump(partFile[listidx][part][i].node)
								
							end
						end
					end		
				end
			end
		end
		--save part file 
			jsonWriteFile(partList[1].path, partFile, true)
	end
end
M.getModelFiles = getModelFiles
M.moveNodes = moveNodes
return M