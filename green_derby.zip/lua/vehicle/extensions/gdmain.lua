local M = {}

	gdai = require('gdai')
	gdcallback = require('gdcallback')

local function updateGFX(dtSim)
	gdai.updateGFX(dtSim)
end
local function onDebugDraw(focusPos) 
	gdai.debugDraw(focusPos)
end	
local function onReset(retainDebug)
	gdai.reset(retainDebug)
end
local function VehicleFocusChanged()
	gdai.stateChanged()
end
local function onInit()
	gdai.init()
end


M.onDebugDraw = onDebugDraw
M.updateGFX = updateGFX
M.onInit = onInit
M.onReset = onReset
M.VehicleFocusChanged = VehicleFocusChanged
return M