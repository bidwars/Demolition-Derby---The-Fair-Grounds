-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
--local function wheelDataCallback(vName,wName,wValue,wID)
local wheelData = {}
local function wheelDataCallback(data)
	-- log('I','example', 'wheelDataCallback triggered....with ')
	 --dump(data)
	local vName = data.vName
	 local wID = data.wID
	 local lastSlip = data.lastSlip  
	wheelData[wID] = {lastSlip = lastSlip, vName = vName}
	
end
local function checkSlip(vName)
	--vObj:queueLuaCommand([[for wID,wtable in pairs(wheels.wheels) do for wName,wValue in pairs(wtable) do if wName == "name" or wName == "lastSlip" then vName = "]]..vName..[[" obj:queueGameEngineLua('derby_main.wheelDataCallback('..serialize(vName)..','..serialize(wName)..','..serialize(wValue)..','..tostring(wID)..')') end end end]])
	for i = 0, 3 do
		local vObj = scenetree.findObject(vName)
		local command = "obj:queueGameEngineLua(string.format('scenario_derby_wheels.wheelDataCallback(%s)', serialize({wID = "..i..", vName='"..vName.."', name=wheels.wheels["..i.."].name, lastSlip=wheels.wheels["..i.."].lastSlip})))"
		vObj:queueLuaCommand([[if wheels.wheels[]]..i..[[] then ]]..command..[[ end]])
	end
end	
				--	print(wd.name)
				--	print(wd.lastSlip)
				--	print(wd.lastSlipError)
				--	print(wd.slipEnergy)
				--	print(wd.slipRatioTarget)
local function slipHigh()
				
	dump(wheelData)
	local slipHigh = 0 
	local slipWheel = nil
	local num = #wheelData
		for i = 0, num do
			if wheelData[i] ~= nil then
				if wheelData[i].vName == vName then
						if slipHigh < wheelData[i].lastSlip then
							slipHigh = wheelData[i].lastSlip
							
							--slipWheel = wheelData[i].name
							--guihooks.trigger('DerbyPlaceChange', { one = wheelData[i].vName, two = wheelData[i].lastSlip, three = wheelData[i].name} )
						end
							--print(wheelData[i].name) 
							--print(wheelData[i].lastSlip)
								--guihooks.trigger('DerbyPlaceChange', { one = wheelData[i].vName, two = wheelData[i].lastSlip, three = wheelData[i].name} )
							
				end
			end
		end	
		--wheelData = {}
	return slipHigh
end	
M.wheelDataCallback = wheelDataCallback
M.checkSlip = checkSlip
M.slipHigh = slipHigh
return M
