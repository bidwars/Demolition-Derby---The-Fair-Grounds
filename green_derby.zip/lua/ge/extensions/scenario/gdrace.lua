-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}


M.racePlace = {}
local driver = {}
local logTag = 'gdrace'

local raceMarker = require("scenario/race_marker")
local helper = require('scenario/scenariohelper')
M.pathData = {}
local lapsEntered = 10

local function updatePlace(playerID)
	local place = M.racePlace
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do
		 local vehicle = scenetree.findObject(vName)
		if vehicle then
			local vid = vehicle:getID()
			--print(vid)
			local vd = M.pathData[vid]
			--dump(vd)
			if vd then
				local count = 1
				--print(vName)
				--print("lcount "..vd.lap.." ccount"..vd.cpPoint.." Dist"..vd.wpdist.." end")
				local vehicleData = M.pathData
				for v,d in pairs(vehicleData) do
					if v ~= vid then
						if vd.lap < d.lap then
							count = count + 1
						end
						if vd.lap == d.lap then
							if vd.cpPoint < d.cpPoint then
								count = count + 1
							end
							if vd.cpPoint == d.cpPoint then
								if vd.wpdist > d.wpdist then
									count = count + 1
								end
							end		
						end
					end
				end	
				--print(count)
				place[count] = {}
				if not driver[vid] then
					driver[vid] = gdloader.getDriver(vid)
				end
				if vid ~= playerID then
					place[count] = {driver = driver[vid], lap = vd.lap}
				else
					place[count] = {driver = 'Your Place', lap = vd.lap}
				end
			end
		end
	end
	local update = false
	if not place[3] then
		place[3] = {driver = "---", lap = "0"}
	end
	if not place[2] then
		place[2] = {driver = "---", lap = "0"}
	end
	if not place[1] then
		place[1] = {driver = "---", lap = "0"}
	end
	
	M.racePlace = place
	--dump(place[1])
	--dump(place[2])
	--dump(place[3])

	guihooks.trigger('DerbyPlaceChange', { one = place[1].driver.. " "..place[1].lap, two = place[2].driver.. " "..place[2].lap, three = place[3].driver} )
end
local function checkPoints(vid)
	local scenario = scenario_scenarios.getScenario()
	if not M.pathData[vid] then
		M.pathData[vid] = {cpPoint = nil, lapCount = nil, wpdist = 0, target = nil}
	end
	local pathData = M.pathData[vid]
	local data = scenario_waypoints.getVehicleWaypointData(vid)
	M.pathdata[vid].wpdist = distance
	if pathData.cpPoint ~= data.next then
		pathData.cpPoint = data.next
		pathData.lap = data.lap
		pathData.target = scenario.lapConfig[data.next]
		M.pathData[vid] = pathData
	end
end
local function deleteRoads()
	local objName = nil
	local obj = nil
	local unload = false
	local objNames = {'derby','dirttrackwp','fig8concretewp'}
	for _,objName in ipairs(objNames) do
		obj = scenetree[objName]
		if obj then
			unload = true
		end
		if unload == true then 
			obj:unload()
			obj:delete()

			be:reloadCollision()
			log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
			unload = false
		end
	end
end
local function updateScenarioData(scenario)
	local newScenario = scenario
	local copyScenario = scenario_scenarios
	copyScenario['setScenario'] =  function(sc) 
		scenario = sc
		end  
	scenario_scenarios = copyScenario
	scenario_scenarios.setScenario(newScenario)
end
local function updateScenarioVehicles(scenario)
	local vehicles = scenetree.findClassObjects('BeamNGVehicle')
	if vehicles then
		for k, vecName in ipairs(vehicles) do
			local to = scenetree.findObject(vecName)
			if to then
				local ScenarioObjectsGroup = scenetree.findObject('ScenarioObjectsGroup')
				if ScenarioObjectsGroup then
					ScenarioObjectsGroup:addObject(to.obj)
				end
			end
		end
	end
end
local function createRoads()
	deleteRoads()
	local Arena = gdloader.Arena

	local scenario = scenario_scenarios.getScenario()
	-- try to load some defaults
	local objName 
	local directory = 'prefabs/'
	scenario.prefabs = {}
	local trackName = nil 
	local tmp = scenario.mission..""..directory.."" .. scenario.levelName ..".prefab"
	if FS:fileExists(tmp) then
		table.insert(scenario.prefabs, tmp)
	end
	scenario.lapConfig = {}
	if Arena < 7 then
		objName = scenario.levelName
		lapsEntered = 1
		scenario.lapCount = 1	
		--scenario_gdvehicles.createVehicles()
	else
		scenario.lapCount = lapsEntered or 10
		guihooks.trigger('DerbyPlaceChange', nil)
		if Arena == 7 then
			objName = 'dirttrackwp'
			trackName = "dirttrack"
		elseif Arena == 8 then
			objName = 'fig8concretewp'
			trackName = "fig8concrete"
		--aiRadFac = 5
		end
		directory = 'prefabs/waypoints/'
		tmp = scenario.mission..""..directory.."" .. objName ..".prefab"
		if FS:fileExists(tmp) then
			table.insert(scenario.prefabs, tmp)
		end
	end
	updateScenarioData(scenario)
	scenario = scenario_scenarios.getScenario()
	scenario_scenarios.onClientStartMission(scenario.mission)  --create the prefabs
	scenario_gdvehicles.createVehicles()
	local vehicles = scenetree.findClassObjects('BeamNGVehicle')
	if vehicles then
		for k, vecName in ipairs(vehicles) do
			scenario.vehicles[vecName] = {playerUsable = true, startFocus = true}
		end
	end
	local waypointsTable = scenetree.findClassObjects('BeamNGWaypoint')
	--dump(waypointsTable)
	scenario.lapConfig = {}
	for k, nodeName in ipairs(waypointsTable) do
		if trackName and string.startswith( nodeName, trackName ) then
			table.insert(scenario.lapConfig, nodeName)
			log('D', 'scenario', tostring(k) .. ' = ' .. tostring(nodeName))
		end
	end
	local state = scenario.state
	scenario.state = 'pre-start'
	updateScenarioData(scenario)
	updateScenarioVehicles()
	map.assureLoad()
	scenario_scenarios.onPreRender()
	raceMarker.init()
	scenario_waypoints.initialise()
	extensions.hook("onRaceInit")
	scenario.state = state
	updateScenarioData(scenario)
	guihooks.trigger('ChangeState', {state ='menu'})
	scenario = scenario_scenarios.getScenario()
	dump(scenario)
end
local function lapSelection(enteredLaps)
	print("laps "..enteredLaps)
	lapsEntered = tonumber(enteredLaps)
end
local function update(playerID)
	local scenario = scenario_scenarios.getScenario()
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do
		 local vehicle = scenetree.findObject(vName)
		local vid = vehicle:getID()
	--for _,vid in ipairs(vehIn) do
		--if vid == playerID then
		--raceMarker.hide(true)
--else
		if not M.pathData[vid] then
			M.pathData[vid] = {cpPoint = nil, lap = 0, wpdist = 0, target = nil}
		end
		local data = scenario_waypoints.getVehicleWaypointData(vid)
		if not data then return end
		local veh = be:getObjectByID(vid)
		if veh then
			local pos = veh:getPosition()
			if not data.nextWp then return end
			local wpPos = data.nextWp.pos
			if wpPos then
				M.pathData[vid].wpdist = wpPos:distance(pos)
					--print(M.pathData[vid].wpdist)
			end
		else
			M.pathData[vid].wpdist = math.huge
		end
		if M.pathData[vid].cpPoint ~= data.next then
			M.pathData[vid].cpPoint = data.next
			M.pathData[vid].lap = data.lap + 1
			local targetNodeName = scenario.lapConfig[data.next]
			if veh then
					print(targetNodeName)
				if vid ~= playerID then
					helper.queueLuaCommand(veh, 'gdai.setTarget("' .. targetNodeName .. '")')
				end
			end
		end
	end
	updatePlace(playerID)
end
local function onScenarioRestarted()
	M.racePlace = {}
	driver = {}
	M.pathData = {}
	lapsEntered = 10
end
M.lapSelection = lapSelection
M.onScenarioRestarted = onScenarioRestarted
M.updatePlace = updatePlace
M.createRoads = createRoads
M.update = update

return M