-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local startvehicleConfig = 0
local startvehicleClass = 0 
local startArena = 0 
local user = "Hawk"
local removePartsFile = {} --Table of parts to remove
local helper = require('scenario/scenariohelper')
local startData = {}
M.vehicleData = {}
M.pathData = {}
M.sVehicles = {}
M.sVehiclesID = {}
M.driver = {}

-------------------------------------------------------------------------------------
--TORQUE SCRIPT TO SET THE PARTS Config
-------------------------------------------------------------------------------------
local function getPosRot(i)
	local Arena = scenario_derby_main.Arena
	local position = nil
	local rotation = nil
	local data = {}
		if Arena == 1 then
			data = startData.freefall
		elseif Arena == 2 then 
			data = startData.concrete 
		elseif Arena == 3 then
			 data = startData.grass
		elseif Arena == 4 then
			data = startData.ovalrace
		elseif Arena == 5 then
			data = startData.fig8concrete
		elseif Arena == 6 then
			data = startData.mudpit
		end	

		for j,t in pairs(data) do
			j = tonumber(j)
			if j == i then
				position = t.pos
				rotation = t.rot
			end
		end
		return position, rotation
end
local function TScript(driver,JBeam,pcs, i)
	
	local position, rotation = getPosRot(i)
	if driver ~= user then 
		local vehicleTS = [[
			new BeamNGVehicle(]]..driver..[[) {
			JBeam = "]]..JBeam..[[";
			partConfig = "]]..pcs..[[";
			renderDistance = "500";
			renderFade = "0.1";
			isAIControlled = "0";
			dataBlock = "default_vehicle";
			position = "]]..position..[[";
			rotation = "1 0 0 0";
			scale = "1 1 1";
			canSave = "1";
			canSaveDynamicFields = "1";
			};
			]]
			TorqueScript.eval(vehicleTS)
			TorqueScript.eval([[
				]]..driver..[[.rotation = "]]..rotation..[[";]])
	else 
		TorqueScript.eval([[
		]]..driver..[[.JBeam = "]] .. JBeam .. [[";
		]]..driver..[[.partConfig = "]] .. pcs .. [[";
		]]..driver..[[.position = "]]..position..[[";
		]]..driver..[[.rotation = "]]..rotation..[[";
		]]..driver..[[.requestReload();]])
		
	end
end
-------------------------------------------------------------------------------------
--SETS THE PARTS FOR EACH vehicle
-------------------------------------------------------------------------------------
local function partsConfig(firstLoad)
	local vehicleConfig = scenario_derby_main.vehicleConfig
	local vehicleClass = scenario_derby_main.vehicleClass
	local vehiclePick = scenario_derby_main.vehiclePick
	local Arena = scenario_derby_main.Arena
	if firstLoad == true then
		startvehicleConfig = vehicleConfig
		startvehicleClass = vehicleClass
		startArena = Arena
		local k = string.format('levels/derby/prefabs/startPos.json')
		startData = readJsonFile(k)
	end
	local includeMods = scenario_derby_main.includeMods
	local path = string.format('levels/derby/configs/removeParts.pc')
	removePartsFile = scenario_derby_classes.readPartsFile(path)
	local JBeam, pcs = scenario_derby_classes.loadClass(removePartsFile)
	--dump(pcs)	
	if startvehicleConfig == vehicleConfig and startvehicleClass == vehicleClass then	
		if firstLoad == true or includeMods > 1 or startArena ~= Arena or vehiclePick > 1 then		
			TScript(user,JBeam,pcs, 1)
		end
	else
		TScript(user,JBeam,pcs, 1)
	end	
end
-------------------------------------------------------------------------------------
--MOVE THE VEHICLES TO THEIR STARTING POSITION
-------------------------------------------------------------------------------------
local function moveVehiclesPosition(vName, vehicleOffset, k)
		
		--Get the Waypoint x, y, and z positions 
		local wpNum1 = scenario_derby_main.wp1
		local wpNum2 = scenario_derby_main.wp2
		local wp1 = scenetree.findObject('wp_' ..wpNum1):getPosition()
		local wp2 = scenetree.findObject('wp_' ..wpNum2):getPosition()
		local Arena = scenario_derby_main.Arena
		local pos = {}
		local offset = 30
		if Arena == 1 then
			offset = 50
		end
		if k > 8 then
			if Arena == 4 or Arena == 5 then  --Oval Track or Figure 8
				pos.x = wp1.x + wp2.x - 8 
				pos.y = wp1.y + wp2.y  
			else
				pos.x = wp1.x + wp2.x 
				pos.y = wp1.y + wp2.y - offset
			end
		else
			pos.x = wp1.x + wp2.x
			pos.y = wp1.y + wp2.y 
		end
		pos.z = wp1.z	
		--Offsets the vehicles so they don't get moved over one another
		if Arena == 4 or Arena == 5 then
			pos.y = (pos.y + vehicleOffset) / 2
			pos.x = pos.x /2
		else
			pos.x = (pos.x + vehicleOffset) / 2
			pos.y = pos.y / 2
		end
		if Arena == 1 then
			print("moved y position")
			pos.y = pos.y + 15
		end
		print("x "..pos.x.. " y "..pos.y.. " z " .. pos.z)
		--Command to move the vehicles
		TorqueScript.eval('if(isObject('..vName..')){'..vName..'.position =" '..pos.x..' '..pos.y..' '..pos.z..' ";}')	
end
-------------------------------------------------------------------------------------
--CREATES THE AI VEHICLES FOR THE SCENARIO  
-------------------------------------------------------------------------------------
local function createVehicles()			
	local vehicleCountEntered = scenario_derby_main.vehicleCountEntered		
	--local driver = {"ai1","ai2","ai3","ai4","ai5","ai6","ai7","ai8","ai9","ai10","ai11","ai12","ai13","ai14","ai15","ai16"}
	M.driver = {["ai1"]="The Big Buffoon",["ai2"]="Mayhem Mike",["ai3"]="Gentle Bud",["ai4"]="Sir NoMercy",["ai5"]="Rawhide Billie",["ai6"]="Cushion Charlie",["ai7"]="Mr. Gumby",["ai8"]="Ms. Gumby",["ai9"]="Montster",["ai10"]="Collissione Carbonara",["ai11"]="Motor Man Jackson",["ai12"]="Erwin the Eliminator",["ai13"]="Softcore James",["ai14"]="Morning Hollywood",["ai15"]="Crashtest Tommy",["ai16"]="Hurricane Houston"}
	partsConfig(false)
	
	for i=1,vehicleCountEntered do
		--JBeam is the vehicle type, and pcs is the parts Configuration
		
		local k = i + 1
		local JBeam, pcs = scenario_derby_classes.loadClass(removePartsFile)
		TScript("ai"..tostring(i),JBeam,pcs, k)
	end
end
-------------------------------------------------------------------------------------
--FUNCTION TO FREEZE AND UNFREEZE VEHICLES BEFORE THE START
-------------------------------------------------------------------------------------
local function freezeAll(state, vName)
	local vObj = scenetree.findObject(vName)
	if vObj then
		vObj:queueLuaCommand('controller.setFreeze('..tostring(state) ..')')
	end
end
local function weldParts(vName)
	local vObj = scenetree.findObject(vName)
	  helper.queueLuaCommand(vObj,
	  
                [[for _,b in pairs(v.data.beams) do
					if b.breakGroup ~= nil then
						local breakGroups = type(b.breakGroup) == "table" and b.breakGroup or {b.breakGroup}
						for _, g in pairs(breakGroups) do
							if type(g) == 'string' and (string.find(g, "hinge") ~= nil or string.find(g, "latch") ~= nil) then
								
								b.beamStrength = math.huge
								local deformLimit = type(b.deformLimit) == 'number' and b.deformLimit or math.huge
								--print(g.." "..b.id1.." "..b.id2.." "..b.beamStrength.." "..b.beamSpring.." "..b.beamDamp.." "..b.beamDeform.." "..deformLimit.." "..deformLimit.." "..b.beamPrecompression.." ")
								obj:setBeam(-1, b.id1, b.id2, b.beamStrength, b.beamSpring, b.beamDamp, b.beamDeform, deformLimit, type(b.deformLimitExpansion) == 'number' and b.deformLimitExpansion or deformLimit, b.beamPrecompression)
								--v.data.beams[b.cid].beamStrength = math.huge
							
							end
						end
					end
                end
				]])
end
local function setupVehicles(vName)
	freezeAll(0,vName)
	M.vehicleData[vName] = {
			targetSet = false, 
			targetTemp = nil,
			target = nil,  --Target vehicle name
			targetObj = nil,
			backup = false,
			forward = true,
			lasthit = false,
			throttle = 0,
			brake = 0,
			line = nil,
			hitTarget = false,
			startPos = nil,
			sDist = 0,  --Start Distance
			tDist = 0,  --Target Distance
			collision = false,
				--randomPointTimer = math.random(1,400),
				--randomPoint = vec3(0, 0, 0),
			dtCount = 0,
			lCount = 0,
			cCount = 0,
			hitID = 0,
			wheelspeed = nil,
				}	
	M.pathData[vName] = {
				line = nil,
				pathNode = nil,
				npathNode = nil,
				nodePos = nil,
				distance = nil,
				}
	
	scenario_derby_main.stopTicks[vName] = 1
	helper.trackVehicle(vName, vName)  --Track the Vehicle
	if vName ~= user then
		helper.setAiMode(vName, 'manual')  --Needed to setup the AI to Auto Shifting
		local vObj = scenetree.findObject(vName)
		if vObj then
			vObj:queueLuaCommand('controller.mainController.setGearboxMode("arcade")')
			local start = vObj:getPosition()	
			M.vehicleData[vName].startPos = vec3(start)
			--vObj:queueLuaCommand('obj:requestReset(RESET_PHYSICS)')  
			--vObj:resetBrokenFlexMesh()  --Repair Vehicles
		end
	end
end
local function nameClone()
	local vehName = {}
	local reset = 2
	local vList = scenetree.findClassObjects('BeamNGVehicle')
	for _,v in ipairs(vList) do
		vehName[v] = v
	end
	local sVehicles = M.sVehicles
	for _,vName in ipairs(sVehicles) do
		if vehName[vName] then
			--print(vName .. "Found")
		else
		--dump(vehName)
			for _,mName in pairs(vehName) do 
				local i,j = string.find(mName, "clone")
				if i ~= nil then
					local reName = {} 
					reName = scenetree.findObject(mName)
					if reName then 
						--print(mName)
						--dump(reName)
						reName.name = vName 
						--print(reName.name .. "notfound")
						vehName[mName] = vName
						reset = 1
					end
					break
				end
			end
		end
	end
	return reset
end
-------------------------------------------------------------------------------------
--LOAD vehicles
-------------------------------------------------------------------------------------
--{id:6, name:"Mud Pit"},
	--{id:5, name:"Concrete Figure 8"},
	--{id:4, name:"Oval Dirt Track"},
	--{id:3, name:"Grass"},
	--{id:2, name:"Concrete"},
	--{id:1, name:"Free Fall"}
local function loadVehicles()	
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
	log('D', 'scenario', "found " .. #sVehicles .. " vehicles")
	--local userVehicle = math.random(1, #sVehicles)
	local vehIn = 0 
	for k, vName in pairs(sVehicles) do	
		M.sVehicles[k] = vName
		local vObj = scenetree.findObject(vName)
		local id = vObj.obj:getID()
		M.sVehiclesID[id] = vName 
		vehIn = vehIn + 1 
		freezeAll(1, vName)		
	end
	return vehIn
end
-------------------------------------------------------------------------------------
--DELETE VEHICLES 
-------------------------------------------------------------------------------------
local function deleteVehicles(vName)
		--TorqueScript.eval('setCameraFree();')
		local vObj = scenetree.findObject(vName)
		if vObj then
			--dump(obj)
			vObj:delete()
			--Update static collision with new prefabs
			be:reloadCollision()
		end
end
-------------------------------------------------------------------------------------
--GETS THE AI MOVING 
-------------------------------------------------------------------------------------
local function driveCar(vName,steering,throttle,brake,parkingbrake)
	--print("drive Car"..vName)
	if not steering then return end
	local vObj = scenetree.findObject(vName)
	if vObj then
		vObj:queueLuaCommand('input.event("steering", '..steering..', 1)')
		vObj:queueLuaCommand('input.event("throttle", '..throttle..', 2)')
		vObj:queueLuaCommand('input.event("brake", '..brake..', 2)')
		vObj:queueLuaCommand('input.event("parkingbrake", '..parkingbrake..', 2)')
	end
end
local function adjustBT(dirDiff,throttle, brake, dirTarget)
	if dirTarget > 0 then
		throttle = throttle + .04	 
	end
end
local function adjustBrakeThrottle(value, vel, dirTarget)
	--print(wheelSlip)
	--print(value)
	local speed  = vel:length()
	--local maxSlip = 14
	--local Arena = scenario_derby_main.Arena
	--if Arena == 3 or Arena == 6 then
	--	maxSlip = 11
	--end
	if speed > 2 and value > 0 then
		if dirTarget < 0.5 and dirTarget > -0.5 then
			if dirTarget < 0.2 and dirTarget > -0.2  then
				value = value - 0.01
			else 
				value = value - 0.005
			end
			value = value - 0.001	
			--print("lower")
		end
	end
	
	if dirTarget > .65 or dirTarget < -.65 then
		if dirTarget > .75 or dirTarget < -.75 then
			if dirTarget > .87 or dirTarget <  -.87 then
				value = value + .01
			else 
				value = value + .005	
			end
		else 
			value = value + 0.001
		end
	else 
		if speed < 2 then
			value = value + 0.01
		end
	end


	if value > 1 then
		value = 1
	elseif value < 0.00 then
		value = 0.00
	end
	return value
end


M.partsConfig = partsConfig
M.createVehicles = createVehicles
M.loadVehicles = loadVehicles
M.freezeAll = freezeAll
M.weldParts = weldParts
M.deleteVehicles = deleteVehicles
M.driveCar = driveCar
M.nameClone = nameClone
M.setupVehicles = setupVehicles
M.adjustBrakeThrottle = adjustBrakeThrottle
M.adjustBT = adjustBT
return M