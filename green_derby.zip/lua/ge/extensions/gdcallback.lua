-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
M.vehIn = {}
local settings = {}
local function driveTrainCallback(data)
	gdloader.driveTrain = data
end
local function driveTrain()
	if be:getPlayerVehicle(0) then
		local vehicle = scenetree.findObjectById(be:getPlayerVehicle(0):getID())
		local command = "obj:queueGameEngineLua(string.format('gdcallback.driveTrainCallback(%s)',serialize({gear = drivetrain.gear})))"
		if vehicle then
			vehicle:queueLuaCommand(command)
		end
	end
end
local function request(vid)
	M.vehIn = gdloader.vehIn
	local vehicle = scenetree.findObjectById(vid)
	if vehicle then
		vehicle:queueLuaCommand('gdcallback.vehInCallBack(' .. serialize(M.vehIn) .. ')')
	end
end
local function getDesc()
	local map = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
	if map == gdloader.oldScenario.map then
		local data = gdloader.oldScenario
		return data
	else
		local scenario = scenario_scenarios.getScenario()
		local data = {name=scenario.name, desc = scenario.description, map = map}
		gdloader.oldScenario = data
		--dump(data)
		--print('newmap')
		return data
	end
end
local function getData()
	local data = {}
	local map = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
	local fn = 'levels/'..map..'/scenarios/tracks.json'
	if FS:fileExists(fn) then
		local file = readJsonFile(fn)
		if file then
			data['tracks'] =  file
		end
	end
	data['map'] = map
	data['model'], data['config2'], data['group'] = scenario_gdclasses.modelName()
	return data
end
local function getParts()
	local data = {}
	data['parts'] = scenario_gdclasses.getParts()
	return data
end
local function saveObject(key,value)
	local fn = string.format('settings/derbyMenu.json')
	local file = {}
	if FS:fileExists(fn) then
		file = readJsonFile(fn)
	end
	file[key] = value
	serializeJsonToFile(fn, file, true)
end
local function saveTable(file)
	local fn = string.format('settings/derbyMenu.json')
	if file then
		serializeJsonToFile(fn, file, true)
		gdloader.selection(file)
	end
end
local function loadObject()
	local fn = string.format('settings/derbyMenu.json')
	if FS:fileExists(fn) then
		local file = readJsonFile(fn)
		if file then
			settings = file
			return settings
		else
			return nil
		end
	end
end
local function removeItem(key, menu)
	local fn = string.format('settings/derbyMenu.json')
	if FS:fileExists(fn) then
		local file = readJsonFile(fn)
		if file then
			if menu then
				file[menu][key] = {}
			else
				file[key] = {}
			end
		end
		serializeJsonToFile(fn, file, true)
	end
end
local function clearAll()
	local fn = string.format('settings/derbyMenu.json')
	local file = {}
	serializeJsonToFile(fn, file, true)
end

M.getDesc = getDesc
M.getData = getData
M.saveTable = saveTable
M.clearAll = clearAll
M.saveObject = saveObject
M.loadObject = loadObject
M.removeItem = removeItem
M.getParts = getParts
M.driveTrain = driveTrain
M.driveTrainCallback = driveTrainCallback
M.request = request
return M
