-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

M.mode = 'disabled' -- this is the main mode
M.manualTargetName = nil
M.debugMode = 'off'
M.targetObjectID = -1
M.speedMode = nil
M.routeSpeed = nil
M.driveInLaneFlag = 'off'
M.extAggression = 1
M.cutOffDrivability = 0

-- [[ STORE FREQUENTLY USED FUNCTIONS IN UPVALUES ]] --
local max = math.max
local min = math.min
local sin = math.sin
local asin = math.asin
local pi = math.pi
local abs = math.abs
local sqrt = math.sqrt
local tableInsert = table.insert
local tableRemove = table.remove
local strFormat = string.format
---------------------------------

-- [[ ENVIRONMENT VARIABLES ]] --
local g = abs(obj:getGravity())
local gravityDir = vec3(0, 0, -1)
local gravityVec = gravityDir * g
----------------------------------

-- [[ PERFORMANCE RELATED ]] --
local maxExternalAggression = 2
local initialAggression = 1 / maxExternalAggression
local initialAggAccCoeff = 0.8
local maxAggAccCoeff = 1.3
local aggression = initialAggression

local accCoeffGrad = (maxAggAccCoeff - initialAggAccCoeff) / (1 - initialAggression)
local accCoeffYintercept = initialAggAccCoeff - accCoeffGrad * initialAggression

local aggressionMode

local baseTurnAccel = min(0.5, aggression) * g
local maxTottalAccel = g

local learned_turn_accel
-- local learned_brake_accel
local learned_total_accel = baseTurnAccel

local turnAccelSmoother = newTemporalSmoothing(0.05, 3, nil, baseTurnAccel)
-- local brakeAccelSmoother = newTemporalSmoothing(0.1, 2, nil, baseTurnAccel)
local totalAccelSmoother = newTemporalSmoothing(0.1, 2, nil, baseTurnAccel)
local targetSpeedSmoother = newTemporalSmoothingNonLinear(10, 7, 0)

-- [[ AI DATA: POSITION, CONTROL, STATE ]] --
local aiID = obj:getID()
local aiPos = vec3(obj:getFrontPosition())
local aiDirVec = vec3(obj:getDirectionVector())
local aiVel = vec3(obj:getVelocity())
local aiSpeed = aiVel:length()
local aiWidth -- this comes back zero at this point
local aiLength -- this comes back zero at this point
--Added aiGear 
local aiGear 

local forces = {}

local throttle = 0
local brake = 0
local threewayturn = 0
local lastCommand = {steering = 0, throttle = 0, brake = 0, parkingbrake = 0}

local targetAiMidPos = nil
local targetstatus = nil


-- [[ CRASH DETECTION ]] --
local crashTime = 0
local crashManeuver = 0
local crashDir = nil
--Added
local totalCrashDistance = 0
local crashPos 
local crashObjID = -1
--End
---------------------

-- [[ OPPONENT DATA ]] --
--Target was Player changed
local target = nil
local targetPos = nil

-- [[ SETTINGS, PARAMETERS, AUXILIARY DATA ]] --
local map = nil
local targetObjectSelectionMode = nil
local currentRoute = nil

-- [[ HEAVY DEBUG MODE ]] --
local speedRecordings = {}
local trajectoryRec = {last = 0}
local routeRec = {last = 0}
local labelRenderDistance = 10
local targetSpeed
local targetSegIdx
local midTargetSegIdx

local function aistatus(status, category)
  guihooks.trigger("AIStatusChange", {status=status, category=category})
end

local function getState()
  return M
end

local function stateChanged()
  if playerInfo.anyPlayerSeated then
    guihooks.trigger("AIStateChange", getState())
  end
end

local function setAggressionInternal(v)
  aggression = min(max((v and v * M.extAggression) or initialAggression * M.extAggression, 0.15), 1)
  baseTurnAccel = min(0.5, aggression) * g
end

local function setAggressionExternal(v)
  M.extAggression = v or M.extAggression
  setAggressionInternal()
end

local function setAggressionMode(aggrmode)
  if aggrmode == 'rubberBand' then
    aggressionMode = 'rubberBand'
  else
    aggressionMode = nil
  end
end

local function resetAggression()
  setAggressionInternal()
end
local function setTargetObjectID(id)
  M.targetObjectID = M.targetObjectID ~= aiID and id or -1
  if M.targetObjectID ~= -1 then targetObjectSelectionMode = 'manual' end
end
local function updatePlayerData()
  if mapmgr.objects[M.targetObjectID] and targetObjectSelectionMode == 'manual' then
    target = mapmgr.objects[M.targetObjectID]
  end
end
local function driveCar(steering, throttle, brake, parkingbrake)
  input.event("steering", -steering, 1)
  input.event("throttle", throttle, 2)
  input.event("brake", brake, 2)
  input.event("parkingbrake", parkingbrake, 2)

  lastCommand.steering = steering
  lastCommand.throttle = throttle
  lastCommand.brake = brake
  lastCommand.parkingbrake = parkingbrake
end
local function aimToTarget()
  if targetPos == nil then return end
		
	--local targetVec = (targetPos - aiPos):normalized()
	--local dirTarget = aiDirVec:dot(targetVec)
	--local dirDiff = -math.asin(aiDirVec:cross(vec3(obj:getDirectionVectorUp())):dot(targetVec))
	

	--Added
	if M.mode == 'derby' then
		--local debugDrawer = obj.debugDrawProxy
		local ahead
		if aiGear > 0 then
			ahead = aiDirVec * aiSpeed + aiPos
		else
			ahead = -aiDirVec * (aiSpeed + 3) + aiPos
		end
		local aheadTargetVec = (targetPos - ahead):normalized()
		local aheadTarget = aiDirVec:dot(aheadTargetVec)
		local dirDiff = -math.asin(aiDirVec:cross(vec3(obj:getDirectionVectorUp())):dot(aheadTargetVec))
		
		if crashManeuver == 3 and aiSpeed > 2 then
			if crashDir > 0 and aheadTarget > .96 then
				crashManeuver = 0
				crashTime = 0 
			elseif crashDir < 0 and aheadTarget <  -.97 then
				crashManeuver = 0
				crashTime = 0
			end
		end
		
		if crashManeuver > 1 then  --reset target
			local distFromCrash = aiPos:distance(crashPos)
			
			if distFromCrash > (5 + aggression) or crashTime > 15 then
				crashManeuver = 0
				--totalCrashDistance = 0
				throttle = 0
				brake = 0 
				crashPos = nil
				crashTime = 0
				M.routeSpeed = nil
				if crashManeuver ~= 3 then
					targetPos = nil
					obj:queueGameEngineLua("scenario_derby_vehicles.resetTarget("..tostring(aiID)..')')
					crashObjID = -1
				else	
					local wp1 = currentRoute['wp1']
					local wp2 = currentRoute['wp2']
					local xpos = (wp1.x + wp2.x) / 2
					local ypos = (wp1.y + wp2.y) / 2
					local point = vec3(xpos, ypos, wp1.z)
						
					if aiPos:distance(point) > 25 then
						M.targetObjectID = point
						targetPos = point
						crashManeuver = 0 
						crashObjID = -1
					end
				end
			else
				local tb = 1
				local crashTargetVec = (crashPos - ahead):normalized()
				local crashTarget = aiDirVec:dot(crashTargetVec)
				dirDiff = -math.asin(aiDirVec:cross(vec3(obj:getDirectionVectorUp())):dot(crashTargetVec))
				tb = tb * (abs(crashTarget))
				tb = max(tb - (distFromCrash /(6 + aggression) ),0.3)
					--print(crashDir)
					--print(crashTarget)
					--print(crashManeuver)
					--print(tb)
					--print(distFromCrash)
					--if crashDir > 0 then 
						--debugDrawer:drawSphere(1, (-aiDirVec * (aiSpeed + 5) + aiPos):toFloat3(), color(255,255,255,255)) 
					--else
						--debugDrawer:drawSphere(1, (aiDirVec * (aiSpeed + 5) + aiPos):toFloat3(), color(255,100,100,255))
					--end
					--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 1.5), color(0,0,0,255), tb.."tb")
					--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 2.3), color(0,0,0,255), crashTime.."crashTime")
					--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 2), color(0,0,0,255), distFromCrash.."distfromcrash")
					--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, .5), color(0,0,0,255), crashManeuver.."crashManeuver")
						
				if crashDir > 0 then
					brake = tb
					throttle = 0
				else
					throttle = tb
					brake = 0 
				end
			end
		else 
			if throttle > 0 and aiSpeed > 4 and aiSpeed < 30 then
				if (abs(dirDiff) / 1.55) > .50 then
					local temp = 1 - (abs(dirDiff) / 1.55)
					throttle = min(temp, throttle)
				end
			else
				if aiSpeed < 5 then
					if aiSpeed < 3 then
						throttle = 0.4
					else
						throttle = 1 - (abs(dirDiff) / 1.55)
						throttle = throttle * aggression
					end
				end
			end
			if aheadTarget > .90 or aheadTarget < -.90 then
				throttle = max(throttle + (throttle * aggression), .90)
			end	
		
			--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, .1), color(0,0,0,255), aheadTarget.."Target")
			if throttle > 1 then throttle = 1 end		
			if aheadTarget < .20   then
				brake = throttle
				throttle = 0 
			else 
				brake = 0 
			end 
			if aiPos:distance(targetPos) < 10 and aiSpeed < 2 then
				if lastCommand.throttle > 0 and brake > 0 and aheadTarget < .20 then
					throttle = brake
					brake = 0
				elseif lastCommand.brake > 0 and throttle > 0 and aheadTarget > .20 then
					brake = throttle
					throttle = 0
				end
			end
		end
		
		--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 1), color(0,0,0,255), brake.."brake")
		--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 1.2), color(0,0,0,255), throttle.. "throttle")
		--if throttle > 0 then 
			--debugDrawer:drawSphere(.2, (aiPos):toFloat3(), color(255,0,255,255))
		--else
			--debugDrawer:drawSphere(.2, (aiPos):toFloat3(), color(0,255,0,255))
		--end
		
		--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, .8), color(0,0,0,255), crashManeuver.. "crashManeuver")
		--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 1.5), color(0,0,0,255), aheadTarget.."target")
		
		--local targetDis = aiPos:distance(targetPos)
		--print(aheadTarget.. "AheadTarget")
		--print(dirTarget.. "DirTarget")
		--print(targetDis.. "targetDis")
		--print(crashManeuver.. "crash")
		--print(throttle.. "throtle")
		--print(brake.. "brake")
		
		driveCar(dirDiff, throttle, brake, 0)
	end
end
local function resetMapAndRoute()
  currentRoute = nil
  targetPos = nil
  --race = nil
  --noOfLaps = nil
  --internalState = 'onroad'
  resetAggression()
end
local function warningAIDisabled(message)
  gui.message(message, 5, "AI debug")
  M.mode = 'disabled'
  M.updateGFX = nop
  resetMapAndRoute()
  stateChanged()
end
--Added for Derby
local function findWalls()
	local mapNodes = map.nodes
	local wp1, wp2 = mapmgr.findClosestRoad(aiPos)
	local wp1pos = mapNodes[wp1].pos
	local wp2pos = mapNodes[wp2].pos
	currentRoute = {wp1 = wp1pos, wp2 = wp2pos}
	print(wp1)
	print(wp2)
end
-------------------------------------------------------------------------------------
--RECTANCE LINE INTERSECT  --https://love2d.org/wiki/General_math
-------------------------------------------------------------------------------------
local function findIntersect(l1p1x,l1p1y, l1p2x,l1p2y, l2p1x,l2p1y, l2p2x,l2p2y, seg1, seg2)
	local a1,b1,a2,b2 = l1p2y-l1p1y, l1p1x-l1p2x, l2p2y-l2p1y, l2p1x-l2p2x
	local c1,c2 = a1*l1p1x+b1*l1p1y, a2*l2p1x+b2*l2p1y
	local delta,x,y = a1*b2 - a2*b1
	if delta==0 then return false, "The lines are parallel." end
	x,y = (b2*c1-b1*c2)/delta, (a1*c2-a2*c1)/delta
	if seg1 or seg2 then
		local min,max = math.min, math.max
		if seg1 and not (min(l1p1x,l1p2x) <= x and x <= max(l1p1x,l1p2x) and min(l1p1y,l1p2y) <= y and y <= max(l1p1y,l1p2y)) or
		   seg2 and not (min(l2p1x,l2p2x) <= x and x <= max(l2p1x,l2p2x) and min(l2p1y,l2p2y) <= y and y <= max(l2p1y,l2p2y)) then
			return false, "The lines don't intersect."
		end
	end
	return x,y
end
local function checkWalls()
	local ahead
	local vel = aiSpeed
	if vel > 2 and vel < 4 then 
		vel = 4
	end
	if aiGear < 0 then
		if vel > 1 then vel = vel + 4 end
		ahead = -aiDirVec * vel + aiPos
	elseif aiGear > 0 then
		ahead = aiDirVec * vel + aiPos
	else
		ahead = aiPos
	end
	--local debugDrawer = obj.debugDrawProxy
	-- debugDrawer:drawSphere(0.5, ahead:toFloat3(), color(255,0,0,255))
	local up  = obj:getDirectionVectorUp()
	local rightvec = (aiDirVec):cross(up)
	local right = (rightvec * 2) + aiPos
	local left = (-rightvec * 2) + aiPos
	
	local directions = {} 
	directions[1] = ahead
	directions[2] = right
	directions[3] = left
	
	local dx = nil
	local dy = nil
	local wp1 = currentRoute['wp1']
	local wp2 = currentRoute['wp2']
	local lineIntersect = nil
	for i,direction in pairs(directions) do
		dx, dy = findIntersect(aiPos.x, aiPos.y, direction.x, direction.y, wp1.x, wp1.y, wp1.x, wp2.y,true,true)
		if dx == false then
			dx, dy = findIntersect(aiPos.x, aiPos.y, direction.x, direction.y, wp2.x, wp2.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = findIntersect(aiPos.x, aiPos.y, direction.x, direction.y, wp1.x, wp1.y, wp2.x, wp1.y,true,true)
		end
		if dx == false then
			dx, dy = findIntersect(aiPos.x, aiPos.y, direction.x, direction.y, wp2.x, wp2.y, wp1.x, wp2.y,true,true)
		end
	
	
		if dx ~= false then
		
			lineIntersect = vec3(dx, dy, aiPos.z)
			
			--if wp1 == 1 then need to do
			--	point = 1
			--else
				local xpos = (wp1.x + wp2.x) / 2
				local ypos = (wp1.y + wp2.y) / 2
				local point1 = vec3(xpos, ypos, wp1.z)
				local point = nil
				local distance1 = aiPos:distance(point1)
				local distance2 = aiPos:distance(wp1)
				local distance3 = aiPos:distance(wp2)
				if distance1 > distance2 and distance1 > distance3 then
				elseif distance2 > distance1 and distance2 > distance3 then	
					--xpos = (wp1.x + wp2.x) * .25
				else
					--xpos = (wp1.x + wp2.x) * .75
				end
				point = vec3(xpos, ypos, wp1.z)
				--debugDrawer:drawSphere(1, lineIntersect:toFloat3(), color(255,0,0,255))
			--end
			--M.targetObjectID = point
			if i == 1 then
				--targetPos = point
				crashManeuver = 3
				crashTime = 0
			end
		end
	end
end	
local function checkHitTarget()
	local aiCollisions = mapmgr.objects[aiID].objectCollisions
	if aiCollisions ~= nil then
		for k,_ in pairs (aiCollisions) do
			if k ~= aiID then
				if crashObjID ~= k then
					crashObjID = k 
					crashManeuver = 2  --hit something
						local wp1 = currentRoute['wp1']
						local wp2 = currentRoute['wp2']
						local xpos = (wp1.x + wp2.x) / 2
						local ypos = (wp1.y + wp2.y) / 2
						local point = vec3(xpos, ypos, wp1.z)
						
						if aiPos:distance(point) > 25 then
							M.targetObjectID = point
							targetPos = point
							crashManeuver = 0 
							crashObjID = -1
						end
				end
			end
		end
	end
end
--Ended

local function updateGFX(dt)
	if map == nil then
		if mapmgr.map == nil then print('nomap') return end
		map = mapmgr.map
	end
		
	local tmpPos = obj:getFrontPosition()
	aiPos:set(tmpPos)
	aiPos.z = max(aiPos.z - 1, obj:getSurfaceHeightBelow(tmpPos))
	aiDirVec:set(obj:getDirectionVector()) --current ai direction
	aiVel:set(obj:getVelocity()) --current ai velocity vector
	aiSpeed = aiVel:length() -- current ai velocity "speed"
	aiWidth = aiWidth or obj:getObjectInitialWidth(aiID)
	aiLength = aiLength or obj:getObjectInitialLength(aiID)	
	aiGear = drivetrain.gear
	local speed = 5
	------------------ DERBY MODE -----------------
	if M.mode == 'derby' then
		if not currentRoute then
			findWalls()
		end
		if crashManeuver ~= 4 then
			checkWalls()
		end
		if crashManeuver == 0 then	
			if mapmgr.objects[M.targetObjectID] and 'number' == type(M.targetObjectID)  then
				updatePlayerData()
				targetPos = target.pos
				checkHitTarget()
			else
				targetPos = M.targetObjectID
				local distanceToTarget = aiPos:distance(targetPos)
				if distanceToTarget < 15 then
					driveCar(0, 0, 0, 0)
					 M.routeSpeed = nil
					 crashManeuver = 0 
					obj:queueGameEngineLua("scenario_derby_vehicles.resetTarget("..tostring(aiID)..')')
					return
				end
			end
			
			--if M.routeSpeed == nil then M.routeSpeed = distanceToTarget end
			--speed = abs(M.routeSpeed - distanceToTarget)
			--if targetType == 1 then
							
				--if crashManeuver == 0 and aiSpeed < 2 and distanceToTarget < 6 then	
					--local wp1 = currentRoute['wp1']
					--local wp2 = currentRoute['wp2']
					--local xpos = (wp1.x + wp2.x) / 2
					--local ypos = (wp1.y + wp2.y) / 2
					--local point = vec3(xpos, ypos, wp1.z)
						
					--if aiPos:distance(point) > 20 then
					--	M.targetObjectID = point
					--	targetPos = point
					--end
				--end
			--else
				
			--end
		
			
		end
	 ------------------ STOP MODE ----------------
	elseif M.mode == 'stop' then
		if aiVel:dot(aiDirVec) > 0 then
		driveCar(0, 0, 1, 0)
		else
		driveCar(0, 1, 0, 0)
		end
		if aiSpeed < 0.08 then --  or curVelVec:dot(aiDirVec) < 0
		driveCar(0, 0, 0, 0) -- only parkingbrake
		M.mode = 'disabled'
		M.manualTargetName = nil
		M.updateGFX = nop
		resetMapAndRoute()
		stateChanged()
		end
		targetSpeed = 0
		--aimToTarget()
		return
	end
	--ADDED
	if crashManeuver > 0 then  --reset target
		if crashTime == 0 then
			if aiGear > 0 then
				crashDir = 1
				crashPos = vec3(aiPos)
			else 
				crashDir = -1
				crashPos = vec3(aiPos)
			end
		end
		if not controller.isFrozen and aiSpeed < 0.1 and(lastCommand.throttle ~= 0 or lastCommand.brake ~= 0) then
			local crashDist = aiPos:distance(crashPos)
			--local debugDrawer = obj.debugDrawProxy
			--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 0.3), color(0,0,0,255), crashDist.."crashDist")
			if crashTime > 5 and crashDist < 2 then
				crashManeuver = 4
				if crashDir == 1 then
					crashDir = -1
				else
					crashDir = 1
				end
				crashTime = 1
			end
		end
		crashTime = crashTime + dt
	end
	
	--END
	throttle = 1
	brake = 0
	--Added Changed
	if currentRoute ~= nil then
		targetSpeed = targetSpeedSmoother:get(speed, dt)
	end
	--Ended
	 local curTurnAccel = abs(sensors.gx2)
    learned_turn_accel = turnAccelSmoother:getUncapped(max(curTurnAccel, baseTurnAccel), dt)

    --local curBrakeAccel = abs(sensors.gy2)
    --learned_brake_accel = brakeAccelSmoother:getUncapped(max(curBrakeAccel, baseTurnAccel), dt)

    local curTotalAccel = sqrt(curTurnAccel*curTurnAccel + square(sensors.gy2))

    local accelCoeff = accCoeffGrad * aggression + accCoeffYintercept --> y = ax + b

    local compTotalAccel = max(min(curTotalAccel * accelCoeff, maxTottalAccel), baseTurnAccel)

    -- https://www.desmos.com/calculator/flajtwbld5 for the functions calculating the in/out rate below
    if compTotalAccel < totalAccelSmoother:value() then
      learned_total_accel = totalAccelSmoother:getWithRateUncapped(compTotalAccel, dt, 0.45 - 0.4 * aggression) --> in rate
    else
      learned_total_accel = totalAccelSmoother:getWithRateUncapped(compTotalAccel, dt, 3 * aggression - 0.3) --> out rate
    end

    local wheelSpeed = electrics.values.wheelspeed
    local trnAccRatio = min(curTurnAccel, learned_turn_accel)/learned_turn_accel
	brake = max(0, min((aiSpeed - targetSpeed) * 3 * square(aggression), 1))
            * min(square(sqrt(aiSpeed/(targetSpeed + 1e-30)) - square(trnAccRatio)) , 1) -- TODO: I think this should be vehicle dependent
            * max(min(2 - (aiSpeed - wheelSpeed) * 0.2, 1), 0)

    throttle = max(0, min((targetSpeed - aiSpeed) * 2 * square(aggression), 1))

    -- see https://www.desmos.com/calculator/e24ebyxrbr for the second term in the calculation below
    throttle = ((throttle > 0.1 * (1 - aggression)) and throttle or 0)
                * min(square(1 - square(trnAccRatio)) , 1) -- TODO: I think this should be vehicle dependent
                * min(max((7 - (wheelSpeed - aiSpeed)) / 6.5, 0), 1)
	-- TODO: this still runs if there is no currentPlan, but raises error if there is no targetSpeed
	
	
    if targetPos == nil then
		--added
		if M.mode == 'derby' then
			obj:queueGameEngineLua("scenario_derby_vehicles.resetTarget("..tostring(aiID)..')')
		end
		--ended
		driveCar(0, 0, 0, 1)
		throttle = 0
	else
		aimToTarget()
	end
	--debugDraw(aiPos)
end

local function debugDraw(focusPos)

	local debugDrawer = obj.debugDrawProxy
		 if targetPos ~= nil then
		 local targetLength = max(aiSpeed * 0.65, 6.5)
		local halfRemainder = targetLength * 0.5
	 local p1Pos = targetPos
      local vec = aiPos - targetPos
      local vecLen = vec:length()

      targetAiMidPos = p1Pos + vec * min(halfRemainder, vecLen) / vecLen
    debugDrawer:drawSphere(0.25, (aiPos - aiDirVec*aiLength):toFloat3(), color(0,255,0,255))
   -- debugDrawer:drawSphere(0.5, targetPos:toFloat3(), color(255,0,0,255))
    --debugDrawer:drawSphere(0.3, targetAiMidPos:toFloat3(), color(255,0,0,255))


    local xyz = math.sin(math.rad(170)*0.5)*vec3(obj:getDirectionVectorUp())
    local q = quat(xyz.x, xyz.y, xyz.z, math.cos(math.rad(170)*0.5))
    local vec = aiDirVec:rotated(q)
   -- debugDrawer:drawCylinder(aiPos:toFloat3(), (aiPos+vec*50):toFloat3(), 0.02, color(0,0,255,200))

    xyz = math.sin(math.rad(-170)*0.5)*vec3(obj:getDirectionVectorUp())
    q = quat(xyz.x, xyz.y, xyz.z, math.cos(math.rad(-170)*0.5))
    vec = aiDirVec:rotated(q)
	--local ahead
		--if aiGear > 0 then
			--ahead = aiDirVec * aiSpeed + aiPos
		--else
			--ahead = -aiDirVec * aiSpeed + aiPos
		--end
		--local aheadTargetVec = (targetPos - ahead):normalized()
		--local aheadTarget = aiDirVec:dot(aheadTargetVec)
		--local dirDiff2 = -math.asin(aiDirVec:cross(vec3(obj:getDirectionVectorUp())):dot(aheadTargetVec))

   -- debugDrawer:drawCylinder(aiPos:toFloat3(), (aiPos+vec*50):toFloat3(), 0.02, color(0,0,255,200))
	--debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 2), color(0,0,0,255),  throttle.. "throttle")
  --debugDrawer:drawText(aiPos:toFloat3() + float3(0, 0, 3), color(0,0,0,255),  aheadTarget.. "aheadTarget")
  end
			 if M.debugMode == 'trajectory' then
				 -- Debug Throttle brake application
					local maxLen = 250
					local len = min(#trajectoryRec, maxLen)
					local last = trajectoryRec.last
				if len == 0 or (trajectoryRec[last][1] - aiPos:toFloat3()):length() > 0.25 then
					last = 1 + last % maxLen
					trajectoryRec[last] = {aiPos:toFloat3(), throttle, brake}
					len = min(len+1, maxLen)
				trajectoryRec.last = last
				end

				local param = float3(0.7, aiWidth, 0.7)
				for i = 1, len-1 do
				local rec = trajectoryRec[1+(last+i)%len]
				debugDrawer:drawSquarePrism(trajectoryRec[1+(last+i-1)%len][1], rec[1], param, param, color(255*sqrt(abs(rec[3])), 255*sqrt(rec[2]), 0, 100))
				end
			end
		
end
local function init()
  map = {}
end
local function setMode(mode)
	  local previousMode = M.mode
  M.mode = mode
  
	 if M.mode ~= 'disabled' and M.mode ~= 'stop' then -- TODO: this should be more explicit maybe?
    mapmgr.requestMap()
    M.updateGFX = updateGFX
	end
	
	if M.mode == 'disabled' then
    M.updateGFX = nop
    driveCar(0,0,0,0)
    currentRoute = nil
    targetPos = nil
    wheels.resetABSBehavior()
    --M.mode = 'stop'
    --mapmgr.disableTracking('AI')
  elseif M.mode ~= 'stop' then
    if controller.mainController then
      controller.mainController.setGearboxMode("arcade")
    end
    wheels.setABSBehavior("arcade")
  end

   speedRecordings = {}
  trajectoryRec = {last = 0}
  routeRec = {last = 0}
  
end
	
local function reset() -- called when the user pressed I
  M.manualTargetName = nil
  resetMapAndRoute()
  driveCar(0, 0, 0, 0)
  setMode(M.mode) -- some scenarios don't work if this is changed to setMode('disabled')
  stateChanged()
end
local function resetLearning()
  turnAccelSmoother:reset()
  totalAccelSmoother:reset()
  targetSpeedSmoother:reset()

  learned_turn_accel = turnAccelSmoother:value()
  learned_total_accel = totalAccelSmoother:value()
end

local function setVehicleDebugMode(newMode)
  tableMerge(M, newMode)
  if M.debugMode ~= 'trajectory' then
    trajectoryRec = {last = 0}
  end
  if M.debugMode ~= 'route' then
    routeRec = {last = 0}
  end
  if M.debugMode ~= 'speed' then
    speedRecordings = {}
  end
  if M.debugMode ~= 'off' then
    M.debugDraw = debugDraw
  else
    M.debugDraw = nop
  end
end
local function setState(newState)
  tableMerge(M, newState) --Set state to Derby mode
  setAggressionExternal(M.extAggression) -- set Aggression to 1
  setMode(M.mode)
  setVehicleDebugMode(M)
  setTargetObjectID(M.targetObjectID)
end

local function onDeserialized(v)
  setState(v)
  stateChanged()
end

local function dumpCurrentRoute()
  dump(currentRoute)
end
-- public interface
M.setTargetObjectID = setTargetObjectID
M.stateChanged = stateChanged
M.debugDraw = nop
M.setVehicleDebugMode = setVehicleDebugMode
M.reset = reset
M.init = init
M.setMode = setMode
M.setState = setState
M.onDeserialized = onDeserialized
M.getState = getState
M.setAggressionMode = setAggressionMode
M.setAggression = setAggressionExternal
M.updateGFX = updateGFX
M.dumpCurrentRoute = dumpCurrentRoute
return M

