-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}


M.racePlace = {}
local driver = {}
local logTag = 'gdrace'

local raceMarker = require("scenario/race_marker")
local helper = require('scenario/scenariohelper')
M.pathData = {}
local lapsEntered = 10

local function updatePlace(playerID)
	local place = M.racePlace
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do
		local vObj = scenetree.findObject(vName)
		local vid = vObj:getID()
		local vd = M.pathData[vid]
			
		local count = 1
		--print(vName)
		--print("lcount "..vd.lapCount.." ccount"..vd.cpCount.." Dist"..vd.wpdist.." end")
		local vehicleData = M.pathData
		for v,d in pairs(vehicleData) do
			if v ~= vid then
				if vd.lapCount < d.lapCount then
					count = count + 1
				end
				if vd.lapCount == d.lapCount then
					if vd.cpPoint < d.cpPoint then
						count = count + 1
					end
					if vd.cpPoint == d.cpPoint then
						if vd.wpdist > d.wpdist then
							count = count + 1
						end
					end		
				end
			end
		end	
		--print(count)
		place[count] = {}
		if not driver[vid] then
			driver[vid] = gdloader.getDriver(vid)
		end
		if vid ~= playerID then
			place[count] = {driver = driver[vid], lap = vd.lapCount}
		else
			place[count] = {driver = 'Your Place', lap = vd.lapCount}
		end
	end
	if not place[3] then
		place[3] = {driver = "---", lap = "0"}
	end
	M.racePlace = place
	--dump(place[1])
	--dump(place[2])
	--dump(place[3])
	guihooks.trigger('DerbyPlaceChange', { one = place[1].driver.. " "..place[1].lap, two = place[2].driver.. " "..place[2].lap, three = place[3].driver} )
end
local function checkPoints(vid)
	local scenario = scenario_scenarios.getScenario()
	if not M.pathData[vid] then
		M.pathData[vid] = {cpPoint = nil, lapCount = nil, wpdist = 0, target = nil}
	end
	local pathData = M.pathData[vid]
	--dump(pathData)
	--local aiRadFac = (scenario.radiusMultiplierAI or 1)
	--local Arena = gdloader.Arena
	--if Arena == 8 then
	--	aiRadFac = 13
	--end
	local data = scenario_waypoints.getVehicleWaypointData(vid)
	--dump(data)
	--dump(getVehicleWaypointData(vid))
	--dump(scenario.nodes)
	--dump(pathData)
	if pathData.cpPoint ~= data.next then
		pathData.cpPoint = data.next
		pathData.lap = data.lap
		pathData.target = scenario.lapConfig[data.next]
		M.pathData[vid] = pathData
	end
	--[[for wp,node in pairs(scenario.lapConfig) do
		local bestwp = string.sub(node, -1)
		bestwp = tonumber(bestwp)
		print(bestwp)
		--print("cppoint "..pathData.cpPoint)
		--print("lap "..pathData.lap)
		if bestwp == pathData.cpPoint then
			local vpos = vec3(be:getObjectByID(vid):getPosition()) 
			local npos = vec3(scenetree.findObject(node):getPosition())
			local wpdist = npos:distance(vpos)
			pathData.wpdist = wpdist
			--print(wpdist)
			if wpdist < aiRadFac then
				pathData.cpPoint = pathData.cpPoint + 1
				if pathData.cpPoint == 6 then
					pathData.cpPoint = 1 
					pathData.lap = pathData.lap + 1	
					--guihooks.trigger('RaceLapChange', {current = pathData.lap, count = scenario.lapCount} )
				end
				--scenario_waypoints.onScenarioVehicleTrigger(vid,data)
			end
			M.pathData[vid] = pathData
			break
		end
	end--]]
end
--[[local function getRoads()
	local roadCount = 1
	local t = string.format('levels/derby/racedata/lap'..Arena..'.json')
	local bestTime = readFile(t)
	if Arena == 7 then
		scenario_derby_airace.bestTime = 14.70  --oval
	else
		scenario_derby_airace.bestTime = 16.25 --concrete fig 8
	end
	bestTime = tonumber(bestTime)
	if bestTime and bestTime < scenario_derby_airace.bestTime then
		local l = string.format('levels/derby/racedata/time'..Arena..'.json')
		local lapData = readJsonFile(l)
		if lapData then
			--print(bestTime)
			--dump(lapData)
			scenario_derby_airace.bestTime = bestTime
			scenario_derby_airace.mapPath[roadCount] = {road = {}}
			for _,ld in ipairs(lapData) do
				scenario_derby_airace.mapPath[roadCount].road[ld.node] = {
				node = ld.node, 
				pos = vec3(ld.posx, ld.posy, ld.posz), 
				radius = ld.radius, 
				links = ld.links, 
				segTags = {}
				}
			end
		end
	else
		local decalRoads = scenetree.findClassObjects('DecalRoad')
		local trackName = nil
		if Arena == 7 then 
			trackName = "dirttrack"
		elseif Arena == 8 then
			trackName = "fig8concrete"
		end
		--dump(decalRoads)
		for _, decalRoadName in pairs(decalRoads) do
			if decalRoadName == trackName then
				local o = scenetree.findObject(decalRoadName)
				--dump(o)
				local segCount = o:getNodeCount() -1
				--print(segCount)
				if segCount > 0 then
					local nextLink = nil
					if tonumber(decalRoadName) == nil then
						scenario_derby_airace.mapPath[roadCount] = {road = {}}
						for i = 1, segCount do
							if i == segCount then
								nextLink = 1
							else
								nextLink = i + 1
							end
								scenario_derby_airace.mapPath[roadCount].road[i] = {
								node = i, 
								pos = vec3(o:getNodePosition(i)), 
								radius = o:getNodeWidth(i), 
								links = nextLink, 
								segTags = {}
								}
						end
					end
				end
			end
		end
	end
end
]]--
local function deleteRoads()
	local objName = nil
	local obj = nil
	local unload = false
	local objNames = {'derby','dirttrackwp','fig8concretewp'}
	for _,objName in ipairs(objNames) do
		obj = scenetree[objName]
		if obj then
			unload = true
		end
		if unload == true then 
			obj:unload()
			obj:delete()

			be:reloadCollision()
			log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
			unload = false
		end
	end
end
local function updateScenarioData(scenario)
	local newScenario = scenario
	local copyScenario = scenario_scenarios
	copyScenario['setScenario'] =  function(sc) 
		scenario = sc
		end  
	scenario_scenarios = copyScenario
	scenario_scenarios.setScenario(newScenario)
end
local function updateScenarioVehicles()
	local vehicles = scenetree.findClassObjects('BeamNGVehicle')
	if vehicles then
		for k, vecName in ipairs(vehicles) do
			local to = scenetree.findObject(vecName)
			if to then
				local ScenarioObjectsGroup = scenetree.findObject('ScenarioObjectsGroup')
				if ScenarioObjectsGroup then
					ScenarioObjectsGroup:addObject(to.obj)
				end
			end
		end
	end
end
local function createRoads()
	deleteRoads()
	local Arena = gdloader.Arena

	local scenario = scenario_scenarios.getScenario()
	-- try to load some defaults
	local objName 
	local directory = 'prefabs/'
	scenario.prefabs = {}
	local trackName = nil 
	local tmp = scenario.mission..""..directory.."" .. scenario.levelName ..".prefab"
	if FS:fileExists(tmp) then
		table.insert(scenario.prefabs, tmp)
	end
	scenario.lapConfig = {}
	if Arena < 7 then
		objName = scenario.levelName
		lapsEntered = 1
		scenario.lapCount = 1	
		--scenario_gdvehicles.createVehicles()
	else
		scenario.lapCount = lapsEntered or 10
		
		if Arena == 7 then
			objName = 'dirttrackwp'
			trackName = "dirttrack"
		elseif Arena == 8 then
			objName = 'fig8concretewp'
			trackName = "fig8concrete"
		--aiRadFac = 5
		end
		directory = 'prefabs/waypoints/'
		tmp = scenario.mission..""..directory.."" .. objName ..".prefab"
		if FS:fileExists(tmp) then
			table.insert(scenario.prefabs, tmp)
		end
	end
		--print('test')
		updateScenarioData(scenario)
		scenario = scenario_scenarios.getScenario()
		scenario_scenarios.onClientStartMission(scenario.mission)  --create the prefabs
		scenario_gdvehicles.createVehicles()
		local waypointsTable = scenetree.findClassObjects('BeamNGWaypoint')
		--dump(waypointsTable)
		scenario.lapConfig = {}
		for k, nodeName in ipairs(waypointsTable) do
			if trackName and string.startswith( nodeName, trackName ) then
				table.insert(scenario.lapConfig, nodeName)
				log('D', 'scenario', tostring(k) .. ' = ' .. tostring(nodeName))
			end
		end
	--[[
	local ScenarioObjectsGroup = scenetree.findObject('ScenarioObjectsGroup')
	log('D', logTag, 'spawning prefabs ...')
	for i, filename in ipairs(scenario.prefabs) do
		if not FS:fileExists(filename) then
			log('E', logTag, 'Prefab file not existing: '.. tostring(filename) .. ' - IGNORING IT')
		else
			objName = string.gsub(filename, "(.*/)(.*)%.prefab", "%2")
			if not scenetree.findObject(objName) then
				--log('D', logTag, 'executing TS: ' .. ts)
				local prefabObj = spawnPrefab(objName, filename, '0 0 0', '0 0 1', '1 1 1')
				ScenarioObjectsGroup:addObject(prefabObj.obj)
			else
				log('E', logTag, 'Prefab: '..objName..' already exist in level')
			end
		end
	end

		  be:physicsStartSimulation()
		  --]]
	 -- we are figuring out the waypoints and build the node graph with the positions of the level
	 --  complete the node graph with the spawned waypoints

	--log('D', 'scenario', "found " .. #waypointsTable .. " waypoints")
	--scenario.nodes = {}
	
	--local aiRadFac = (scenario.radiusMultiplierAI or 1)

	--dump(waypointsTable)
	

	--
	--[[		local o = scenetree.findObject(nodeName)
			if o then
				if scenario.nodes[nodeName] == nil then
					local rota = nil
					if o:getField('directionalWaypoint',0) == '1' then
						rota = quat(o:getRotation())*vec3(1,0,0)
					end
					scenario.nodes[nodeName] = {
						pos = vec3(o:getPosition()),
						radius = getSceneWaypointRadius(o), --o:getScale():len() * aiRadFac,
						rot = rota
					}
				end
			else
				log('E', 'scenario', 'waypoint not found: ' .. tostring(nodeName))
			end
		end
	end	
		--reset map to make sure waypoints from the prefab are also considered
  map.load()

  --second step: try to find the waypoint in the AI graph
	local mapData = map.getMap()
	
	if mapData and scenario.lapConfig then
		
		for _, wp in ipairs(scenario.lapConfig) do
			if scenario.nodes[wp] == nil then
				if mapData.nodes[wp] ~= nil then
					scenario.nodes[wp] = deepcopy(mapData.nodes[wp])
					scenario.nodes[wp].radius = scenario.nodes[wp].radius * aiRadFac
					scenario.nodes[wp].pos = vec3(scenario.nodes[wp].pos)
					scenario.nodes[wp].rot = vec3(scenario.nodes[wp].rot)
				else
					log('E', logTag, 'unable to find waypoint: ' .. dumps(wp))
				end
			end
		end
	else
		log('W', logTag, 'no ai graph for this map found')
	end
	
 -- dump(mapData)
 
	--]]
	
		--dump(scenario)
	--scenario = scenario_scenarios.getScenario()
	local state = scenario.state
	scenario.state = 'pre-start'
	updateScenarioData(scenario)
	updateScenarioVehicles()
	map.assureLoad()
	scenario_scenarios.onPreRender()
	raceMarker.init()
	scenario_waypoints.initialise()
	extensions.hook("onRaceInit")
	scenario.state = state
	updateScenarioData(scenario)
	guihooks.trigger('ChangeState', {state ='menu'})
	scenario = scenario_scenarios.getScenario()
	--dump(scenario)
end
local function lapSelection(enteredLaps)
	print("laps "..enteredLaps)
	lapsEntered = tonumber(enteredLaps)
end

local function update(playerID)

	local scenario = scenario_scenarios.getScenario()
	local vehIn = gdloader.vehIn
	for _,vid in ipairs(vehIn) do
		--checkPoints(vid)
		--local pathData = M.pathData[vid]
		if vid == playerID then
		--raceMarker.hide(true)
		else
			if not M.pathData[vid] then
				M.pathData[vid] = {cpPoint = nil, lapCount = nil, wpdist = 0, target = nil}
			end
		
			local data = scenario_waypoints.getVehicleWaypointData(vid)
			local target = M.pathData[vid].target
			if M.pathData[vid].cpPoint ~= data.next then
				M.pathData[vid].cpPoint = data.next
				M.pathData[vid].lap = data.lap
				target = nil
			end
			if not target then	
				local targetNodeName = scenario.lapConfig[data.next]
				local veh = be:getObjectByID(vid)
				if veh then
					--print(targetNodeName)
					helper.queueLuaCommand(veh, 'gdai.setTarget("' .. targetNodeName .. '")')
				end
				M.pathData[vid].target = data.next
			end
		end
	end
	--updatePlace(playerID)
end
local function onScenarioRestarted()
	M.racePlace = {}
	driver = {}
	M.pathData = {}
	lapsEntered = 10
end
--M.setupScenario = setupScenario
M.lapSelection = lapSelection
M.onScenarioRestarted = onScenarioRestarted
M.updatePlace = updatePlace
--M.getRoads = getRoads
M.checkPoints = checkPoints
M.createRoads = createRoads
M.update = update

return M