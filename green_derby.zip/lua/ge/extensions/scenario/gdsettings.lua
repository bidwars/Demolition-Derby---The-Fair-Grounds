-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local lookback = 'forward'
local currentcam = nil


local function adjustCamera()
	local camera = gdloader.options.camera
	if camera == false then return end
	local cam = core_camera.getActiveCamName(0)
	if cam == 'driver' then
		gdcallback.driveTrain()
		local drive = gdloader.driveTrain
		if drive and type(drive) == 'table' then
			if drive.gear > 0 then
				if lookback == 'back' or currentcam ~= cam then
					core_camera.rotate_yaw_right(0, 0)
					core_camera.rotate_yaw_left(0, 0)						
					lookback = 'forward' 
				end
			elseif drive.gear < 0 then
				if lookback == 'forward' or currentcam ~= cam then
					core_camera.rotate_yaw_right(1, 0)
					core_camera.rotate_yaw_left(-1, 0)
					lookback = 'back'
				end
			end
		end
		if currentcam ~= cam then
			currentcam = cam
		end
	end
end

local function adjustSettings()
	local fuel = gdloader.options.fuel
	local fire = gdloader.options.fire
	local radiator = gdloader.options.radiator
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
	for _,vName in ipairs(sVehicles) do
		local vObj = scenetree.findObject(vName)
		if vObj then
			if fire == false then
				vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
			end	
		end
	end
	local vehIn = gdloader.vehIn
	for _, vid in ipairs(vehIn) do	
		local vObj = be:getObjectByID(vid)
		if vObj then
			if fuel == false then
				vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
			end
			vObj:queueLuaCommand([[
			local maxrd = ]]..radiator..[[
			local maxEngineTemp = 0
			local maxCylinderTemp = 0
			local maxOilTemp = 140
			local engine = powertrain.getDevice("mainEngine")
			if engine then
				local cwt = engine.thermals.cylinderWallTemperature
				local ebt = engine.thermals.engineBlockTemperature
				local rd = engine.thermals.radiatorDamage
				local ebm = engine.jbeamData.engineBlockMaterial
				local ot = engine.thermals.oilTemperature
				if rd == maxrd then
					if ot > maxOilTemp then
						engine.thermals.oilTemperature = maxOilTemp
					end
					if ebm == "iron" then 
						maxEngineTemp = 1000
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 1100
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					else
						maxEngineTemp = 600
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 620
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					end
				end
			end
			]])
		end
	end
end
local function update()
	adjustCamera()
	adjustSettings()
end

M.update = update
return M