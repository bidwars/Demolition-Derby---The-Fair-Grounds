angular.module('beamng.stuff')
.controller('derbyController',['$log', '$scope', '$state', 'bngApi', 'storeData', function ($log, $scope, $state, bngApi, storeData) {
  var vm = this;

  $scope.opponents = [
	{id:17, name:"17 Cars"},
	{id:16, name:"16 Cars"},
	{id:15, name:"15 Cars"},
	{id:14, name:"14 Cars"},
	{id:13, name:"13 Cars"},
	{id:12, name:"12 Cars"},
	{id:11, name:"11 Cars"},
	{id:10, name:"10 Cars"},
	{id:9, name:"9 Cars"},
	{id:8, name:"8 Cars"},
	{id:7, name:"7 Cars"},
	{id:6, name:"6 Cars"},
	{id:5, name:"5 Cars"},
	{id:4, name:"4 Cars"},
	{id:3, name:"3 Cars"},
	{id:2, name:"2 Cars"},
	{id:1, name:"1 Car"}
	];
$scope.classes = [
	{id:8, name:"Random"},
	{id:7, name:"Pigeon"},
	{id:6, name:"Luxury/Sport Cars"},
	{id:5, name:"Compact Cars"},
	{id:4, name:"Mid-Size Cars"},
	{id:3, name:"Large Cars"},
	{id:2, name:"Truck Pickups/Vans/SUVs"},
	{id:1, name:"Heavy Semis"}
	];
$scope.mods = [
	{id:5, name:"All Mods and BeamNG - Official"},
	{id:4, name:"Peter Derby - Derby Stuff Mod Pack"},
	{id:3, name:"F150 Mods"},
	{id:2, name:"All Mods"},
	{id:1, name:"No Mods"}
	];
$scope.vehicle = [
	{id:1, name:"Auto", type:"Model"}
	];
$scope.states = [
	{id:5, name:"Stock Config"},
	{id:4, name:"Pro-Derby Config"},
	{id:3, name:"Basic-Derby Config"},
	{id:2, name:"Stripped Config"},
	{id:1, name:"Low-End Config"}
	];
  $scope.arenas = [
	{id:8, name:"Concrete Figure 8 Racing"},
	{id:7, name:"Oval Dirt Racing"},
	{id:6, name:"Mud Pit Derby"},
	{id:5, name:"Oval Dirt Derby"},
	{id:4, name:"Varied Ground Derby"},
	{id:3, name:"Grass Derby"},
	{id:2, name:"Concrete Derby"},
	{id:1, name:"Free Fall Derby"}
	];
$scope.selectedLaps = 10;
$scope.tab = 1;
$scope.setTab = function(newTab){
      $scope.tab = newTab;
};
$scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
};
$scope.showArenas = function(arena){
	bngApi.engineLua('gdloader.getArena(' + bngApi.serializeToLua(arena) + ')', function (show) {	
	if(show == 1)
		$scope.showArena = true;
	else
		$scope.showArena = false;
	});
};

$scope.Selection = function(opponents,classes,mods,vehicles,states,arena) {	
 	storeData.saveSelection(opponents,classes,mods,vehicles,states,arena);
	
	$scope.showArenas(arena);
	bngApi.engineLua('scenario_gdclasses.modelName()', function (response) {	
		$scope.$apply(function () {$scope.vehicle = response;});
	});	
    bngApi.engineLua('gdloader.selection(' + bngApi.serializeToLua(opponents) + ',' + bngApi.serializeToLua(classes) + ',' + bngApi.serializeToLua(mods) + ','+ bngApi.serializeToLua(vehicles) + ','+ bngApi.serializeToLua(states) + ')');	
};
$scope.getLaps = function (){
	if($scope.selectedArena == 7 || $scope.selectedArena == 8) 
		$scope.showLaps = true;
	else 
		$scope.showLaps = false;
};
$scope.lapSelection = function(laps) {
    	bngApi.engineLua('scenario_gdrace.lapSelection(' + bngApi.serializeToLua(laps) + ')');
};
$scope.getSelection = function(){
	console.log('function call');
	$scope.selectedOpponent = storeData.getSelection1();
	$scope.selectedClass = storeData.getSelection2();
	$scope.selectedMods = storeData.getSelection3();
	$scope.selectedVehicle = storeData.getSelection4();
	$scope.selectedState = storeData.getSelection5();
	$scope.selectedArena = storeData.getSelection6();
	$scope.getLaps();
};
$scope.$watch('$viewContentLoaded', function() {
	$scope.selectedOpponent = storeData.getSelection1();
	$scope.selectedClass = storeData.getSelection2();
	$scope.selectedMods = storeData.getSelection3();
	$scope.selectedVehicle = storeData.getSelection4();
	$scope.selectedState = storeData.getSelection5();
	$scope.selectedArena = storeData.getSelection6();
	$scope.getLaps();
	$scope.showArenas($scope.selectedArena);
	$scope.Selection($scope.selectedOpponent,$scope.selectedClass,$scope.selectedMods,$scope.selectedVehicle,$scope.selectedState,$scope.selectedArena);
});
}])
.service("storeData", function(){
this.saveSelection = function(opponents,classes,mods,vehicles,states,arena){
this.opponents = opponents;
this.classes = classes;
this.mods = mods;
this.vehicles = vehicles;
this.states = states;
this.arena = arena;
}
this.getSelection1 = function() {
	if(this.opponents === undefined){
	this.opponents = 4;};
	return this.opponents;
}
this.getSelection2 = function() {
	if(this.classes === undefined){
	this.classes = 3;};
	return this.classes;
}
this.getSelection3 = function() {
	if(this.mods === undefined){
	this.mods = 1;};
	return this.mods;
}
this.getSelection4 = function() {
	if(this.vehicles === undefined){
	this.vehicles = 1;};
	return this.vehicles;
}
this.getSelection5 = function() {
	if(this.states === undefined){
	this.states = 3;};
	return this.states;
}
this.getSelection6 = function() {
	if(this.arena === undefined){
	this.arena = 3;};
	return this.arena;
}
});

