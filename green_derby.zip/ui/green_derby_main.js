angular.module('beamng.stuff')
.controller('derbyController',['$log', '$scope', '$state', 'bngApi', 'storeData', function ($log, $scope, $state, bngApi, storeData) {
  var vm = this;

  $scope.opponents = [
	{id:17, name:"17 Cars"},
	{id:16, name:"16 Cars"},
	{id:15, name:"15 Cars"},
	{id:14, name:"14 Cars"},
	{id:13, name:"13 Cars"},
	{id:12, name:"12 Cars"},
	{id:11, name:"11 Cars"},
	{id:10, name:"10 Cars"},
	{id:9, name:"9 Cars"},
	{id:8, name:"8 Cars"},
	{id:7, name:"7 Cars"},
	{id:6, name:"6 Cars"},
	{id:5, name:"5 Cars"},
	{id:4, name:"4 Cars"},
	{id:3, name:"3 Cars"},
	{id:2, name:"2 Cars"},
	{id:1, name:"1 Car"}
	];
$scope.class = [
	{id:8, name:"Random"},
	{id:7, name:"Pigeon"},
	{id:6, name:"Luxury/Sport Cars"},
	{id:5, name:"Compact Cars"},
	{id:4, name:"Mid-Size Cars"},
	{id:3, name:"Large Cars"},
	{id:2, name:"Truck Pickups/Vans/SUVs"},
	{id:1, name:"Heavy Semis"}
	];
$scope.mods = [
	{id:5, name:"All Mods and BeamNG - Official"},
	{id:4, name:"Peter Derby - Derby Stuff Mod Pack"},
	{id:3, name:"F150 Mods"},
	{id:2, name:"All Mods"},
	{id:1, name:"No Mods"}
	];
$scope.vehicle = [
	{id:1, name:"Auto", type:"Model"}
	];
$scope.states = [
	{id:5, name:"Stock Config"},
	{id:4, name:"Pro-Derby Config"},
	{id:3, name:"Basic-Derby Config"},
	{id:2, name:"Stripped Config"},
	{id:1, name:"Low-End Config"}
	];
  $scope.arenas = [
	{id:6, name:"Mud Pit"},
	{id:5, name:"Concrete Figure 8"},
	{id:4, name:"Oval Dirt Track"},
	{id:3, name:"Grass"},
	{id:2, name:"Concrete"},
	{id:1, name:"Free Fall"}
	];
$scope.selectedLaps = 10;
$scope.Selection = function(arg1,arg2,arg3,arg4,arg5,arg6) {
 	storeData.saveSelection(arg1,arg2,arg3,arg4,arg5,arg6);

    	bngApi.engineLua('scenario_derby_main.Selection(' + bngApi.serializeToLua(arg1) + ',' + bngApi.serializeToLua(arg2) + ',' + bngApi.serializeToLua(arg3) + ','+ bngApi.serializeToLua(arg4) + ','+ bngApi.serializeToLua(arg5) + ','+ bngApi.serializeToLua(arg6) + ')', function (response) {
      //console.log("got response from lua: ", response);
      $scope.$apply(function () { 
	$scope.vehicle = response;
	});
 });	
}	
$scope.lapSelection = function(arg7) {
    	bngApi.engineLua('scenario_derby_main.lapSelection(' + bngApi.serializeToLua(arg7) + ')');
 }; 
$scope.getSelection = function(){
	console.log('function call');
	$scope.selectedOpponent = storeData.getSelection1();
	$scope.selectedClass = storeData.getSelection2();
	$scope.selectedMods = storeData.getSelection3();
	$scope.selectedVehicle = storeData.getSelection4();
	$scope.selectedState = storeData.getSelection5();
	$scope.selectedArena = storeData.getSelection6();
};
$scope.getDetails = function (){
	if($scope.selectedArena == 4) 
		$scope.result = true;
	else 
		$scope.result = false;
}

$scope.$watch('$viewContentLoaded', function() {
	$scope.selectedOpponent = storeData.getSelection1();
	$scope.selectedClass = storeData.getSelection2();
	$scope.selectedMods = storeData.getSelection3();
	$scope.selectedVehicle = storeData.getSelection4();
	$scope.selectedState = storeData.getSelection5();
	$scope.selectedArena = storeData.getSelection6();
	$scope.getDetails();

	$scope.Selection($scope.selectedOpponent,$scope.selectedClass,$scope.selectedMods,$scope.selectedVehicle,$scope.selectedState,$scope.selectedArena);
});
}])
.service("storeData", function(){
this.saveSelection = function(arg1,arg2,arg3,arg4,arg5,arg6){
this.arg1 = arg1;
this.arg2 = arg2;
this.arg3 = arg3;
this.arg4 = arg4;
this.arg5 = arg5;
this.arg6 = arg6;
}
this.getSelection1 = function() {
	if(this.arg1 === undefined){
	this.arg1 = 4;};
	return this.arg1;
}
this.getSelection2 = function() {
	if(this.arg2 === undefined){
	this.arg2 = 3;};
	return this.arg2;
}
this.getSelection3 = function() {
	if(this.arg3 === undefined){
	this.arg3 = 1;};
	return this.arg3;
}
this.getSelection4 = function() {
	if(this.arg4 === undefined){
	this.arg4 = 1;};
	return this.arg4;
}
this.getSelection5 = function() {
	if(this.arg5 === undefined){
	this.arg5 = 3;};
	return this.arg5;
}
this.getSelection6 = function() {
	if(this.arg6 === undefined){
	this.arg6 = 3;};
	return this.arg6;
}
});

