angular.module('beamng.apps')

/**
 * @ngdoc directive
 * @name beamng.apps:derbyPlace
 * @description 
**/
.directive('derbyPlace', function () {  
    return {
	template: 
		'<div ng-class="{\'bngApp\' : data}" style="width: 100%; height: 100%; font-size: 1.4em;" ' +		
		'layout="column" layout-align="start start">' +
        '<span ng-if="data">1st {{ data.one }} </span>' +
		'<span ng-if="data">2nd {{ data.two }} </span>' +
		'<span ng-if="data">3rd {{ data.three }} </span>' +
      '</div>',
    replace: true,
    link: function (scope, element, attrs) {
      scope.data = null;
      scope.$on('DerbyPlaceChange', function (event, data) {
        //console.log('Testing to see if we get Data');
	   if(data === null) return; 
        scope.$applyAsync(function () { 
          scope.data = data;
		 
        });
      });

      scope.$on('ScenarioNotRunning', function () {
        scope.data = null;
      });
    }
  };
});