-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local startvehicleConfig = 0
local startvehicleClass = 0 
local startArena = 0 
local removePartsFile = {} --Table of parts to remove
local startData = {}


local function getPosRot(i)
	local Arena = gdloader.Arena
	local position = {}
	local rotation = {}
	local data = {}
		if Arena == 1 then
			data = startData.freefall
		elseif Arena == 2 then 
			data = startData.concrete 
		elseif Arena == 3 then
			 data = startData.grass
		elseif Arena == 4 then
			data = startData.vground
		elseif Arena == 5 then
			data = startData.ovalderby
		elseif Arena == 6 then
			data = startData.mudpit
		elseif Arena == 7 then
			data = startData.ovalrace
		elseif Arena == 8 then
			data = startData.fig8concrete
		else
			if i == 1 then 
				data[i] = gdloader.startPos
			else
				local rot = quat(1, 0, 0, 0)
				local dir = vec3(0, -1, 0)
				local pos = vec3(0,0,0)
				
				local playerVehicleID = be:getPlayerVehicleID(0)
				for k, v in pairs(map.objects) do
					if k == playerVehicleID then
						dir = v.dirVec:normalized()
						rot = quatFromDir(dir)
					end
				end
				local playerVehicle = be:getPlayerVehicle(0)
				local offset = vec3(-dir.y, dir.x, 0)
				pos = vec3(playerVehicle:getPosition()) + offset * 5
				data[i] = {pos =  pos , rot = rot}
			end
		end	

		for j,t in pairs(data) do
			j = tonumber(j)
			if j == i then
				position = t.pos
				rotation = t.rot
				return position, rotation
			end
		end
end
local function setRotation(rot)
	local veh = be:getPlayerVehicle(0)
	if veh then 
		veh.obj.playerUsable = true
		local driver = veh.name 
		--print(driver)
		TorqueScript.eval([[
		]]..driver..[[.rotation = "]]..rot.x..' '..rot.y..' '..rot.z..' '..rot.w..[[";]])
	end
end
local function setPlayer(position,rotation)
	local veh = be:getPlayerVehicle(0)
	if veh then 
		veh:setPosRot(position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w)
		setRotation(rotation)
	end
	
end
-------------------------------------------------------------------------------------
--SETS THE PARTS FOR EACH vehicle
-------------------------------------------------------------------------------------
local function partsConfig(firstLoad)
	local vehicleConfig = gdloader.vehicleConfig
	local vehicleClass = gdloader.vehicleClass
	local vehiclePick = gdloader.vehiclePick
	local Arena = gdloader.Arena
	local startPos = {}
	if firstLoad == 1 then
		startvehicleConfig = vehicleConfig
		startvehicleClass = vehicleClass
		startArena = Arena
		local k = string.format('levels/derby/prefabs/startPos.json')
		startData = readJsonFile(k)
	end
	local includeMods = gdloader.includeMods
	local path = string.format('levels/derby/configs/removeParts.pc')
	removePartsFile = scenario_gdclasses.readPartsFile(path)
	local model, pcs = scenario_gdclasses.loadClass(removePartsFile)
	--dump(pcs)	
	local position, rotation = getPosRot(1)
	local options = {config = pcs, pos = position}
	if firstLoad == 1 then 
		--core_vehicles.removeAll()
		return
		--gdloader.vehIn = {}
		--core_vehicles.spawnNewVehicle(model, options)
		--setPlayer(position,rotation)
	else
		if startvehicleConfig ~= vehicleConfig or startvehicleClass ~= vehicleClass or includeMods > 1 or vehiclePick > 1 or startArena ~= Arena then	
			core_vehicles.removeCurrent()
			gdloader.vehIn = {}
			core_vehicles.spawnNewVehicle(model, options)
			setPlayer(position,rotation)
		else
			core_vehicles.removeCurrent()
			gdloader.vehIn = {}
			core_vehicles.spawnNewVehicle(model, options)
			setPlayer(position,rotation)
		end
	end	
end
-------------------------------------------------------------------------------------
--CREATES THE AI VEHICLES FOR THE SCENARIO  
-------------------------------------------------------------------------------------
local function createVehicles()				
	partsConfig(2
	)
	local count = gdloader.vehicleCountEntered 
	for i=1,count do
		--model is the vehicle type, and pcs is the parts Configuration
		
		local k = i + 1
		local model, pcs = scenario_gdclasses.loadClass(removePartsFile)
		local position, rotation = getPosRot(k)
		local options = {config = pcs, pos = position}
		core_vehicles.spawnNewVehicle(model, options)
		setRotation(rotation)
	end
end

M.partsConfig = partsConfig
M.createVehicles = createVehicles
M.loadVehicles = loadVehicles

return M