-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}


M.racePlace = {}
local driver = {}
local logTag = 'gdrace'
local playerID = nil
local helper = require('scenario/scenariohelper')
local raceMarker = require("scenario/race_marker")
M.pathData = {}
local waypoint = {}

local function updatePlace(playerID)
	local place = {}
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do
		 local veh = scenetree.findObject(vName)
		if veh then
			local vid = veh:getID()
			--print(vid)
			local vd = M.pathData[vid]
			--dump(vd)
			if vd then
				local count = 1
				--print(vName)
				--print("lcount "..vd.lap.." ccount"..vd.cpPoint.." Dist"..vd.wpdist.." end")
				local vehicleData = M.pathData
				for v,d in pairs(vehicleData) do
					if v ~= vid then
						if vd.lap < d.lap then
							count = count + 1
						end
						if vd.lap == d.lap then
							if vd.cpPoint < d.cpPoint then
								count = count + 1
							end
							if vd.cpPoint == d.cpPoint then
								if vd.wpdist > d.wpdist then
									count = count + 1
								end
							end		
						end
					end
				end	
				--print(count)
				place[count] = {}
				if not driver[vid] then
					for k,v in ipairs(gdloader.vehIn) do
						if v.vid == vid then
							driver[vid] = gdloader.vehIn[k].driverName or 'error'
							break
						end
					end
				end
				if vid ~= playerID then
					place[count] = {driver = driver[vid], lap = vd.lap}
				else
					place[count] = {driver = 'You', lap = vd.lap}
				end
			end
		end
	end
	--local update = false
	if not place[3] then
		place[3] = {driver = "---", lap = "0"}
	end
	if not place[2] then
		place[2] = {driver = "---", lap = "0"}
	end
	if not place[1] then
		place[1] = {driver = "---", lap = "0"}
	end
	
	M.racePlace = place
	--dump(place)
	--dump(place[2])
	--dump(place[3])

	guihooks.trigger('DerbyPlaceChange', { one = place[1].driver.. " "..place[1].lap, two = place[2].driver.. " "..place[2].lap, three = place[3].driver.. " "..place[3].lap} )
end
local function update(playerID)

	local scenario = scenario_scenarios.getScenario()
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')	
	for _, vName in ipairs(sVehicles) do
		local veh = scenetree.findObject(vName)
		if veh then 
			local vid = veh:getID()
			if not M.pathData[vid] then
				M.pathData[vid] = {cpPoint = nil, lap = 0, wpdist = 0, target = nil}
			end
			local data = scenario_waypoints.getVehicleWaypointData(vid)
			if not data then return end
			--dump(data)
			local pos = veh:getPosition()
			if data.nextWps[1] then 
			local node = data.nextWps[1].cpName
				if node and scenario then 
					local wp = scenario.nodes[node]
					if wp then
						local wpPos = wp.pos
						if wpPos then
							M.pathData[vid].wpdist = wpPos:distance(pos)
						--print(M.pathData[vid].wpdist)
						else
							M.pathData[vid].wpdist = 999
						end
					end
				end
			end
			if data.next then
				if M.pathData[vid].cpPoint ~= data.next then
					M.pathData[vid].cpPoint = data.next
				end
			else
				M.pathData[vid].cpPoint = 1
			end
			if data.lap then
				if M.pathData[vid].lap ~= (data.lap + 1) then
					M.pathData[vid].lap = data.lap + 1
				end
			else
				M.pathData[vid].lap = 1
			end
		end
	end
	updatePlace(playerID)
end
local function updateScenarioData(scenario)
	local newScenario = scenario
	local copyScenario = scenario_scenarios
	copyScenario['setScenario'] =  function(sc) 
		scenario = sc
		end  
	scenario_scenarios = copyScenario
	scenario_scenarios.setScenario(newScenario)
end
local function updateScenarioVehicles()
	local vehicles = scenetree.findClassObjects('BeamNGVehicle')
	if vehicles then
		for k, vecName in ipairs(vehicles) do
			local to = scenetree.findObject(vecName)
			if to then
				local ScenarioObjectsGroup = scenetree.findObject('ScenarioObjectsGroup')
				if ScenarioObjectsGroup then
					ScenarioObjectsGroup:addObject(to.obj)
				end
			end
		end
	end
end
local function setScenario()
	local arenaGroup = gdloader.options.arena.type
	local arena = gdloader.options.arena.name
	--local laps = gdloader.options.laps 
	local mapName = getMissionFilename():match('levels/([%w|_|%-|%s]+)/')
	local scenario = scenario_scenarios.getScenario()
	-- try to load some defaults
	local directory = 'prefabs/'
	scenario.prefabs = {}
	local trackName
	local objName 
	local fn = scenario.mission..""..directory.."" .. scenario.levelName ..".prefab"
	if FS:fileExists(fn) then
		table.insert(scenario.prefabs, fn)
	else
		fn = "levels/"..mapName.."/"..directory.."" .. mapName..".prefab"
			--if FS:fileExists(fn) then
			print(fn)
				table.insert(scenario.prefabs, fn)
			--end
	end
	if arenaGroup == 'Derby' then
		objName = scenario.levelName
		scenario.lapCount = 1
	else
		guihooks.trigger('DerbyPlaceChange', nil)
		objName = arena
		trackName = 'road'
		directory = 'prefabs/waypoints/'
		fn = scenario.mission..""..directory.."" .. objName ..".prefab"
		if FS:fileExists(fn) then
			print(fn)
			table.insert(scenario.prefabs, fn)
		else
			
			fn = "levels/"..mapName.."/"..directory.."" .. objName ..".prefab"
			--if FS:fileExists(fn) then
			print(fn)
				table.insert(scenario.prefabs, fn)
			--end
		end
	end
	updateScenarioData(scenario) --saves the information to the scenario
	scenario = scenario_scenarios.getScenario()
	scenario_scenarios.onClientStartMission(scenario.mission)  --create the prefabs spawn prefabs
	scenario_gdvehicles.createVehicles()
	local waypointsTable = scenetree.findClassObjects('BeamNGWaypoint') --find the new waypoints we just spawned from prefabs
	--dump(waypointsTable)
	scenario.lapConfig = {}  --set the scenario lap config
	for k, nodeName in ipairs(waypointsTable) do
		if trackName and string.startswith( nodeName, trackName ) then
			table.insert(scenario.lapConfig, nodeName)
			log('D', 'scenario', tostring(k) .. ' = ' .. tostring(nodeName))
		end
	end
	local state = scenario.state
	scenario.state = 'pre-start'
	--if arenaGroup ~= 'Derby' then
		--waypoint = scenario.lapConfig
		--table.insert(waypoint, scenario.lapConfig[1])
		
		--scenario.statistics = {disableEndUI = true}
		scenario.whiteListActions = {"switch_next_vehicle", "switch_previous_vehicle", "loadHome", "saveHome", "recover_vehicle", "reload_vehicle", "vehicle_selector", "parts_selector", "dropPlayerAtCamera", "nodegrabberRender", "slower_motion", "faster_motion", "realtime_motion", "slow_motion"}
		scenario.blackListActions =  {}
	--end
	updateScenarioData(scenario)
	if arenaGroup ~= 'Derby' then
		scenario.BranchLapConfig = scenario.lapConfig
		scenario.initialLapConfig = deepcopy(scenario.lapConfig)
		updateScenarioVehicles()
	end
	
	map.assureLoad()
	scenario_scenarios.onPreRender()  -- set the scenario back to pre-start state.  This sets up the scenario with all the correct information
	scenario.state = state --set the scenario.state back to racing
	updateScenarioData(scenario)
	--dump(scenario)
	if arenaGroup == 'Derby' then
		updateScenarioVehicles()
	end
	guihooks.trigger('ChangeState', {state ='menu'})  --remove the start menu
end
local function setAiPath(arg)
	local vehicleName = arg.vehicleName
	local waypoints = arg.waypoints
	local routeSpeed = arg.routeSpeed or 0
	local routeSpeedMode = arg.routeSpeedMode or 'off'
	local driveInLane = arg.driveInLane or 'off'
	local speeds = arg.speeds or {}
	local lapCount = arg.lapCount or 0
	local aggression = arg.aggression or 1
	local aggressionMode = arg.aggressionMode or '' -- rubberBand or nil (aggression decreases with distance from opponent)
	local resetLearning = arg.resetLearning and 'true' or 'false'
  --print('setAiPath')
	helper.queueLuaCommandByName(vehicleName, 'gdai.driveUsingPath({wpTargetList = '..serialize(waypoints)..', routeSpeed = '..routeSpeed..', routeSpeedMode = "'..routeSpeedMode..'", driveInLane = "'..driveInLane..'", wpSpeeds = '..serialize(speeds)..', noOfLaps = '..lapCount..', aggression = '..aggression..', aggressionMode = "'..aggressionMode..'", resetLearning = '..resetLearning..'})')

	--This causes the checkpoints to be all messed up in my scenario
 
  --if core_checkpoints then
    --core_checkpoints.saveAIPath(vehicleName, arg)
  --end

	if scenario_scenarios then
		scenario_scenarios.updateVehicleAiState(vehicleName, {pathArgs = arg})
	end				
end
local function setAiRacing(vid)
	local scenario = scenario_scenarios.getScenario()
	local arg = {}
	local veh = be:getObjectByID(vid)
	local vName = veh:getName()
	if vName then 
		local aggression = 1 + ((math.random(1, 10)) * .1)
		arg = {
			wpTargetList = waypoint,
			noOfLaps = scenario.lapCount or gdloader.options.laps , 
			wpSpeeds = {},
			aggression = aggression or 1.4,
			aggressionMode = '', 
			resetLearning = 'false',
			routeSpeed = 0,
			routeSpeedMode = 'off',
			driveInLane = 'off',
			}	
		helper.queueLuaCommandByName(vName, 'gdai.driveUsingPath({wpTargetList = '..serialize(arg.wpTargetList)..', routeSpeed = '..arg.routeSpeed..', routeSpeedMode = "'..arg.routeSpeedMode..'", driveInLane = "'..arg.driveInLane..'", wpSpeeds = '..serialize(arg.wpSpeeds)..', noOfLaps = '..arg.noOfLaps..', aggression = '..arg.aggression..', aggressionMode = "'..arg.aggressionMode..'", resetLearning = '..arg.resetLearning..'})')		
		--setAiPath(arg)
	
		if scenario_scenarios then
			scenario_scenarios.updateVehicleAiState(vName, {pathArgs = arg})
		end	
	end
end
local function initScenario(playerID)
	local scenario = scenario_scenarios.getScenario()
	if scenario then
		local arenaGroup = gdloader.options.arena.type
		if arenaGroup ~= 'Derby' then
			local state = scenario.state
			scenario.state = 'pre-start'
			local laps = gdloader.options.laps
			waypoint = scenario.lapConfig
			table.insert(waypoint, scenario.lapConfig[1])
			scenario.BranchLapConfig = scenario.lapConfig
			scenario.initialLapConfig = deepcopy(scenario.lapConfig)
			scenario.statistics = {disableEndUI = true}
			scenario.whiteListActions = {"switch_next_vehicle", "switch_previous_vehicle", "loadHome", "saveHome", "recover_vehicle", "reload_vehicle", "vehicle_selector", "parts_selector", "dropPlayerAtCamera", "nodegrabberRender", "slower_motion", "faster_motion", "realtime_motion", "slow_motion"}
			scenario.blackListActions =  {}
			updateScenarioData(scenario)
			updateScenarioVehicles()
			local veh = be:getObjectByID(playerID)	
			local vName = veh:getName()
			scenario.lapCount = laps or 10
			veh.obj.playerUsable = true
			scenario.playerUsableVehicles = {vName}
			scenario.vehicles = {[''..vName..''] = {playerUsable = true, startFocus = true, driver={}}, ['*'] = { driver = {}}}
			updateScenarioData(scenario)
			raceMarker.init()
			if scenario_raceUI then
				scenario_raceUI.initialise(scenario)
			end
			scenario_waypoints.initialise()
			extensions.hook("onRaceInit")
			guihooks.trigger('RaceStart')
			for _,v in ipairs(gdloader.vehIn) do
				core_checkpoints.onVehicleSpawned(v.vid)
			end	
				
			scenario_scenarios.onPreRender()  -- set the scenario back to pre-start state.  This sets up the scenario with all the correct information
			scenario.state = state --set the scenario.state back to racing
			updateScenarioData(scenario)
			--dump(scenario)
			guihooks.trigger('ChangeState', {state ='menu'})
			--extensions.hook('onScenarioChange', scenario) --One last call to let everything know we can start
		else
			raceMarker.init()
			scenario_waypoints.initialise()
		end
	end	
end
local function resetHeat()
	local scenario = scenario_scenarios.getScenario()
	if scenario then
		scenario.showCountdown = true
		scenario.raceState = 'countdown'
		scenario.timer = 0
		 scenario.countDownTime = 3.5
		scenario.countDownShowed = false
		updateScenarioData()
	end
end
local function onScenarioRestarted()
	M.racePlace = {}
	driver = {}
	M.pathData = {}
	waypoint = {}
end

M.resetHeat = resetHeat
M.updateScenarioData = updateScenarioData
M.setAiRacing = setAiRacing
M.onScenarioRestarted = onScenarioRestarted
M.updatePlace = updatePlace
M.setScenario = setScenario
M.update = update
M.initScenario = initScenario

return M