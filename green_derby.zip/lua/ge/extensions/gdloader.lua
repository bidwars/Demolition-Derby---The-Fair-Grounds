local M = {}
M.vehIn = {}
M.driveTrain = 0
M.stopTicks = {}
local user = 'Hawk'
local maxStopTicks = math.huge
local dropPos = nil
local lastPosition = {}
local lookback = 'forward'
local currentcam = nil
local sVehicles = {}
local helper = require('scenario/scenariohelper')
local driver = {["Hawk"]="Hawk",["ai1"]="The Big Buffoon",["ai2"]="Mayhem Mike",["ai3"]="Gentle Bud",["ai4"]="Sir NoMercy",["ai5"]="Rawhide Billie",["ai6"]="Cushion Charlie",["ai7"]="Mr. Gumby",["ai8"]="Ms. Gumby",["ai9"]="Montster",["ai10"]="Collissione Carbonara",["ai11"]="Motor Man Jackson",["ai12"]="Erwin the Eliminator",["ai13"]="Softcore James",["ai14"]="Morning Hollywood",["ai15"]="Crashtest Tommy",["ai16"]="Hurricane Houston"}

local function adjustCamera()
	local cam = core_camera.getActiveCamName(0)
	if cam == 'observer' or cam == 'orbit' then
	else
		callback.driveTrain()
		local drive = M.driveTrain
		if drive.gear then
			if drive.gear > 0 then
				if lookback == 'back' or currentcam ~= cam then
					core_camera.lookBack(0)						
					lookback = 'forward' 
				end
			elseif drive.gear < 0 then
				if lookback == 'forward' or currentcam ~= cam then
					core_camera.lookBack(0)
					lookback = 'back'
				end
			end
		end
		if currentcam ~= cam then
			currentcam = cam
		end
	end
end
local function adjustSettings()
	for _, vName in ipairs(sVehicles) do	
		local vObj = scenetree.findObject(vName)
		if vObj then			
			vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
			vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
			vObj:queueLuaCommand([[
			local maxEngineTemp = 0
			local maxCylinderTemp = 0
			local maxOilTemp = 140
			local engine = powertrain.getDevice("mainEngine")
			if engine then
				local cwt = engine.thermals.cylinderWallTemperature
				local ebt = engine.thermals.engineBlockTemperature
				local rd = engine.thermals.radiatorDamage
				local ebm = engine.jbeamData.engineBlockMaterial
				local ot = engine.thermals.oilTemperature
				if rd == 0 then
					if ot > maxOilTemp then
						engine.thermals.oilTemperature = maxOilTemp
					end
					if ebm == "iron" then 
						maxEngineTemp = 1000
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 1100
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					else
						maxEngineTemp = 600
						if ebt > maxEngineTemp then
							engine.thermals.engineBlockTemperature = maxEngineTemp 
						end
						maxCylinderTemp = 620
						if cwt > maxCylinderTemp then
							engine.thermals.cylinderWallTemperature = maxCylinderTemp	
						end
					end
				end
			end
			]])
		end
	end
end
local function freezeAll(state, vName)
	local vObj = scenetree.findObject(vName)
	if vObj then
		vObj:queueLuaCommand('controller.mainController.setFreeze('..tostring(state) ..')')
	end
end
local function removeRecord(t,id)
	local i = nil
	for k,v in ipairs(t) do
		if v == id then
			i = k
		end
	end
	table.remove(t, i)
end
local function addStopTicks(dt)
	for k, vName in ipairs(sVehicles) do	
		local vObj = scenetree.findObject(vName)
		if vObj then
			local pos = vObj:getPosition()	
			local stopTicks = M.stopTicks[vName] 
			if stopTicks ~= nil then
				if not dropPos then
					dropPos = pos.z
				end
				if lastPosition[vName] == nil then lastPosition[vName] = pos end
				local distance =  math.abs((pos - lastPosition[vName]):len())
				if pos.z < dropPos - 2 then
					stopTicks = maxStopTicks + 1
				elseif distance > 0.4 then
					--vehicles still moving
					lastPosition[vName] = pos
					stopTicks = 0			
				else
					--Add one stop tick to the vehicles stop ticks
					stopTicks = stopTicks + dt 
				end
				--If they reach the max stop ticks then they are out
				if stopTicks > maxStopTicks  then	
			
					local msg = driver[vName] .. ' has been called out!'
					helper.flashUiMessage(msg, 3)
					removeRecord(M.vehIn, vObj:getID())
					freezeAll(1,vName)
				end
				M.stopTicks[vName] = stopTicks			
			end
		end
	end
end
local function onRaceResult()
	--local vehIn = #M.vehIn
	--for _,vName in ipairs(sVehicles) do
		--local lap = scenario_derby_vehicles.pathData[vName].lapCount
		--if lap > scenario.lapCount or vehIn == 1 then		
			--loadDone = false
			--if mode == 'race' then
				--scenario_derby_airace.lapWrite()  --need a new function to write the lap times.
--end
			
			--local place = scenario_derby_race.racePlace
			local result = nil
			if vName == user then
				result = {msg = 'You Won!'}
				if mode == 'race' then
					result = {msg = '1st Place! ' .. place[1].driver..' / 2nd Place ' ..place[2].driver.. ' / 3rd Place ' ..place[3].driver.. ' ' }
				end
				success(result)
			else
				local driverName = scenario_derby_vehicles.driver[vName]
				result = 'The driver '..driverName..' has won.'
				fail(result)
			end	
		--end
	--end
end
local function updateGFX(dtReal) 
	local vehIn = #M.vehIn
	if vehIn > 1 then
		adjustCamera()
		adjustSettings()
		addStopTicks(dtReal)
	end
	if vehIn == 1 then
		--onRaceResult()
	end
	
end
local function onPhysicsPaused()
	for _,vName in pairs(sVehicles) do
		helper.queueLuaCommandByName(vName, 'gdai.setState({mode="stop"})')
	end
end
local function onVehicleSpawned(vid)
	print('onSpawn')
	sVehicles = {}
	table.insert(M.vehIn, vid)
	local veh = be:getObjectByID(vid)
	veh:queueLuaCommand('extensions.load("gdmain")')
	sVehicles = scenetree.findClassObjects('BeamNGVehicle')
end


M.onPhysicsPaused = onPhysicsPaused
M.onVehicleSpawned = onVehicleSpawned
M.updateGFX = updateGFX

return M