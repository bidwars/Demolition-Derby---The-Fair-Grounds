-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}
local scenario = nil --Scenario Saved to this
--Helper for scenario lua commands
local helper = require('scenario/scenariohelper')

--Vehicle Info
local lastPosition = {} --Last position of the vehicle
local maxStopTicks = 800 --was 700 --About 60 seconds --Max number of times the onPreRender(dt) loops before the vehicle is counted out
local vTimeout = {} --Vehicles that have been called out
local vehOut = 0 --Number of vehicles out
local vehIn = 0  --Number of vehicles still running
local user = "Hawk"

--Racing
local lapsEntered = 10 --Default number of laps for racing
local raceMarker = require("scenario/race_marker")

--Delay Start
local derbyTick = 2 -- Used with delayStart to have a timer for when to resume
local delayStart = false  --Used Delay the Start of the senario until everything has loaded
local loadDone = false --Used to Start the senario when loading is done

local Arena = nil  -- Arena selected 

--Modules
M.wp1 = 0
M.wp2 = 0
M.vehicleCountEntered = 0
M.vehicleClass = 0
M.includeMods = 0
M.vehicleConfig = 0	
M.Arena = 0	
M.vehiclePick = 0
M.stopTicks = {}
M.vehOut = 0
M.vehIn = 0
M.vTimeout = {}
require('mathlib')

-------------------------------------------------------------------------------------
--GET A LIST OF WAYPOINTS ON THE MAP
-------------------------------------------------------------------------------------
local function findWP()  
local wpNum1 = 1  --Default Grass
local wpNum2 = 2
	if Arena == 2 then --Concrete
		wpNum1 = 3
		wpNum2 = 4
	elseif Arena == 1 then -- Free Fall
		wpNum1 = 5
		wpNum2 = 6
	elseif Arena == 4 then  --Oval Track
		wpNum1 = 7
		wpNum2 = 8
	elseif Arena == 5 then --Concrete Figture 8
		wpNum1 = 3
		wpNum2 = 4
	elseif Arena == 6 then -- Mud Pit
		wpNum1 = 9
		wpNum2 = 10
	end
	M.wp1 = wpNum1 
	M.wp2 = wpNum2 
end
-------------------------------------------------------------------------------------
--GET THE NUMBER OF AI VEHICLES, ARENA SELECTED, AND STATE FROM THE demo_derby.js FILE
-------------------------------------------------------------------------------------
local function Selection(enteredCount,class,mods,vList,state,arena)
	print("Vehicle Count "..enteredCount)
	print("Class "..class)
	print("Mods "..mods)
	print("State "..state)
	print("Arena "..arena)
	if vList == nil then vList = 1 end
	print("Vehicle List "..vList)
	M.vehicleCountEntered = tonumber(enteredCount)
	M.vehicleClass = tonumber(class)
	M.includeMods = tonumber(mods)
	M.vehicleConfig = tonumber(state)	
	Arena = tonumber(arena)
	M.Arena = Arena	
	M.vehiclePick = tonumber(vList)
	scenario_derby_classes.modelName()
	--dump(derby_classes.dataList)
	return scenario_derby_classes.dataList
end
local function lapSelection(enteredLaps)
	--print("laps "..enteredLaps)
	lapsEntered = tonumber(enteredLaps)
end
local function setPlayer()
	local player = scenetree.findObject(user)
	be:enterVehicle(0, player.obj)
	commands.setCameraPlayer()	
	scenario.focusSlot = player.obj:getID()
end
-------------------------------------------------------------------------------------
--SCENARIO START
-------------------------------------------------------------------------------------
local function onScenarioChange(sc)
	scenario = sc
	if not scenario then return end
	if scenario.state == 'pre-start' and delayStart == false then
		--Set the default partsconfig
		Selection(4,3,1,1,3,3)
		scenario_derby_vehicles.partsConfig(true)
	end
	if scenario.state == 'running' and delayStart == false then			
		scenario_derby_vehicles.createVehicles()
		if Arena == 4 or Arena == 5 then
			scenario_derby_race.createRoads(scenario, lapsEntered)
			scenario_waypoints.initialise(scenario)
		else
			scenario.lapCount = 1
		end
		findWP()
		vehIn = scenario_derby_vehicles.loadVehicles() 
		M.vehIn = vehIn
		guihooks.trigger('ShowApps', true)
		extensions.hook("onRaceInit")
		setPlayer()
		scenario_derby_vehicles.freezeAll(1,user)
		delayStart = true
	end
end
 ------------------------------------------------------------------------------------
 --WHEN THE SENARIO COUNTDOWN TIMER REACHES GO!
 ------------------------------------------------------------------------------------
local function onScenarioRaceCountingDone()
	derbyTick = scenario_derby_vehicles.nameClone()
	if derbyTick ~= 1 then
		local sVehicles = scenario_derby_vehicles.sVehicles
		for _, vName in pairs(sVehicles) do
			scenario_derby_vehicles.setupVehicles(vName)
		end
		loadDone = true
		--scenario.state = 'pre-running' --scenario.state = 'pre-running' --set the senario back to pre-running.
		--extensions.hook('onScenarioChange', scenario)
	else
		setPlayer()
		scenario_derby_vehicles.freezeAll(1,user)
	end	
end
local function fail(result)
	scenario_scenarios.finish({failed = result})
end
local function success(result)
	scenario_scenarios.finish(result)
end
---------------------------------------------------------------------------------------
--MAIN SCENARIO TIMER LOOP 
-------------------------------------------------------------------------------------------
local function onPreRender(dt)
	if derbyTick == 1 then
		onScenarioRaceCountingDone()
		derbyTick = 2
	end
	if loadDone == false then return end
	local sVehicles = scenario_derby_vehicles.sVehicles
	for k, vName in pairs(sVehicles) do	
		if derbyTick == 2 then
			scenario_derby_vehicles.weldParts(vName)
			derbyTick = 3 
		else
			local vObj = scenetree.findObject(vName)
			if vObj then
				local driverName
				if vName ~= user then
					driverName = scenario_derby_vehicles.driver[vName]
				else
					driverName = user
				end
				local stopTicks = M.stopTicks[vName] 
				if stopTicks ~= nil then
					vObj:queueLuaCommand('if energyStorage.getStorage("mainTank") then energyStorage.getStorage("mainTank"):setRemainingVolume(1) end')
					vObj:queueLuaCommand('fire.extinguishVehicleSlowly()')
					if vTimeout[vName] == nil or vTimeout[vName] ~= vName then 
						if vehOut >= 1 and vehIn == 1 then
						--Senario is finished display win message
							if vTimeout[user] == nil then
								local result = {msg = 'You Won!'}
								success(result)
							else
								fail('The driver '..driverName..' has won.')
							end
							loadDone = false	
							break
						end
			
						local position = vObj:getPosition()
						if Arena == 4 or Arena == 5 then
							local v3position = vec3(position)
							scenario_derby_race.checkPoints(vName,scenario,v3position)
						end
						if vName ~= user then --~=  Should be
						--scenario_derby_wheels.checkSlip(vName)
						--Get the ai moving 
							if Arena == 4 or Arena == 5 then	
								scenario_derby_airace.update(vName)
							else
								scenario_derby_aiderby.update(vName,dt)
							end
			
						else
							--if not map.objects[map.objectNames[vName]] then return end
						--local vel = map.objects[map.objectNames[vName]].vel
						--vel = vel:length()
						--if vel then
						--	if vel > 0 then 
						--		settings.setValue('cameraOrbitRelaxation', 1) 
						--	else 
						--		settings.setValue('cameraOrbitRelaxation', 3)
						--	end 
						--	end
							raceMarker.hide(true)
						end
						--Get the distance from the last position
						--print(position)
						local wp1 = scenetree.findObject('wp_' ..M.wp1):getPosition()
						if position.z < wp1.z - 2 then
							stopTicks = maxStopTicks
						end
						if lastPosition[vName] == nil then lastPosition[vName] = position end
						local distance =  math.abs((position - lastPosition[vName]):len())
						if distance > 0.4 then
							--vehicles still moving
							lastPosition[vName] = position
							stopTicks = 0			
						else
							--Add one stop tick to the vehicles stop ticks
							if Arena ~= 5 or Arena ~= 4 then
								stopTicks = stopTicks + 1 
							end
							--If they reach the max stop ticks then they are out
				
							if stopTicks > maxStopTicks  then	
								vehOut = vehOut + 1	
								vehIn = vehIn - 1
								vTimeout[vName] = vName
					
								local msg = driver .. ' has been called out!'
								helper.flashUiMessage(msg, 3)
								scenario_derby_vehicles.freezeAll(1,vName)
							end
						end
					end
				end
				M.stopTicks[vName] = stopTicks	
				M.vehIn = vehIn
				M.vehOut = vehOut
				M.vTimeout[vName] = vTimeout[vName]
			end
		end
	end
end
-------------------------------------------------------------------------------------
--TRIGGERED ANYTIME THE SENARIO IS RESTARTED
-------------------------------------------------------------------------------------
local function onScenarioRestarted()
	--if(scenetree.DerbyObjectsGroup) then scenetree.DerbyObjectsGroup:delete()end
	--derbyGroup:unload()
	--derbyGroup:delete()
	--scenario_derby_vehicles.scenarioVehicles = {}
	--local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
	--local rVehilces = scenario_derby_vehicles.scenarioVehicles
	local sVehicles = scenetree.findClassObjects('BeamNGVehicle')
		for k, vName in pairs(sVehicles) do	
			if k ~= 1 or vName ~= "Hawk" then
				log('D', 'scenario', "Deleting Vehicle "..vName)
				scenario_derby_vehicles.deleteVehicles(vName)
			end
		end
	M.vehIn = 0
	vehIn = 0 
	vTimeout = {}
	vehOut = 0
	derbyTick = 0
	delayStart = false
	loadDone = false
	M.vehOut = 0
	M.stopTicks = {} 
	scenario_derby_vehicles.sVehicles = {}
	sVehicles = {}
	local objName = nil
	local obj = nil
	local unload = false
	objName = "dirttrackwp"	
	obj = scenetree[objName]
	if obj then
		unload = true
	else	
		objName = "fig8concretewp"
		obj = scenetree[objName]
		if obj then
			unload = true
		end		
	end
	if unload == true then 
		obj:unload()
		obj:delete()
	
		be:reloadCollision()
		log('D', 'scenario_scenarios.spawnPrefab', 'unloading Prefab '..objName)
	end
	
end
M.Selection = Selection
M.lapSelection = lapSelection
M.onRaceTick = onRaceTick
M.onScenarioChange = onScenarioChange
M.onScenarioRaceCountingDone = onScenarioRaceCountingDone
M.onPreRender = onPreRender
M.onScenarioRestarted = onScenarioRestarted
--M.wheelDataCallback = wheelDataCallback


return M