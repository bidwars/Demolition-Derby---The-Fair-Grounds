-------------------------------------------------------------------------------------
-- Derby Lua Script
-- By Bidwars
-------------------------------------------------------------------------------------

local M = {}

local save = {}
local function setVehPos(filename)
 --if filename == nil then
   -- filename = v.vehicleDirectory .. "/vehicle.save.json"
  --end

  --local save = jsonReadFile(filename)

  -- satefy checks
 -- if not save  or save.nodeCount ~= #v.data.nodes or save.beamCount ~= #v.data.beams then
   -- log("E", "save", "unable to load vehicle: invalid vehicle loaded?")
  --  return
 -- end
	
	--obj:queueGameEngineLua("be:getPlayerVehicle(0):setPositionRotation("..pos..","..rot..")")
	--obj:queueGameEngineLua("vehicleSetPositionRotation("..obj:getID()..","..thpos.x..","..thpos.y..","..thpos.z..","..throt.x..","..throt.y..","..throt.z..","..throt.w..")")
	--obj:setPositionRotation(thpos.x, thpos.y, thpos.z, throt.x, throt.y, throt.z, throt.w)
end
local function nodeInfo()
	local rot = quat(obj:getRotation())
	dump(rot)
	local pos = vec3(obj:getPosition())
	dump(pos) 
	save.oldnodes={}
	for _, node in pairs(v.data.nodes) do
		local nodePos = vec3(pos - node.pos)
		local d = {
			vec3(obj:getNodePosition(node.cid)):toTable()
		}
		table.insert(d,node.cid)
		table.insert(d,node.partOrigin)
		table.insert(d,nodePos:toTable())
		
		save.oldnodes[node.cid + 1] = d
	end
end
local function load(filename)
  if filename == nil then
    filename = v.vehicleDirectory .. "/vehicle.save.json"
  end

  local save = jsonReadFile(filename)

  -- satefy checks
  if not save  or save.nodeCount ~= #v.data.nodes or save.beamCount ~= #v.data.beams then
    log("E", "save", "unable to load vehicle: invalid vehicle loaded?")
    return
  end

  --importPersistentData(save.luaState)

  --for k, h in pairs(save.hydros) do
   -- hydros.hydros[k].state = h
  --end
	 for _, node in pairs(v.data.nodes) do
	
	--dump(vec3(obj:getNodePosition(node.cid)):toTable())
	local cid = tonumber(node.cid) + 1
	 local savedNode = save.nodes[cid]
	 savedNode[1] = vec3(savedNode[1])
	 local nodePos = vec3(obj:getNodePosition(node.cid))
	local nl1 = savedNode[1]
	nl1 = vec3(nl1.x,nl1.y,0):length()
	local nl2 = nodePos
	nl2 = vec3(nl2.x,nl2.y,0):length()
	local savedN = vec3(savedNode[1].x,savedNode[1].y,0)
	local nodeP = vec3(nodePos.x,nodePos.y,0)
	
	local degs = math.deg(math.acos(savedN:dot(nodeP)/nl1 * nl2))
	
	local prev = savedNode[1]:normalized()
	local new = nodePos:normalized()
	local test = math.atan2(new:cross(prev):length(),new:dot(prev)) * 180/math.pi
	local vecX = vec3(1, 0, 0)
	local vecY = vec3(0, -1, 0)
	local degs2 = math.deg(math.acos(prev:dot(new)/nl1 * nl2))
	--local a2 = math.deg(math.atan2(prev:dot(vecX), prev:dot(vecY))) 
	--local a3 = math.deg(math.atan2(new:dot(vecX), new:dot(vecY)))
	--local test = math.atan2((savedNode[1]:cross(nodePos):length()), savedNode[1]:dot(nodePos))* 180/math.pi
	--local an = math.asin(savedNode[1]:dot(nodePos))* 180/math.pi
	--local test2 = math.asin(savedNode[1].x * nodePos.y - savedNode[1].y * nodePos.x)
	print(node.cid)
	print(degs)
	print(degs2)
	--print(a2)
	--print(a3)
	print(test)
	--print(test2)
	--print(test2*180/math.pi)
	print(nodePos)
	print(savedNode[1])
	local radi = math.acos(savedN:dot(nodeP)/nl1 * nl2)
	--print(radi)
	savedNode[1] = savedNode[1] * test
	obj:setNodePosition(node.cid, vec3(savedNode[1]):toFloat3())
    if savedNode[2] and savedNode[2] > 1 then
      obj:setNodeMass(node.cid, savedNode[2])
    end
	
  end
  
 --for cid, node in pairs(save.nodes) do
  --  cid = tonumber(cid) - 1
--	obj:setNodePosition(node.cid, vec3(savedNode[1]):toFloat3())
  --  if savedNode[2] and savedNode[2] > 1 then
  --    obj:setNodeMass(node.cid, savedNode[2])
   -- end
 --end

  for cid, beam in pairs(save.beams) do
    cid = tonumber(cid) - 1
    obj:setBeamLength(cid, beam[1])
    if beam[2] == true then
      obj:breakBeam(cid)
    end
    if beam[3] > 0 then
      -- deformation: do not call c++ at all, its just used on the lua side anyways
      --print('deformed: ' .. tostring(cid) .. ' = ' .. tostring(beam[3]))
      beamstate.beamDeformed(cid, beam[3])
    end
  end
	
  obj:commitLoad()
end
--local num = 0
--local saveme = {} 

local function saveNodes(filename,state,heat)
  if filename == nil then
    filename = v.vehicleDirectory .. "/vehicle.save.json"
  end
  local rot = quat(obj:getRotation())
	dump(rot)
	local pos = vec3(obj:getPosition())
	dump(pos) 
	--local save = {}
  -- TODO: color	
  --local save = {}
  --save.format = "v2"
  save.model = v.vehicleDirectory:gsub("vehicles/", ""):gsub("/", "")
  --save.parts = v.userPartConfig
  --save.vars = v.userVars
	save.vehicleDirectory = v.vehicleDirectory
  save.nodeCount = #v.data.nodes
  --save.beamCount = #v.data.beams
  --save.railCount = #v.data.rails
  --save.luaState = serializePackages("save")
  --save.hydros = {}
  ----for _, h in pairs(hydros.hydros) do
    --table.insert(save.hydros, h.state)
  --end
  
	--save.rails = {}
	--print("The rails")
	--dump(v.data.rails)
	--print("The slideNodes")
	--dump(v.data.slideNodes)
	--for _,rail in pairs(v.data.rails) do
 
 save.nodes = {}

if state == 1 then 
print('checking')
	local recover = jsonReadFile(filename)
		if not recover then return end
  for _, node in pairs(v.data.nodes) do
	if not string.find(node.partOrigin, 'wheeldata') then
		local recoveredNode = vec3(recover.nodes[node.cid + 1][1])
		local newNode =  vec3(obj:getNodePosition(node.cid))
		local distance = math.abs((recoveredNode - newNode):length())
		if (distance * 100) > 9 then 
		--print(node.partOrigin)
		local dif = recoveredNode - newNode
		--dump(dif)
		--dump(node.pos + dif)
		--dump(vec3(node.pos))
		 --obj:queueGameEngineLua("(be:getObjectByID(" .. obj:getID() .. ")):(Point4F(" .. insertCommas(defaultColor) .. "))")
		--obj:queueGameEngineLua("("..obj:getID()..","..thpos.x..","..thpos.y..","..thpos.z..","..throt.x..","..throt.y..","..throt.z..","..throt.w..")")
		--dump(node)
		local d = {
		vec3(node.pos + dif):toTable()
		}
		table.insert(d, node.partOrigin)
		table.insert(d, node.name)
		--if not save.nodes[node.partOrigin] then
		
			--save.nodes[node.partOrigin] = node.partOrigin
		--end
			--save.nodes[node.partOrigin][node.cid + 1] = d -- grouped by part
		save.nodes[node.cid + 1] = d
		end	
	end
		
   end
    obj:queueGameEngineLua("scenario_gdbeams.moveNodes("..heat..","..obj:getID()..")")
   
else
	print('saving')
	for _, node in pairs(v.data.nodes) do
	local d = {
	  vec3(obj:getNodePosition(node.cid)):toTable()
    }
    if math.abs(obj:getOriginalNodeMass(node.cid) - obj:getNodeMass(node.cid)) > 0.1 then
      table.insert(d, obj:getNodeMass(node.cid))
    end	
	
	save.nodes[node.cid + 1] = d
	end
	
 end
	jsonWriteFile(filename, save, true)
  --save.rot = quat(obj:getRotation()):toTable()
  --save.pos = vec3(obj:getPosition()):toTable()
 -- save.beams = {}
 -- for _, beam in pairs(v.data.beams) do
   -- local d = {
    --  obj:getBeamRestLength(beam.cid),
    --  obj:beamIsBroken(beam.cid),
    --  obj:getBeamDeformation(beam.cid)
   -- }
   -- save.beams[beam.cid + 1] = d
 -- end
  
  --if state == 0 then
	--setVehPos()
	 
	-- saveme = save
	--jsonWriteFile(filename, save, true)
	--local srot = quat(obj:getRotation())
	--dump(srot)
	--local spos = vec3(obj:getPosition())
	--dump(spos) 

		--obj:queueGameEngineLua("vehicleSetPositionRotation("..obj:getID()..","..pos.x..","..pos.y..","..pos.z..","..rot.x..","..rot.y..","..rot.z..","..rot.w..")")
	--num = 1
	--saveNodes("vehicles/heatsTEST.json")
--else
	
 -- end

end
--M.setVehPos = setVehPos
M.saveNodes = saveNodes
M.load = load
M.nodeInfo = nodeInfo
return M